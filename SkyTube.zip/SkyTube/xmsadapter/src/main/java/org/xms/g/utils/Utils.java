
package org.xms.g.utils;

import java.lang.reflect.Array;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

public class Utils {

    private static Map<String, String> map = new HashMap<>();

    private static Map<String, String> G2H = new HashMap<>();

    private static Map<String, String> H2G = new HashMap<>();

    private static Map<Class, Constructor> wrapperCache = new ConcurrentHashMap<>();

    private static Map<Class, Method> getGHInstCache = new ConcurrentHashMap<>();

    private static final String G = "g";

    private static final String H = "h";

    public static <T, R> T[] mapArray2GH(R[] array, Class<T> cls, boolean isH) {
        if (null == array) {
            org.xms.g.utils.XmsLog.w("1", "array is null");
            return null;
        }
        T[] result = (T[]) Array.newInstance(cls, array.length);
        for (int i = 0; i < array.length; i++) {
            result[i] = Utils.getInstanceInInterface(array[i], isH);
        }
        String arrayType = array.getClass().getName();
        String resultType = result.getClass().getName();
        org.xms.g.utils.XmsLog.i("2", "array : " + arrayType + " isH : " + isH + " result : " + resultType);
        return result;
    }

    private static class MappedIterator<R, T> implements Iterator<T> {
        Iterator<R> origin;

        Function<R, T> mapper;

        MappedIterator(Iterator<R> origin, Function<R, T> mapper) {
            this.origin = origin;
            this.mapper = mapper;
        }

        @Override
        public boolean hasNext() {
            return origin.hasNext();
        }

        @Override
        public T next() {
            return mapper.apply(origin.next());
        }

        @Override
        public void remove() {
            origin.remove();
        }
    }

    public static <R, T> Iterable<T> transformIterable(Iterable<R> iterable, Function<R, T> mapper) {
        Iterator<T> iter = new MappedIterator<>(iterable.iterator(), mapper);
        String iteratorType = iter == null ? null : iter.getClass().getName();
        org.xms.g.utils.XmsLog.i("1", "iterable : " + iterable.getClass().getName() + " result : " + iteratorType);
        return () -> iter;
    }

    public static <T, R> T[] genericArrayCopy(R[] array, Class<T> type, Function<R, T> mapper) {
        T[] arr = (T[]) Array.newInstance(type, array.length);
        for (int i = 0; i < array.length; i++) {
            arr[i] = mapper.apply(array[i]);
        }
        String typeType = type == null ? null : type.getClass().getName();
        org.xms.g.utils.XmsLog.i("1",
            "array : " + array.getClass().getName() + " type : " + typeType + " result : " + arr.getClass().getName());
        return arr;
    }

    public static <K, V, T> Map<T, K> convertMap(Map<T, V> map, Function<V, K> mapper) {
        Map<T, K> returnMap = new HashMap<>();
        for (Map.Entry<T, V> entry : map.entrySet()) {
            returnMap.put(entry.getKey(), mapper.apply(map.get(entry.getKey())));
        }
        org.xms.g.utils.XmsLog.i("1",
            "map : " + map.getClass().getName() + " result : " + returnMap.getClass().getName());
        return returnMap;
    }

    public static <T, R> android.util.SparseArray<T> genericArrayCopy(android.util.SparseArray<R> array,
        Function<R, T> mapper) {
        android.util.SparseArray<T> arr = new android.util.SparseArray<>(array.size());
        for (int i = 0; i < array.size(); i++) {
            int key = array.keyAt(i);
            arr.put(key, mapper.apply(array.get(key)));
        }
        org.xms.g.utils.XmsLog.i("1",
            "array : " + array.getClass().getName() + " result : " + arr.getClass().getName());
        return arr;
    }

    public static <T, R> List<T> mapList(List<R> list, Function<R, T> mapper) {
        if (list == null) {
            org.xms.g.utils.XmsLog.i("1", "list is null");
            return null;
        }
        List<T> result = new ArrayList<>(list.size());
        for (int i = 0; i < list.size(); i++) {
            result.add(mapper.apply(list.get(i)));
        }
        String resultType = result.getClass().getName();
        org.xms.g.utils.XmsLog.i("2", "list : " + list.getClass().getName() + " result : " + resultType);
        return result;
    }

    public static <T, R> List<T> mapList2GH(List<R> list, boolean isH) {
        List<T> result = mapList(list, it -> getInstanceInInterface(it, isH));
        String listType = list == null ? null : list.getClass().getName();
        String resultType = result == null ? null : result.getClass().getName();
        org.xms.g.utils.XmsLog.i("1", "list : " + listType + " isH : " + isH + " result : " + resultType);
        return result;
    }

    public static <T, R> List<T> mapList2X(List<R> list, boolean isH) {
        List<T> result = isH ? mapList(list, it -> (T) getXmsObjectWithHmsObject(it))
            : mapList(list, it -> (T) getXmsObjectWithGmsObject(it));
        String listType = list == null ? null : list.getClass().getName();
        String resultType = result == null ? null : result.getClass().getName();
        org.xms.g.utils.XmsLog.i("1", "list : " + listType + " isH : " + isH + " result : " + resultType);
        return result;
    }

    public static <T, R> Collection<T> mapCollection(Collection<? extends R> collection, Function<R, T> mapper) {
        if (collection == null) {
            org.xms.g.utils.XmsLog.i("0", "collection : null");
            return null;
        }
        String collectionType = collection.getClass().getName();
        Collection<T> result;
        if (collection instanceof Set) {
            int capacity = Math.max((int) ((float) collection.size() / 0.75F) + 1, 16);
            result = new HashSet<>(capacity);
        } else {
            result = new ArrayList<>(collection.size());
        }
        for (R item : collection) {
            result.add(mapper.apply(item));
        }
        String resultType = result.getClass().getName();
        org.xms.g.utils.XmsLog.i("1", "collection : " + collectionType + " result : " + resultType);
        return result;
    }

    public static <T, R> Collection<T> mapCollection2GH(Collection<R> collection, boolean isH) {
        Collection<T> result = mapCollection(collection, it -> getInstanceInInterface(it, isH));
        String collectionType = collection == null ? null : collection.getClass().getName();
        String resultType = result == null ? null : result.getClass().getName();
        org.xms.g.utils.XmsLog.i("1", "collection : " + collectionType + " isH : " + isH + " result : " + resultType);
        return result;
    }

    public static <T, R> Collection<T> mapCollection2X(Collection<R> collection, boolean isH) {
        Collection<T> result = isH ? mapCollection(collection, it -> (T) getXmsObjectWithHmsObject(it))
            : mapCollection(collection, it -> (T) getXmsObjectWithGmsObject(it));
        String collectionType = collection == null ? null : collection.getClass().getName();
        String resultType = result == null ? null : result.getClass().getName();
        org.xms.g.utils.XmsLog.i("1", "collection : " + collectionType + " isH : " + isH + " result : " + resultType);
        return result;
    }

    private static Object transformList2X(Object object, boolean isH)
        throws IllegalAccessException, InstantiationException, ClassNotFoundException {
        if (!(object instanceof List)) {
            org.xms.g.utils.XmsLog.i("1", "object is List");
            return object;
        }
        List result = (List) object.getClass().newInstance();
        for (int i = 0; i < ((List) object).size(); i++) {
            Object o = ((List) object).get(i);
            if (o == null || !map.containsKey(o.getClass().getCanonicalName())) {
                result.add(o);
                continue;
            }
            // should transform to X.
            String xName = map.get(o.getClass().getCanonicalName());
            Class clazz = Class.forName(xName);
            if (isH) {
                result.add(getOrCreateInstance(clazz, null, o, isH));
            } else {
                result.add(getOrCreateInstance(clazz, o, null, isH));
            }
        }
        String objectType = object.getClass().getName();
        String resultType = result == null ? null : result.getClass().getName();
        org.xms.g.utils.XmsLog.i("2", "object : " + objectType + " isH : " + isH + " result : " + resultType);
        return result;
    }

    public static Object getXmsObjectWithGmsObject(Object object) {
        if (object == null) {
            return object;
        }
        if (object instanceof List) {
            try {
                return transformList2X(object, false);
            } catch (IllegalAccessException e) {
                org.xms.g.utils.XmsLog.e("2", e.getMessage(), e);
            } catch (InstantiationException e) {
                org.xms.g.utils.XmsLog.e("2", e.getMessage(), e);
            } catch (ClassNotFoundException e) {
                org.xms.g.utils.XmsLog.e("2", e.getMessage(), e);
            }
        }
        if (!isGmsType(object)) {
            return object;
        }
        org.xms.g.utils.XmsLog.i("1", "inObject : " + object.getClass().getName());
        return getXmsObject(object, G);
    }

    public static Object getXmsObjectWithHmsObject(Object object) {
        if (object == null) {
            return object;
        }
        if (object instanceof List) {
            try {
                return transformList2X(object, true);
            } catch (IllegalAccessException e) {
                org.xms.g.utils.XmsLog.e("2", e.getMessage(), e);
            } catch (InstantiationException e) {
                org.xms.g.utils.XmsLog.e("2", e.getMessage(), e);
            } catch (ClassNotFoundException e) {
                org.xms.g.utils.XmsLog.e("2", e.getMessage(), e);
            }
        }
        if (!isHmsType(object)) {
            return object;
        }
        org.xms.g.utils.XmsLog.i("1", "inObject : " + object.getClass().getName());
        return getXmsObject(object, H);
    }

    private static Object getXmsObject(Object object, String GorH) {
        String xmsClassName = null;
        String interfaceClass = null;
        String inClassName = object.getClass().getName();
        inClassName = inClassName.replaceAll("\\$", ".");

        Class inSuperClass = object.getClass().getSuperclass();
        Class[] interfaces = object.getClass().getInterfaces();
        while (!map.containsKey(inClassName)) {
            inClassName = inSuperClass.getName().replaceAll("\\$", ".");
            if (inClassName.equals("java.lang.Object")) {
                if (interfaces == null || interfaces.length == 0) {
                    break;
                }
                String interfacesStr = interfaces[0].getName().replaceAll("\\$", ".");
                while (!map.containsKey(interfacesStr)) {
                    interfaces = interfaces[0].getInterfaces();
                    interfacesStr = interfaces[0].getName().replaceAll("\\$", ".");
                }
                interfaceClass = map.get(interfacesStr);
                org.xms.g.utils.XmsLog.d("2",
                    "interfacesStr : " + interfacesStr + ", interfaceClass : " + interfaceClass);
            } else {
                inSuperClass = inSuperClass.getSuperclass();
                interfaces = inSuperClass.getInterfaces();
            }
        }

        xmsClassName = map.get(inClassName);
        org.xms.g.utils.XmsLog.i("1", "inClassName : " + inClassName + ", xmsClassName : " + xmsClassName);
        if (xmsClassName == null) {
            if (interfaceClass != null) {
                xmsClassName = interfaceClass;
                org.xms.g.utils.XmsLog.i("5", "xmsClassName : " + xmsClassName);
            } else {
                org.xms.g.utils.XmsLog.i("6", "xmsClassName is null");
                return object;
            }
        }

        try {
            Class clazz = Class.forName(xmsClassName);
            org.xms.g.utils.XmsLog.i("7", "clazz : " + clazz.getName());
            Constructor[] constructors = clazz.getConstructors();
            for (Constructor constructor : constructors) {
                if (constructor.getParameterTypes().length == 2
                    && isGmsClass(constructor.getParameterTypes()[0].getName())) {
                    return "g".equals(GorH) ? constructor.newInstance(object, null)
                        : constructor.newInstance(null, object);
                }
            }
        } catch (ClassNotFoundException e) {
            org.xms.g.utils.XmsLog.e("8", e.getMessage(), e);
        } catch (IllegalAccessException e) {
            org.xms.g.utils.XmsLog.e("9", e.getMessage(), e);
        } catch (InstantiationException e) {
            org.xms.g.utils.XmsLog.e("10", e.getMessage(), e);
        } catch (InvocationTargetException e) {
            org.xms.g.utils.XmsLog.e("11", e.getMessage(), e);
        }
        return null;
    }

    public static boolean isGmsClass(String className) {
        if (className.startsWith("com.google.android.gms") || className.startsWith("com.google.firebase")
            || className.startsWith("com.google.ads") || className.startsWith("com.android.installreferrer")
            || className.startsWith("com.google.android.libraries") || className.startsWith("com.google.api")) {
            org.xms.g.utils.XmsLog.i("1", "true");
            return true;
        }
        org.xms.g.utils.XmsLog.i("2", "false");
        return false;
    }

    public static boolean isHmsClass(String className) {
        if (className.startsWith("com.huawei.hms") || className.startsWith("com.huawei.hmf")) {
            org.xms.g.utils.XmsLog.i("1", "true");
            return true;
        }
        org.xms.g.utils.XmsLog.i("2", "false");
        return false;
    }

    public static boolean isGmsType(Object obj) {
        if (obj == null) {
            return false;
        }
        if (obj.getClass().isAnonymousClass() || obj.getClass().isMemberClass()) {
            if (isGmsClass(obj.getClass().getName())) {
                return true;
            }
            if (obj.getClass().getSuperclass().getName().equals("java.lang.Object")) {
                Class[] superInterfaces = obj.getClass().getInterfaces();
                // anonymous class or inner class has only one interface
                for (Class inter : superInterfaces) {
                    return isGmsClass(inter.getName());
                }
            } else {
                Class superClassName = obj.getClass().getSuperclass();
                return isGmsClass(superClassName.getName());
            }
        }
        return isGmsClass(obj.getClass().getName());
    }

    public static boolean isHmsType(Object obj) {
        if (obj == null) {
            return false;
        }
        if (obj.getClass().isAnonymousClass() || obj.getClass().isMemberClass()) {
            if (isHmsClass(obj.getClass().getName())) {
                return true;
            }
            if (obj.getClass().getSuperclass().getName().equals("java.lang.Object")) {
                Class[] superInterfaces = obj.getClass().getInterfaces();
                // anonymous class or inner class has only one interface
                for (Class inter : superInterfaces) {
                    return isHmsClass(inter.getName());
                }
            } else {
                Class superClassName = obj.getClass().getSuperclass();
                return isHmsClass(superClassName.getName());
            }
        }
        return isHmsClass(obj.getClass().getName());
    }

    public static Class getGmsClassWithXmsClass(Class xmsClass) {
        try {
            Field field = xmsClass.getField("gInstance");
            org.xms.g.utils.XmsLog.i("1", "field.getType : " + field.getType());
            return field.getType();
        } catch (NoSuchFieldException e) {
            org.xms.g.utils.XmsLog.w("2", "xmsClass : " + xmsClass + ", e : " + e.getMessage(), e);
            return xmsClass;
        }
    }

    public static Class getHmsClassWithXmsClass(Class xmsClass) {
        try {
            Field field = xmsClass.getField("hInstance");
            org.xms.g.utils.XmsLog.i("1", "field.getType : " + field.getType());
            return field.getType();
        } catch (NoSuchFieldException e) {
            org.xms.g.utils.XmsLog.w("2", "xmsClass : " + xmsClass + ", e : " + e.getMessage(), e);
            return xmsClass;
        }
    }

    public static Class getXmsClassWithClass(Class clazz) {
        try {
            if (map.containsKey(clazz.getName())) {
                org.xms.g.utils.XmsLog.i("1", "XmsClass : " + map.get(clazz.getName()));
                return Class.forName(map.get(clazz.getName()));
            }
        } catch (ClassNotFoundException e) {
            org.xms.g.utils.XmsLog.e("2", e.getMessage(), e);
        }
        return null;
    }

    /**
     * Tell a clazz is xms type or not.
     *
     * @param clazz, the clazz need to be identified.
     * @return if clazz is xms type, return true.
     */
    public static boolean isXmsType(Class clazz) {
        boolean result = XInterface.class.isAssignableFrom(clazz);
        org.xms.g.utils.XmsLog.i("1", "isXmsType : " + result);
        return result;
    }

    /**
     * Create an instance from its Class, and we MUST use
     * its wrapper constructor.
     *
     * @param clazz, Create an instance from clazz.
     * @param gInst, first parameter for constructor.
     * @param hInst, second parameter for constructor.
     * @return the instance.
     */
    public static Object getOrCreateInstance(Class clazz, Object gInst, Object hInst, boolean isH) {
        // transform ghList to xList.
        Object instance = isH ? hInst : gInst;
        if (instance == null) {
            org.xms.g.utils.XmsLog.i("1", "instance : null");
            return null;
        }
        if (instance instanceof List) {
            org.xms.g.utils.XmsLog.i("2", "instance is List");
            return mapList2X((List) instance, isH);
        }

        if (!isXmsType(clazz)) {
            org.xms.g.utils.XmsLog.i("3", "instance : " + instance.getClass().getName());
            // maybe instance is GInstance or HInstance
            if (isH) { // HInstance
                return getXmsObjectWithHmsObject(instance);
            }
            // GInstance
            return getXmsObjectWithGmsObject(instance);
        }

        String className = "";
        if (clazz.isInterface() || Modifier.isAbstract(clazz.getModifiers())) {
            className = clazz.getName();
            className += "$XImpl";
            try {
                org.xms.g.utils.XmsLog.d("4", "className : " + className);
                clazz = Class.forName(className);
            } catch (ClassNotFoundException e) {
                org.xms.g.utils.XmsLog.e("5", e.getMessage(), e);
            }
        }

        Constructor constructor = getWrapperConstructor(clazz);
        if (constructor != null) {
            try {
                return constructor.newInstance(gInst, hInst);
            } catch (InstantiationException e) {
                org.xms.g.utils.XmsLog.e("6", e.getMessage(), e);
            } catch (IllegalAccessException e) {
                org.xms.g.utils.XmsLog.e("7", e.getMessage(), e);
            } catch (InvocationTargetException e) {
                org.xms.g.utils.XmsLog.e("8", e.getMessage(), e);
            }
        }

        return null;
    }

    /**
     * Find wrapper constructor for an xms class.
     *
     * @param xmsType, the class whose wrapper constructor need to be found.
     * @return xmsType's wrapper constructor.
     */
    public static Constructor getWrapperConstructor(Class xmsType) {
        if (wrapperCache.containsKey(xmsType)) {
            org.xms.g.utils.XmsLog.i("1", "wrapperCache.get(xmsType) xmsType : " + xmsType.getName());
            return wrapperCache.get(xmsType);
        }

        Constructor[] constructors = xmsType.getConstructors();
        for (int i = 0; i < constructors.length; i++) {
            if (constructors[i].getParameterTypes().length != 2) {
                continue;
            }

            if (map.containsKey(constructors[i].getParameterTypes()[0].getCanonicalName())) {
                wrapperCache.put(xmsType, constructors[i]);
                org.xms.g.utils.XmsLog.i("2",
                    "wrapperCache.put(xmsType, constructors[i]) xmsType : " + xmsType.getName());
                return constructors[i];
            } else {
                org.xms.g.utils.XmsLog.w("3",
                    "map not containsKey " + constructors[i].getParameterTypes()[0].getCanonicalName());
            }
        }

        return null;
    }

    /**
     * If an object is xms instance, get its G instance or H instance.
     * An xms object may be an XGettable instance, then it has a concrete g instance,
     * also, it may be an XInterface but not XGettable, we must call these methods
     * by reflection.
     *
     * @param o object to get its g instance.
     * @param isH show we need its g or h instance.
     * @return xms object's g/h instance.
     */
    public static <T> T getInstanceInInterface(Object o, boolean isH) {
        if (!(o instanceof XInterface)) {
            String inObjectType = o == null ? null : o.getClass().getName();
            org.xms.g.utils.XmsLog.i("1", "inObject : " + inObjectType);
            return (T) o;
        }

        if (o instanceof XGettable) {
            if (isH) {
                org.xms.g.utils.XmsLog.i("2", "hInstance : " + ((XGettable) o).getHInstance().getClass().getName());
                return (T) ((XGettable) o).getHInstance();
            } else {
                org.xms.g.utils.XmsLog.i("3", "gInstance : " + ((XGettable) o).getGInstance().getClass().getName());
                return (T) ((XGettable) o).getGInstance();
            }
        }

        // o must be an XInterface and not XGettable.
        return (T) reflectiveGetInstance(o, isH);
    }

    private static Object reflectiveGetInstance(Object o, boolean isH) {
        if (getGHInstCache.containsKey(o.getClass())) {
            org.xms.g.utils.XmsLog.i("1", "inObject : " + o.getClass());
            try {
                return getGHInstCache.get(o.getClass()).invoke(o);
            } catch (IllegalAccessException e) {
                org.xms.g.utils.XmsLog.i("2", "inObject : " + o.getClass(), e);
            } catch (InvocationTargetException e) {
                org.xms.g.utils.XmsLog.i("3", "inObject : " + o.getClass(), e);
            }
        }

        Method[] methods = o.getClass().getMethods();
        for (int i = 0; i < methods.length; i++) {
            if (methods[i].getParameterTypes().length > 0) {
                continue;
            }

            if (isH && (!methods[i].getName().startsWith("getHInstance"))) {
                continue;
            }

            if (!isH && (!methods[i].getName().startsWith("getGInstance"))) {
                continue;
            }

            org.xms.g.utils.XmsLog.i("2", "inObject : " + o.getClass() + ", methods[i] : " + methods[i].getName());
            getGHInstCache.put(o.getClass(), methods[i]);
            try {
                return methods[i].invoke(o);
            } catch (IllegalAccessException e) {
                org.xms.g.utils.XmsLog.e("3", e.getMessage(), e);
            } catch (InvocationTargetException e) {
                org.xms.g.utils.XmsLog.e("4", e.getMessage(), e);
            }
        }

        return null;
    }

    /**
     * Invoke the bridge method with the original parameter types.
     *
     * @param receiver the invoke target
     * @param methodName the method name
     * @param params parameters
     * @param paramTypes the declaration types of parameters (the upper bound type for the generic type)
     * @param isH HMS if true; GMS, otherwise
     * @return the return value
     * @throws IllegalStateException capsuling the real refection exception
     */
    public static Object invokeBridgeMethod(Object receiver, String methodName, Object[] params, Class[] paramTypes,
        boolean isH) throws IllegalStateException {
        if (params == null) {
            org.xms.g.utils.XmsLog.w("1", "params == null");
            throw new IllegalArgumentException("null params");
        }

        if (paramTypes == null) {
            org.xms.g.utils.XmsLog.w("2", "paramTypes == null");
            throw new IllegalArgumentException("null paramTypes");
        }

        if (params.length != paramTypes.length) {
            org.xms.g.utils.XmsLog.w("3", "params.length != paramTypes.length");
            throw new IllegalArgumentException("mismatched params and paramTypes");
        }

        Method bridgeMethod = BridgeMethodUtils.getBridgeMethod(receiver.getClass(), methodName, paramTypes);
        org.xms.g.utils.XmsLog.d("4", "get bridge method " + bridgeMethod.toString());
        Method bridgedMethod = BridgeMethodUtils.getBridgedMethod(bridgeMethod);
        org.xms.g.utils.XmsLog.d("4", "get bridged method " + bridgedMethod.toString());
        try {
            String bridgeMethodType = bridgeMethod.getName();
            String bridgedMethodMethodType = bridgedMethod.getName();
            org.xms.g.utils.XmsLog.d("4",
                "bridgeMethod : " + bridgeMethodType + ", bridgedMethod : " + bridgedMethodMethodType);
            Class<?>[] types = bridgedMethod.getParameterTypes();
            Object[] args = new Object[params.length];
            for (int i = 0; i < params.length; i++) {
                if (isH) {
                    args[i] = Utils.getOrCreateInstance(types[i], null, params[i], isH);
                } else {
                    args[i] = Utils.getOrCreateInstance(types[i], params[i], null, isH);
                }
            }
            org.xms.g.utils.XmsLog.i("5", "receiver : " + receiver.getClass().getName());
            if (args.length > 0) {
                StringBuffer argSb = new StringBuffer();
                for (int i = 0; i < args.length; i++) {
                    String argsType = args[i] == null ? null : args[i].getClass().getName();
                    argSb.append("args [" + i + "] : ").append(argsType).append(", ");
                }
                org.xms.g.utils.XmsLog.i("6", argSb.toString());
            }
            bridgedMethod.setAccessible(true);
            return bridgedMethod.invoke(receiver, args);
        } catch (Exception ex) {
            org.xms.g.utils.XmsLog.e("7", ex.getMessage(), ex);
            throw new IllegalStateException(ex);
        }
    }

    /**
     * handle invokeBridge method return value.
     * return value need type cast.
     *
     * @param receiver the invoke target
     * @param isH HMS if true; GMS, otherwise
     * @return the return value
     */
    public static Object handleInvokeBridgeReturnValue(Object receiver, boolean isH) {
        // not xms type
        if (!isXmsType(receiver.getClass())) {
            org.xms.g.utils.XmsLog.d("1", "receiver : " + receiver.getClass().getName());
            return receiver;
        }
        // gettable, use Gettable getGorHinstance
        if (receiver instanceof XGettable) {
            if (isH) {
                org.xms.g.utils.XmsLog.i("2",
                    "hInstance : " + ((XGettable) receiver).getHInstance().getClass().getName());
                return ((XGettable) receiver).getHInstance();
            }
            org.xms.g.utils.XmsLog.i("3", "gInstance : " + ((XGettable) receiver).getGInstance().getClass().getName());
            return ((XGettable) receiver).getGInstance();
        }
        // interface, invoke default getHorGInstance method
        Method[] methods = receiver.getClass().getMethods();
        int cnt = 0;
        String prefix = isH ? "getHInstance" : "getGInstance";
        Method target = null;
        for (Method m : methods) {
            if (m.getName().startsWith(prefix)) {
                cnt++;
                target = m;
            }
        }
        if (cnt == 1) {
            try {
                org.xms.g.utils.XmsLog.i("4", "receiver : " + receiver.getClass().getName());
                return target.invoke(receiver);
            } catch (IllegalAccessException e) {
                org.xms.g.utils.XmsLog.e("5", e.getMessage(), e);
            } catch (InvocationTargetException e) {
                org.xms.g.utils.XmsLog.e("6", e.getMessage(), e);
            }
        }
        IllegalStateException illegalStateException = new IllegalStateException("mutiple getInstance methods found.");
        org.xms.g.utils.XmsLog.w("7", illegalStateException.getMessage());
        throw illegalStateException;
    }

    public static Object invokeProtectMethod(Object receiver, Class targetClass, String methodName,
        Class[] methodParametersType, Object[] args) {
        if (targetClass == null) {
            throw new IllegalStateException("null class.");
        }
        if (methodName == null || methodName.isEmpty()) {
            throw new IllegalStateException("methodName not exist.");
        }
        try {
            Method method = null;
            method = targetClass.getDeclaredMethod(methodName, methodParametersType);
            assert method != null;
            method.setAccessible(true);
            return method.invoke(receiver, args);
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (InvocationTargetException e) {
            e.printStackTrace();
        } catch (NoSuchMethodException e) {
            e.printStackTrace();
        }
        return null;
    }

    static {
        map.put("com.google.firebase.FirebaseApiNotAvailableException", "org.xms.f.FirebaseApiNotAvailableException");
        map.put("com.google.firebase.FirebaseException", "org.xms.f.FirebaseException");
        map.put("com.google.android.gms.actions.ItemListIntents", "org.xms.g.actions.ItemListIntents");
        map.put("com.google.android.gms.actions.NoteIntents", "org.xms.g.actions.NoteIntents");
        map.put("com.google.android.gms.actions.ReserveIntents", "org.xms.g.actions.ReserveIntents");
        map.put("com.google.android.gms.actions.SearchIntents", "org.xms.g.actions.SearchIntents");
        map.put("com.huawei.hms.actions.SearchIntents", "org.xms.g.actions.SearchIntents");
        map.put("com.google.android.gms.common.AccountPicker", "org.xms.g.common.AccountPicker");
        map.put("com.google.android.gms.common.AccountPicker.AccountChooserOptions", "org.xms.g.common.AccountPicker$AccountChooserOptions");
        map.put("com.google.android.gms.common.AccountPicker.AccountChooserOptions.Builder", "org.xms.g.common.AccountPicker$AccountChooserOptions$Builder");
        map.put("com.google.android.gms.common.ConnectionResult", "org.xms.g.common.ConnectionResult");
        map.put("com.huawei.hms.api.ConnectionResult", "org.xms.g.common.ConnectionResult");
        map.put("com.google.android.gms.common.ErrorDialogFragment", "org.xms.g.common.ErrorDialogFragment");
        map.put("com.huawei.hms.common.ErrorDialogFragment", "org.xms.g.common.ErrorDialogFragment");
        map.put("com.google.android.gms.common.GoogleApiAvailability", "org.xms.g.common.ExtensionApiAvailability");
        map.put("com.huawei.hms.api.HuaweiApiAvailability", "org.xms.g.common.ExtensionApiAvailability");
        map.put("com.google.android.gms.common.GooglePlayServicesNotAvailableException", "org.xms.g.common.ExtensionPlayServicesNotAvailableException");
        map.put("com.huawei.hms.api.HuaweiServicesNotAvailableException", "org.xms.g.common.ExtensionPlayServicesNotAvailableException");
        map.put("com.google.android.gms.common.GooglePlayServicesRepairableException", "org.xms.g.common.ExtensionPlayServicesRepairableException");
        map.put("com.huawei.hms.api.HuaweiServicesRepairableException", "org.xms.g.common.ExtensionPlayServicesRepairableException");
        map.put("com.google.android.gms.common.GooglePlayServicesUtil", "org.xms.g.common.ExtensionPlayServicesUtil");
        map.put("com.huawei.hms.api.HuaweiMobileServicesUtil", "org.xms.g.common.ExtensionPlayServicesUtil");
        map.put("com.google.android.gms.common.Scopes", "org.xms.g.common.Scopes");
        map.put("com.google.android.gms.common.SupportErrorDialogFragment", "org.xms.g.common.SupportErrorDialogFragment");
        map.put("com.huawei.hms.common.ErrDlgFragmentForSupport", "org.xms.g.common.SupportErrorDialogFragment");
        map.put("com.google.android.gms.common.UserRecoverableException", "org.xms.g.common.UserRecoverableException");
        map.put("com.huawei.hms.api.UserRecoverableException", "org.xms.g.common.UserRecoverableException");
        map.put("com.google.android.gms.common.api.Api", "org.xms.g.common.api.Api");
        map.put("com.huawei.hms.api.Api", "org.xms.g.common.api.Api");
        map.put("com.google.android.gms.common.api.Api.ApiOptions.HasOptions", "org.xms.g.common.api.Api$ApiOptions$HasOptions$XImpl");
        map.put("com.huawei.hms.api.Api.ApiOptions.HasOptions", "org.xms.g.common.api.Api$ApiOptions$HasOptions$XImpl");
        map.put("com.google.android.gms.common.api.Api.ApiOptions.NoOptions", "org.xms.g.common.api.Api$ApiOptions$NoOptions");
        map.put("com.huawei.hms.api.Api.ApiOptions.NoOptions", "org.xms.g.common.api.Api$ApiOptions$NoOptions");
        map.put("com.google.android.gms.common.api.Api.ApiOptions.NotRequiredOptions", "org.xms.g.common.api.Api$ApiOptions$NotRequiredOptions$XImpl");
        map.put("com.huawei.hms.api.Api.ApiOptions.NotRequiredOptions", "org.xms.g.common.api.Api$ApiOptions$NotRequiredOptions$XImpl");
        map.put("com.google.android.gms.common.api.Api.ApiOptions.Optional", "org.xms.g.common.api.Api$ApiOptions$Optional$XImpl");
        map.put("com.huawei.hms.api.Api.ApiOptions.Optional", "org.xms.g.common.api.Api$ApiOptions$Optional$XImpl");
        map.put("com.google.android.gms.common.api.Api.ApiOptions", "org.xms.g.common.api.Api$ApiOptions$XImpl");
        map.put("com.huawei.hms.api.Api.ApiOptions", "org.xms.g.common.api.Api$ApiOptions$XImpl");
        map.put("com.google.android.gms.common.api.ApiException", "org.xms.g.common.api.ApiException");
        map.put("com.huawei.hms.common.ApiException", "org.xms.g.common.api.ApiException");
        map.put("com.google.android.gms.common.api.AvailabilityException", "org.xms.g.common.api.AvailabilityException");
        map.put("com.huawei.hms.common.api.AvailabilityException", "org.xms.g.common.api.AvailabilityException");
        map.put("com.google.android.gms.common.api.Batch", "org.xms.g.common.api.Batch");
        map.put("com.google.android.gms.common.api.Batch.Builder", "org.xms.g.common.api.Batch$Builder");
        map.put("com.google.android.gms.common.api.BatchResult", "org.xms.g.common.api.BatchResult");
        map.put("com.google.android.gms.common.api.BatchResultToken", "org.xms.g.common.api.BatchResultToken");
        map.put("com.google.android.gms.common.api.BooleanResult", "org.xms.g.common.api.BooleanResult");
        map.put("com.huawei.hms.common.api.BooleanResult", "org.xms.g.common.api.BooleanResult");
        map.put("com.google.android.gms.common.api.CommonStatusCodes", "org.xms.g.common.api.CommonStatusCodes");
        map.put("com.huawei.hms.common.api.CommonStatusCodes", "org.xms.g.common.api.CommonStatusCodes");
        map.put("com.google.android.gms.common.api.GoogleApi", "org.xms.g.common.api.ExtensionApi$XImpl");
        map.put("com.google.android.gms.common.api.GoogleApiClient.Builder", "org.xms.g.common.api.ExtensionApiClient$Builder");
        map.put("com.huawei.hms.api.HuaweiApiClient.Builder", "org.xms.g.common.api.ExtensionApiClient$Builder");
        map.put("com.google.android.gms.common.api.GoogleApiClient.ConnectionCallbacks", "org.xms.g.common.api.ExtensionApiClient$ConnectionCallbacks$XImpl");
        map.put("com.huawei.hms.api.HuaweiApiClient.ConnectionCallbacks", "org.xms.g.common.api.ExtensionApiClient$ConnectionCallbacks$XImpl");
        map.put("com.google.android.gms.common.api.GoogleApiClient.OnConnectionFailedListener", "org.xms.g.common.api.ExtensionApiClient$OnConnectionFailedListener$XImpl");
        map.put("com.huawei.hms.api.HuaweiApiClient.OnConnectionFailedListener", "org.xms.g.common.api.ExtensionApiClient$OnConnectionFailedListener$XImpl");
        map.put("com.google.android.gms.common.api.GoogleApiClient", "org.xms.g.common.api.ExtensionApiClient$XImpl");
        map.put("com.huawei.hms.api.HuaweiApiClient", "org.xms.g.common.api.ExtensionApiClient$XImpl");
        map.put("com.google.android.gms.common.api.HasApiKey", "org.xms.g.common.api.HasApiKey$XImpl");
        map.put("com.google.android.gms.common.api.OptionalPendingResult", "org.xms.g.common.api.OptionalPendingResult$XImpl");
        map.put("com.huawei.hms.common.api.OptionalPendingResult", "org.xms.g.common.api.OptionalPendingResult$XImpl");
        map.put("com.google.android.gms.common.api.PendingResult", "org.xms.g.common.api.PendingResult$XImpl");
        map.put("com.huawei.hms.support.api.client.PendingResult", "org.xms.g.common.api.PendingResult$XImpl");
        map.put("com.google.android.gms.common.api.PendingResults", "org.xms.g.common.api.PendingResults");
        map.put("com.huawei.hms.support.api.client.PendingResultsCreator", "org.xms.g.common.api.PendingResults");
        map.put("com.google.android.gms.common.api.Releasable", "org.xms.g.common.api.Releasable$XImpl");
        map.put("com.huawei.hms.common.api.Releasable", "org.xms.g.common.api.Releasable$XImpl");
        map.put("com.google.android.gms.common.api.ResolvableApiException", "org.xms.g.common.api.ResolvableApiException");
        map.put("com.huawei.hms.common.ResolvableApiException", "org.xms.g.common.api.ResolvableApiException");
        map.put("com.google.android.gms.common.api.ResolvingResultCallbacks", "org.xms.g.common.api.ResolvingResultCallbacks$XImpl");
        map.put("com.huawei.hms.support.api.client.ResolvingResultCallbacks", "org.xms.g.common.api.ResolvingResultCallbacks$XImpl");
        map.put("com.google.android.gms.common.api.Response", "org.xms.g.common.api.Response");
        map.put("com.huawei.hms.common.api.Response", "org.xms.g.common.api.Response");
        map.put("com.google.android.gms.common.api.Result", "org.xms.g.common.api.Result$XImpl");
        map.put("com.huawei.hms.support.api.client.Result", "org.xms.g.common.api.Result$XImpl");
        map.put("com.google.android.gms.common.api.ResultCallback", "org.xms.g.common.api.ResultCallback$XImpl");
        map.put("com.huawei.hms.support.api.client.ResultCallback", "org.xms.g.common.api.ResultCallback$XImpl");
        map.put("com.google.android.gms.common.api.ResultCallbacks", "org.xms.g.common.api.ResultCallbacks$XImpl");
        map.put("com.huawei.hms.support.api.client.ResultCallbacks", "org.xms.g.common.api.ResultCallbacks$XImpl");
        map.put("com.google.android.gms.common.api.ResultTransform", "org.xms.g.common.api.ResultTransform$XImpl");
        map.put("com.huawei.hms.support.api.client.ResultConvert", "org.xms.g.common.api.ResultTransform$XImpl");
        map.put("com.google.android.gms.common.api.Scope", "org.xms.g.common.api.Scope");
        map.put("com.huawei.hms.support.api.entity.auth.Scope", "org.xms.g.common.api.Scope");
        map.put("com.google.android.gms.common.api.Status", "org.xms.g.common.api.Status");
        map.put("com.huawei.hms.support.api.client.Status", "org.xms.g.common.api.Status");
        map.put("com.google.android.gms.common.api.TransformedResult", "org.xms.g.common.api.TransformedResult$XImpl");
        map.put("com.huawei.hms.support.api.client.ConvertedResult", "org.xms.g.common.api.TransformedResult$XImpl");
        map.put("com.google.android.gms.common.api.UnsupportedApiCallException", "org.xms.g.common.api.UnsupportedApiCallException");
        map.put("com.huawei.hms.common.api.UnsupportedApiCallException", "org.xms.g.common.api.UnsupportedApiCallException");
        map.put("com.google.android.gms.common.data.AbstractDataBuffer", "org.xms.g.common.data.AbstractDataBuffer$XImpl");
        map.put("com.huawei.hms.common.data.AbstractDataBuffer", "org.xms.g.common.data.AbstractDataBuffer$XImpl");
        map.put("com.google.android.gms.common.data.DataBuffer", "org.xms.g.common.data.DataBuffer$XImpl");
        map.put("com.huawei.hms.common.data.DataBuffer", "org.xms.g.common.data.DataBuffer$XImpl");
        map.put("com.google.android.gms.common.data.DataBufferObserver.Observable", "org.xms.g.common.data.DataBufferObserver$Observable$XImpl");
        map.put("com.google.android.gms.common.data.DataBufferObserver", "org.xms.g.common.data.DataBufferObserver$XImpl");
        map.put("com.huawei.hms.common.data.DataBufferObserver", "org.xms.g.common.data.DataBufferObserver$XImpl");
        map.put("com.google.android.gms.common.data.DataBufferObserverSet", "org.xms.g.common.data.DataBufferObserverSet");
        map.put("com.google.android.gms.common.data.DataBufferUtils", "org.xms.g.common.data.DataBufferUtils");
        map.put("com.huawei.hms.common.data.DataBufferUtils", "org.xms.g.common.data.DataBufferUtils");
        map.put("com.google.android.gms.common.data.Freezable", "org.xms.g.common.data.Freezable$XImpl");
        map.put("com.huawei.hms.common.data.Freezable", "org.xms.g.common.data.Freezable$XImpl");
        map.put("com.google.android.gms.common.data.FreezableUtils", "org.xms.g.common.data.FreezableUtils");
        map.put("com.huawei.hms.common.data.FreezableUtils", "org.xms.g.common.data.FreezableUtils");
        map.put("com.google.android.gms.common.images.ImageManager", "org.xms.g.common.images.ImageManager");
        map.put("com.google.android.gms.common.images.ImageManager.OnImageLoadedListener", "org.xms.g.common.images.ImageManager$OnImageLoadedListener$XImpl");
        map.put("com.google.android.gms.common.images.Size", "org.xms.g.common.images.Size");
        map.put("com.huawei.hms.common.size.Size", "org.xms.g.common.images.Size");
        map.put("com.google.android.gms.common.images.WebImage", "org.xms.g.common.images.WebImage");
        map.put("com.huawei.hms.common.webserverpic.WebServerPic", "org.xms.g.common.images.WebImage");
        map.put("com.google.android.gms.security.ProviderInstaller", "org.xms.g.security.ProviderInstaller");
        map.put("com.huawei.hms.security.SecComponentInstallWizard", "org.xms.g.security.ProviderInstaller");
        map.put("com.google.android.gms.security.ProviderInstaller.ProviderInstallListener", "org.xms.g.security.ProviderInstaller$ProviderInstallListener$XImpl");
        map.put("com.huawei.hms.security.SecComponentInstallWizard.SecComponentInstallWizardListener", "org.xms.g.security.ProviderInstaller$ProviderInstallListener$XImpl");
        map.put("com.google.android.gms.tasks.CancellationToken", "org.xms.g.tasks.CancellationToken$XImpl");
        map.put("com.huawei.hmf.tasks.CancellationToken", "org.xms.g.tasks.CancellationToken$XImpl");
        map.put("com.google.android.gms.tasks.CancellationTokenSource", "org.xms.g.tasks.CancellationTokenSource");
        map.put("com.huawei.hmf.tasks.CancellationTokenSource", "org.xms.g.tasks.CancellationTokenSource");
        map.put("com.google.android.gms.tasks.Continuation", "org.xms.g.tasks.Continuation$XImpl");
        map.put("com.huawei.hmf.tasks.Continuation", "org.xms.g.tasks.Continuation$XImpl");
        map.put("com.google.android.gms.tasks.OnCanceledListener", "org.xms.g.tasks.OnCanceledListener$XImpl");
        map.put("com.huawei.hmf.tasks.OnCanceledListener", "org.xms.g.tasks.OnCanceledListener$XImpl");
        map.put("com.google.android.gms.tasks.OnCompleteListener", "org.xms.g.tasks.OnCompleteListener$XImpl");
        map.put("com.huawei.hmf.tasks.OnCompleteListener", "org.xms.g.tasks.OnCompleteListener$XImpl");
        map.put("com.google.android.gms.tasks.OnFailureListener", "org.xms.g.tasks.OnFailureListener$XImpl");
        map.put("com.huawei.hmf.tasks.OnFailureListener", "org.xms.g.tasks.OnFailureListener$XImpl");
        map.put("com.google.android.gms.tasks.OnSuccessListener", "org.xms.g.tasks.OnSuccessListener$XImpl");
        map.put("com.huawei.hmf.tasks.OnSuccessListener", "org.xms.g.tasks.OnSuccessListener$XImpl");
        map.put("com.google.android.gms.tasks.OnTokenCanceledListener", "org.xms.g.tasks.OnTokenCanceledListener$XImpl");
        map.put("com.google.android.gms.tasks.RuntimeExecutionException", "org.xms.g.tasks.RuntimeExecutionException");
        map.put("com.google.android.gms.tasks.SuccessContinuation", "org.xms.g.tasks.SuccessContinuation$XImpl");
        map.put("com.huawei.hmf.tasks.SuccessContinuation", "org.xms.g.tasks.SuccessContinuation$XImpl");
        map.put("com.google.android.gms.tasks.Task", "org.xms.g.tasks.Task$XImpl");
        map.put("com.huawei.hmf.tasks.Task", "org.xms.g.tasks.Task$XImpl");
        map.put("com.google.android.gms.tasks.TaskCompletionSource", "org.xms.g.tasks.TaskCompletionSource");
        map.put("com.huawei.hmf.tasks.TaskCompletionSource", "org.xms.g.tasks.TaskCompletionSource");
        map.put("com.google.android.gms.tasks.TaskExecutors", "org.xms.g.tasks.TaskExecutors");
        map.put("com.google.android.gms.tasks.Tasks", "org.xms.g.tasks.Tasks");
        map.put("com.huawei.hmf.tasks.Tasks", "org.xms.g.tasks.Tasks");
        G2H.put("com.google.android.gms.actions.SearchIntents", "com.huawei.hms.actions.SearchIntents");
        G2H.put("com.google.android.gms.common.ConnectionResult", "com.huawei.hms.api.ConnectionResult");
        G2H.put("com.google.android.gms.common.ErrorDialogFragment", "com.huawei.hms.common.ErrorDialogFragment");
        G2H.put("com.google.android.gms.common.GoogleApiAvailability", "com.huawei.hms.api.HuaweiApiAvailability");
        G2H.put("com.google.android.gms.common.GooglePlayServicesNotAvailableException", "com.huawei.hms.api.HuaweiServicesNotAvailableException");
        G2H.put("com.google.android.gms.common.GooglePlayServicesRepairableException", "com.huawei.hms.api.HuaweiServicesRepairableException");
        G2H.put("com.google.android.gms.common.GooglePlayServicesUtil", "com.huawei.hms.api.HuaweiMobileServicesUtil");
        G2H.put("com.google.android.gms.common.SupportErrorDialogFragment", "com.huawei.hms.common.ErrDlgFragmentForSupport");
        G2H.put("com.google.android.gms.common.UserRecoverableException", "com.huawei.hms.api.UserRecoverableException");
        G2H.put("com.google.android.gms.common.api.Api", "com.huawei.hms.api.Api");
        G2H.put("com.google.android.gms.common.api.Api.ApiOptions.HasOptions", "com.huawei.hms.api.Api.ApiOptions.HasOptions");
        G2H.put("com.google.android.gms.common.api.Api.ApiOptions.NoOptions", "com.huawei.hms.api.Api.ApiOptions.NoOptions");
        G2H.put("com.google.android.gms.common.api.Api.ApiOptions.NotRequiredOptions", "com.huawei.hms.api.Api.ApiOptions.NotRequiredOptions");
        G2H.put("com.google.android.gms.common.api.Api.ApiOptions.Optional", "com.huawei.hms.api.Api.ApiOptions.Optional");
        G2H.put("com.google.android.gms.common.api.Api.ApiOptions", "com.huawei.hms.api.Api.ApiOptions");
        G2H.put("com.google.android.gms.common.api.ApiException", "com.huawei.hms.common.ApiException");
        G2H.put("com.google.android.gms.common.api.AvailabilityException", "com.huawei.hms.common.api.AvailabilityException");
        G2H.put("com.google.android.gms.common.api.BooleanResult", "com.huawei.hms.common.api.BooleanResult");
        G2H.put("com.google.android.gms.common.api.CommonStatusCodes", "com.huawei.hms.common.api.CommonStatusCodes");
        G2H.put("com.google.android.gms.common.api.GoogleApiClient.Builder", "com.huawei.hms.api.HuaweiApiClient.Builder");
        G2H.put("com.google.android.gms.common.api.GoogleApiClient.ConnectionCallbacks", "com.huawei.hms.api.HuaweiApiClient.ConnectionCallbacks");
        G2H.put("com.google.android.gms.common.api.GoogleApiClient.OnConnectionFailedListener", "com.huawei.hms.api.HuaweiApiClient.OnConnectionFailedListener");
        G2H.put("com.google.android.gms.common.api.GoogleApiClient", "com.huawei.hms.api.HuaweiApiClient");
        G2H.put("com.google.android.gms.common.api.OptionalPendingResult", "com.huawei.hms.common.api.OptionalPendingResult");
        G2H.put("com.google.android.gms.common.api.PendingResult", "com.huawei.hms.support.api.client.PendingResult");
        G2H.put("com.google.android.gms.common.api.PendingResults", "com.huawei.hms.support.api.client.PendingResultsCreator");
        G2H.put("com.google.android.gms.common.api.Releasable", "com.huawei.hms.common.api.Releasable");
        G2H.put("com.google.android.gms.common.api.ResolvableApiException", "com.huawei.hms.common.ResolvableApiException");
        G2H.put("com.google.android.gms.common.api.ResolvingResultCallbacks", "com.huawei.hms.support.api.client.ResolvingResultCallbacks");
        G2H.put("com.google.android.gms.common.api.Response", "com.huawei.hms.common.api.Response");
        G2H.put("com.google.android.gms.common.api.Result", "com.huawei.hms.support.api.client.Result");
        G2H.put("com.google.android.gms.common.api.ResultCallback", "com.huawei.hms.support.api.client.ResultCallback");
        G2H.put("com.google.android.gms.common.api.ResultCallbacks", "com.huawei.hms.support.api.client.ResultCallbacks");
        G2H.put("com.google.android.gms.common.api.ResultTransform", "com.huawei.hms.support.api.client.ResultConvert");
        G2H.put("com.google.android.gms.common.api.Scope", "com.huawei.hms.support.api.entity.auth.Scope");
        G2H.put("com.google.android.gms.common.api.Status", "com.huawei.hms.support.api.client.Status");
        G2H.put("com.google.android.gms.common.api.TransformedResult", "com.huawei.hms.support.api.client.ConvertedResult");
        G2H.put("com.google.android.gms.common.api.UnsupportedApiCallException", "com.huawei.hms.common.api.UnsupportedApiCallException");
        G2H.put("com.google.android.gms.common.data.AbstractDataBuffer", "com.huawei.hms.common.data.AbstractDataBuffer");
        G2H.put("com.google.android.gms.common.data.DataBuffer", "com.huawei.hms.common.data.DataBuffer");
        G2H.put("com.google.android.gms.common.data.DataBufferObserver", "com.huawei.hms.common.data.DataBufferObserver");
        G2H.put("com.google.android.gms.common.data.DataBufferUtils", "com.huawei.hms.common.data.DataBufferUtils");
        G2H.put("com.google.android.gms.common.data.Freezable", "com.huawei.hms.common.data.Freezable");
        G2H.put("com.google.android.gms.common.data.FreezableUtils", "com.huawei.hms.common.data.FreezableUtils");
        G2H.put("com.google.android.gms.common.images.Size", "com.huawei.hms.common.size.Size");
        G2H.put("com.google.android.gms.common.images.WebImage", "com.huawei.hms.common.webserverpic.WebServerPic");
        G2H.put("com.google.android.gms.security.ProviderInstaller", "com.huawei.hms.security.SecComponentInstallWizard");
        G2H.put("com.google.android.gms.security.ProviderInstaller.ProviderInstallListener", "com.huawei.hms.security.SecComponentInstallWizard.SecComponentInstallWizardListener");
        G2H.put("com.google.android.gms.tasks.CancellationToken", "com.huawei.hmf.tasks.CancellationToken");
        G2H.put("com.google.android.gms.tasks.CancellationTokenSource", "com.huawei.hmf.tasks.CancellationTokenSource");
        G2H.put("com.google.android.gms.tasks.Continuation", "com.huawei.hmf.tasks.Continuation");
        G2H.put("com.google.android.gms.tasks.OnCanceledListener", "com.huawei.hmf.tasks.OnCanceledListener");
        G2H.put("com.google.android.gms.tasks.OnCompleteListener", "com.huawei.hmf.tasks.OnCompleteListener");
        G2H.put("com.google.android.gms.tasks.OnFailureListener", "com.huawei.hmf.tasks.OnFailureListener");
        G2H.put("com.google.android.gms.tasks.OnSuccessListener", "com.huawei.hmf.tasks.OnSuccessListener");
        G2H.put("com.google.android.gms.tasks.SuccessContinuation", "com.huawei.hmf.tasks.SuccessContinuation");
        G2H.put("com.google.android.gms.tasks.Task", "com.huawei.hmf.tasks.Task");
        G2H.put("com.google.android.gms.tasks.TaskCompletionSource", "com.huawei.hmf.tasks.TaskCompletionSource");
        G2H.put("com.google.android.gms.tasks.Tasks", "com.huawei.hmf.tasks.Tasks");
        H2G.put("com.huawei.hms.actions.SearchIntents", "com.google.android.gms.actions.SearchIntents");
        H2G.put("com.huawei.hms.api.ConnectionResult", "com.google.android.gms.common.ConnectionResult");
        H2G.put("com.huawei.hms.common.ErrorDialogFragment", "com.google.android.gms.common.ErrorDialogFragment");
        H2G.put("com.huawei.hms.api.HuaweiApiAvailability", "com.google.android.gms.common.GoogleApiAvailability");
        H2G.put("com.huawei.hms.api.HuaweiServicesNotAvailableException", "com.google.android.gms.common.GooglePlayServicesNotAvailableException");
        H2G.put("com.huawei.hms.api.HuaweiServicesRepairableException", "com.google.android.gms.common.GooglePlayServicesRepairableException");
        H2G.put("com.huawei.hms.api.HuaweiMobileServicesUtil", "com.google.android.gms.common.GooglePlayServicesUtil");
        H2G.put("com.huawei.hms.common.ErrDlgFragmentForSupport", "com.google.android.gms.common.SupportErrorDialogFragment");
        H2G.put("com.huawei.hms.api.UserRecoverableException", "com.google.android.gms.common.UserRecoverableException");
        H2G.put("com.huawei.hms.api.Api", "com.google.android.gms.common.api.Api");
        H2G.put("com.huawei.hms.api.Api.ApiOptions.HasOptions", "com.google.android.gms.common.api.Api.ApiOptions.HasOptions");
        H2G.put("com.huawei.hms.api.Api.ApiOptions.NoOptions", "com.google.android.gms.common.api.Api.ApiOptions.NoOptions");
        H2G.put("com.huawei.hms.api.Api.ApiOptions.NotRequiredOptions", "com.google.android.gms.common.api.Api.ApiOptions.NotRequiredOptions");
        H2G.put("com.huawei.hms.api.Api.ApiOptions.Optional", "com.google.android.gms.common.api.Api.ApiOptions.Optional");
        H2G.put("com.huawei.hms.api.Api.ApiOptions", "com.google.android.gms.common.api.Api.ApiOptions");
        H2G.put("com.huawei.hms.common.ApiException", "com.google.android.gms.common.api.ApiException");
        H2G.put("com.huawei.hms.common.api.AvailabilityException", "com.google.android.gms.common.api.AvailabilityException");
        H2G.put("com.huawei.hms.common.api.BooleanResult", "com.google.android.gms.common.api.BooleanResult");
        H2G.put("com.huawei.hms.common.api.CommonStatusCodes", "com.google.android.gms.common.api.CommonStatusCodes");
        H2G.put("com.huawei.hms.api.HuaweiApiClient.Builder", "com.google.android.gms.common.api.GoogleApiClient.Builder");
        H2G.put("com.huawei.hms.api.HuaweiApiClient.ConnectionCallbacks", "com.google.android.gms.common.api.GoogleApiClient.ConnectionCallbacks");
        H2G.put("com.huawei.hms.api.HuaweiApiClient.OnConnectionFailedListener", "com.google.android.gms.common.api.GoogleApiClient.OnConnectionFailedListener");
        H2G.put("com.huawei.hms.api.HuaweiApiClient", "com.google.android.gms.common.api.GoogleApiClient");
        H2G.put("com.huawei.hms.common.api.OptionalPendingResult", "com.google.android.gms.common.api.OptionalPendingResult");
        H2G.put("com.huawei.hms.support.api.client.PendingResult", "com.google.android.gms.common.api.PendingResult");
        H2G.put("com.huawei.hms.support.api.client.PendingResultsCreator", "com.google.android.gms.common.api.PendingResults");
        H2G.put("com.huawei.hms.common.api.Releasable", "com.google.android.gms.common.api.Releasable");
        H2G.put("com.huawei.hms.common.ResolvableApiException", "com.google.android.gms.common.api.ResolvableApiException");
        H2G.put("com.huawei.hms.support.api.client.ResolvingResultCallbacks", "com.google.android.gms.common.api.ResolvingResultCallbacks");
        H2G.put("com.huawei.hms.common.api.Response", "com.google.android.gms.common.api.Response");
        H2G.put("com.huawei.hms.support.api.client.Result", "com.google.android.gms.common.api.Result");
        H2G.put("com.huawei.hms.support.api.client.ResultCallback", "com.google.android.gms.common.api.ResultCallback");
        H2G.put("com.huawei.hms.support.api.client.ResultCallbacks", "com.google.android.gms.common.api.ResultCallbacks");
        H2G.put("com.huawei.hms.support.api.client.ResultConvert", "com.google.android.gms.common.api.ResultTransform");
        H2G.put("com.huawei.hms.support.api.entity.auth.Scope", "com.google.android.gms.common.api.Scope");
        H2G.put("com.huawei.hms.support.api.client.Status", "com.google.android.gms.common.api.Status");
        H2G.put("com.huawei.hms.support.api.client.ConvertedResult", "com.google.android.gms.common.api.TransformedResult");
        H2G.put("com.huawei.hms.common.api.UnsupportedApiCallException", "com.google.android.gms.common.api.UnsupportedApiCallException");
        H2G.put("com.huawei.hms.common.data.AbstractDataBuffer", "com.google.android.gms.common.data.AbstractDataBuffer");
        H2G.put("com.huawei.hms.common.data.DataBuffer", "com.google.android.gms.common.data.DataBuffer");
        H2G.put("com.huawei.hms.common.data.DataBufferObserver", "com.google.android.gms.common.data.DataBufferObserver");
        H2G.put("com.huawei.hms.common.data.DataBufferUtils", "com.google.android.gms.common.data.DataBufferUtils");
        H2G.put("com.huawei.hms.common.data.Freezable", "com.google.android.gms.common.data.Freezable");
        H2G.put("com.huawei.hms.common.data.FreezableUtils", "com.google.android.gms.common.data.FreezableUtils");
        H2G.put("com.huawei.hms.common.size.Size", "com.google.android.gms.common.images.Size");
        H2G.put("com.huawei.hms.common.webserverpic.WebServerPic", "com.google.android.gms.common.images.WebImage");
        H2G.put("com.huawei.hms.security.SecComponentInstallWizard", "com.google.android.gms.security.ProviderInstaller");
        H2G.put("com.huawei.hms.security.SecComponentInstallWizard.SecComponentInstallWizardListener", "com.google.android.gms.security.ProviderInstaller.ProviderInstallListener");
        H2G.put("com.huawei.hmf.tasks.CancellationToken", "com.google.android.gms.tasks.CancellationToken");
        H2G.put("com.huawei.hmf.tasks.CancellationTokenSource", "com.google.android.gms.tasks.CancellationTokenSource");
        H2G.put("com.huawei.hmf.tasks.Continuation", "com.google.android.gms.tasks.Continuation");
        H2G.put("com.huawei.hmf.tasks.OnCanceledListener", "com.google.android.gms.tasks.OnCanceledListener");
        H2G.put("com.huawei.hmf.tasks.OnCompleteListener", "com.google.android.gms.tasks.OnCompleteListener");
        H2G.put("com.huawei.hmf.tasks.OnFailureListener", "com.google.android.gms.tasks.OnFailureListener");
        H2G.put("com.huawei.hmf.tasks.OnSuccessListener", "com.google.android.gms.tasks.OnSuccessListener");
        H2G.put("com.huawei.hmf.tasks.SuccessContinuation", "com.google.android.gms.tasks.SuccessContinuation");
        H2G.put("com.huawei.hmf.tasks.Task", "com.google.android.gms.tasks.Task");
        H2G.put("com.huawei.hmf.tasks.TaskCompletionSource", "com.google.android.gms.tasks.TaskCompletionSource");
        H2G.put("com.huawei.hmf.tasks.Tasks", "com.google.android.gms.tasks.Tasks");
    }
}
