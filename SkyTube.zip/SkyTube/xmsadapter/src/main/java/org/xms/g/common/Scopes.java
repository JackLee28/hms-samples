package org.xms.g.common;

public final class Scopes extends org.xms.g.utils.XObject {
    
    public Scopes(com.google.android.gms.common.Scopes param0, java.lang.Object param1) {
        super(param0, null);
    }
    
    public static java.lang.String getAPP_STATE() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static java.lang.String getCLOUD_SAVE() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static java.lang.String getDRIVE_APPFOLDER() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static java.lang.String getDRIVE_FILE() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static java.lang.String getEMAIL() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static java.lang.String getFITNESS_ACTIVITY_READ() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static java.lang.String getFITNESS_ACTIVITY_READ_WRITE() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static java.lang.String getFITNESS_BODY_READ() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static java.lang.String getFITNESS_BODY_READ_WRITE() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static java.lang.String getFITNESS_LOCATION_READ() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static java.lang.String getFITNESS_LOCATION_READ_WRITE() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static java.lang.String getFITNESS_NUTRITION_READ() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static java.lang.String getFITNESS_NUTRITION_READ_WRITE() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static java.lang.String getGAMES() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static java.lang.String getPLUS_LOGIN() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static java.lang.String getPLUS_ME() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static java.lang.String getPROFILE() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static org.xms.g.common.Scopes dynamicCast(java.lang.Object param0) {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static boolean isInstance(java.lang.Object param0) {
        throw new java.lang.RuntimeException("Not Supported");
    }
}