package org.xms.g.common;

public final class AccountPicker extends org.xms.g.utils.XObject {
    
    public AccountPicker(com.google.android.gms.common.AccountPicker param0, java.lang.Object param1) {
        super(param0, null);
    }
    
    public static android.content.Intent newChooseAccountIntent(org.xms.g.common.AccountPicker.AccountChooserOptions param0) {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static android.content.Intent newChooseAccountIntent(android.accounts.Account param0, java.util.ArrayList param1, java.lang.String[] param2, boolean param3, java.lang.String param4, java.lang.String param5, java.lang.String[] param6, android.os.Bundle param7) {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static org.xms.g.common.AccountPicker dynamicCast(java.lang.Object param0) {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static boolean isInstance(java.lang.Object param0) {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static class AccountChooserOptions extends org.xms.g.utils.XObject {
        
        public AccountChooserOptions(com.google.android.gms.common.AccountPicker.AccountChooserOptions param0, java.lang.Object param1) {
            super(param0, null);
        }
        
        public AccountChooserOptions() {
            super(((com.google.android.gms.common.AccountPicker.AccountChooserOptions) null), null);
        }
        
        public static org.xms.g.common.AccountPicker.AccountChooserOptions dynamicCast(java.lang.Object param0) {
            throw new java.lang.RuntimeException("Not Supported");
        }
        
        public static boolean isInstance(java.lang.Object param0) {
            throw new java.lang.RuntimeException("Not Supported");
        }
        
        public static class Builder extends org.xms.g.utils.XObject {
            
            public Builder(com.google.android.gms.common.AccountPicker.AccountChooserOptions.Builder param0, java.lang.Object param1) {
                super(param0, null);
            }
            
            public Builder() {
                super(((com.google.android.gms.common.AccountPicker.AccountChooserOptions.Builder) null), null);
            }
            
            public org.xms.g.common.AccountPicker.AccountChooserOptions build() {
                throw new java.lang.RuntimeException("Not Supported");
            }
            
            public org.xms.g.common.AccountPicker.AccountChooserOptions.Builder setAllowableAccounts(java.util.List param0) {
                throw new java.lang.RuntimeException("Not Supported");
            }
            
            public org.xms.g.common.AccountPicker.AccountChooserOptions.Builder setAllowableAccountsTypes(java.util.List param0) {
                throw new java.lang.RuntimeException("Not Supported");
            }
            
            public org.xms.g.common.AccountPicker.AccountChooserOptions.Builder setAlwaysShowAccountPicker(boolean param0) {
                throw new java.lang.RuntimeException("Not Supported");
            }
            
            public org.xms.g.common.AccountPicker.AccountChooserOptions.Builder setOptionsForAddingAccount(android.os.Bundle param0) {
                throw new java.lang.RuntimeException("Not Supported");
            }
            
            public org.xms.g.common.AccountPicker.AccountChooserOptions.Builder setSelectedAccount(android.accounts.Account param0) {
                throw new java.lang.RuntimeException("Not Supported");
            }
            
            public org.xms.g.common.AccountPicker.AccountChooserOptions.Builder setTitleOverrideText(java.lang.String param0) {
                throw new java.lang.RuntimeException("Not Supported");
            }
            
            public static org.xms.g.common.AccountPicker.AccountChooserOptions.Builder dynamicCast(java.lang.Object param0) {
                throw new java.lang.RuntimeException("Not Supported");
            }
            
            public static boolean isInstance(java.lang.Object param0) {
                throw new java.lang.RuntimeException("Not Supported");
            }
        }
    }
}