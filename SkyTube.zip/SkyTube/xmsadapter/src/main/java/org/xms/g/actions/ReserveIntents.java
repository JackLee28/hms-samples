package org.xms.g.actions;

public class ReserveIntents extends org.xms.g.utils.XObject {
    private boolean wrapper = true;
    
    public ReserveIntents(com.google.android.gms.actions.ReserveIntents param0, java.lang.Object param1) {
        super(param0, null);
    }
    
    public static java.lang.String getACTION_RESERVE_TAXI_RESERVATION() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static org.xms.g.actions.ReserveIntents dynamicCast(java.lang.Object param0) {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static boolean isInstance(java.lang.Object param0) {
        throw new java.lang.RuntimeException("Not Supported");
    }
}