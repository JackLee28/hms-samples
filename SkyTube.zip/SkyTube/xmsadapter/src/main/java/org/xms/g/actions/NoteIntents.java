package org.xms.g.actions;

public class NoteIntents extends org.xms.g.utils.XObject {
    private boolean wrapper = true;
    
    public NoteIntents(com.google.android.gms.actions.NoteIntents param0, java.lang.Object param1) {
        super(param0, null);
    }
    
    public static java.lang.String getACTION_APPEND_NOTE() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static java.lang.String getACTION_CREATE_NOTE() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static java.lang.String getACTION_DELETE_NOTE() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static java.lang.String getEXTRA_NAME() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static java.lang.String getEXTRA_NOTE_QUERY() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static java.lang.String getEXTRA_TEXT() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static org.xms.g.actions.NoteIntents dynamicCast(java.lang.Object param0) {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static boolean isInstance(java.lang.Object param0) {
        throw new java.lang.RuntimeException("Not Supported");
    }
}