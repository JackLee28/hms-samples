package com.google.android.gms.samples.fsi;

import android.app.Application;

import org.xms.g.utils.GlobalEnvSetting;

public class MyApp extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
        GlobalEnvSetting.init(this, null);
    }
}