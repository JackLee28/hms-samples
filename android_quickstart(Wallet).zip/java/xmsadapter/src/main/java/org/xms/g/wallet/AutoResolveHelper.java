package org.xms.g.wallet;

public class AutoResolveHelper extends org.xms.g.utils.XObject {
    private boolean wrapper = true;
    
    public AutoResolveHelper(com.google.android.gms.wallet.AutoResolveHelper param0, com.huawei.hms.wallet.ResolveTaskHelper param1) {
        super(param0, null);
        this.setHInstance(param1);
        wrapper = true;
    }
    
    public static int getRESULT_ERROR() {
        if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
            org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hms.wallet.ResolveTaskHelper.RESULT_FAIL");
            return com.huawei.hms.wallet.ResolveTaskHelper.RESULT_FAIL;
        } else {
            org.xms.g.utils.XmsLog.d("XMSRouter", "com.google.android.gms.wallet.AutoResolveHelper.RESULT_ERROR");
            return com.google.android.gms.wallet.AutoResolveHelper.RESULT_ERROR;
        }
    }
    
    public static org.xms.g.common.api.Status getStatusFromIntent(android.content.Intent param0) {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static void putStatusIntoIntent(android.content.Intent param0, org.xms.g.common.api.Status param1) {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static <XTResult extends org.xms.g.wallet.AutoResolvableResult> void resolveTask(org.xms.g.tasks.Task<XTResult> param0, android.app.Activity param1, int param2) {
        if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
            org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hms.wallet.ResolveTaskHelper.excuteTask(((com.huawei.hmf.tasks.Task) ((param0) == null ? null : (param0.getHInstance()))), param1, param2)");
            com.huawei.hms.wallet.ResolveTaskHelper.excuteTask(((com.huawei.hmf.tasks.Task) ((param0) == null ? null : (param0.getHInstance()))), param1, param2);
        } else {
            org.xms.g.utils.XmsLog.d("XMSRouter", "com.google.android.gms.wallet.AutoResolveHelper.resolveTask(((com.google.android.gms.tasks.Task) ((param0) == null ? null : (param0.getGInstance()))), param1, param2)");
            com.google.android.gms.wallet.AutoResolveHelper.resolveTask(((com.google.android.gms.tasks.Task) ((param0) == null ? null : (param0.getGInstance()))), param1, param2);
        }
    }
    
    public static org.xms.g.wallet.AutoResolveHelper dynamicCast(java.lang.Object param0) {
        return ((org.xms.g.wallet.AutoResolveHelper) param0);
    }
    
    public static boolean isInstance(java.lang.Object param0) {
        if (!(param0 instanceof org.xms.g.utils.XGettable)) {
            return false;
        }
        if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
            return ((org.xms.g.utils.XGettable) param0).getHInstance() instanceof com.huawei.hms.wallet.ResolveTaskHelper;
        } else {
            return ((org.xms.g.utils.XGettable) param0).getGInstance() instanceof com.google.android.gms.wallet.AutoResolveHelper;
        }
    }
}