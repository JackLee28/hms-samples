package org.xms.g.wallet;

public final class WalletConstants extends org.xms.g.utils.XObject {
    
    public WalletConstants(com.google.android.gms.wallet.WalletConstants param0, com.huawei.hms.wallet.constant.WalletPassConstant param1) {
        super(param0, null);
        this.setHInstance(param1);
    }
    
    public static java.lang.String getACTION_ENABLE_WALLET_OPTIMIZATION() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static int getBILLING_ADDRESS_FORMAT_FULL() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static int getBILLING_ADDRESS_FORMAT_MIN() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static int getCARD_CLASS_CREDIT() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static int getCARD_CLASS_DEBIT() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static int getCARD_CLASS_PREPAID() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static int getCARD_CLASS_UNKNOWN() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static int getCARD_NETWORK_AMEX() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static int getCARD_NETWORK_DISCOVER() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static int getCARD_NETWORK_INTERAC() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static int getCARD_NETWORK_JCB() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static int getCARD_NETWORK_MASTERCARD() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static int getCARD_NETWORK_OTHER() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static int getCARD_NETWORK_VISA() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static int getENVIRONMENT_PRODUCTION() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static int getENVIRONMENT_SANDBOX() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static int getENVIRONMENT_STRICT_SANDBOX() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static int getENVIRONMENT_TEST() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static int getERROR_CODE_AUTHENTICATION_FAILURE() {
        if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
            org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hms.wallet.constant.WalletPassConstant.ERROR_CODE_MERCHANT_ACCOUNT_ERROR");
            return com.huawei.hms.wallet.constant.WalletPassConstant.ERROR_CODE_MERCHANT_ACCOUNT_ERROR;
        } else {
            org.xms.g.utils.XmsLog.d("XMSRouter", "com.google.android.gms.wallet.WalletConstants.ERROR_CODE_AUTHENTICATION_FAILURE");
            return com.google.android.gms.wallet.WalletConstants.ERROR_CODE_AUTHENTICATION_FAILURE;
        }
    }
    
    public static int getERROR_CODE_BUYER_ACCOUNT_ERROR() {
        if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
            org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hms.wallet.constant.WalletPassConstant.ERROR_CODE_USER_ACCOUNT_ERROR");
            return com.huawei.hms.wallet.constant.WalletPassConstant.ERROR_CODE_USER_ACCOUNT_ERROR;
        } else {
            org.xms.g.utils.XmsLog.d("XMSRouter", "com.google.android.gms.wallet.WalletConstants.ERROR_CODE_BUYER_ACCOUNT_ERROR");
            return com.google.android.gms.wallet.WalletConstants.ERROR_CODE_BUYER_ACCOUNT_ERROR;
        }
    }
    
    public static int getERROR_CODE_DEVELOPER_ERROR() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static int getERROR_CODE_INTERNAL_ERROR() {
        if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
            org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hms.wallet.constant.WalletPassConstant.ERROR_CODE_INTERNAL_ERROR");
            return com.huawei.hms.wallet.constant.WalletPassConstant.ERROR_CODE_INTERNAL_ERROR;
        } else {
            org.xms.g.utils.XmsLog.d("XMSRouter", "com.google.android.gms.wallet.WalletConstants.ERROR_CODE_INTERNAL_ERROR");
            return com.google.android.gms.wallet.WalletConstants.ERROR_CODE_INTERNAL_ERROR;
        }
    }
    
    public static int getERROR_CODE_INVALID_PARAMETERS() {
        if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
            org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hms.wallet.constant.WalletPassConstant.ERROR_CODE_INVALID_PARAMETERS");
            return com.huawei.hms.wallet.constant.WalletPassConstant.ERROR_CODE_INVALID_PARAMETERS;
        } else {
            org.xms.g.utils.XmsLog.d("XMSRouter", "com.google.android.gms.wallet.WalletConstants.ERROR_CODE_INVALID_PARAMETERS");
            return com.google.android.gms.wallet.WalletConstants.ERROR_CODE_INVALID_PARAMETERS;
        }
    }
    
    public static int getERROR_CODE_INVALID_TRANSACTION() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static int getERROR_CODE_MERCHANT_ACCOUNT_ERROR() {
        if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
            org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hms.wallet.constant.WalletPassConstant.ERROR_CODE_MERCHANT_ACCOUNT_ERROR");
            return com.huawei.hms.wallet.constant.WalletPassConstant.ERROR_CODE_MERCHANT_ACCOUNT_ERROR;
        } else {
            org.xms.g.utils.XmsLog.d("XMSRouter", "com.google.android.gms.wallet.WalletConstants.ERROR_CODE_MERCHANT_ACCOUNT_ERROR");
            return com.google.android.gms.wallet.WalletConstants.ERROR_CODE_MERCHANT_ACCOUNT_ERROR;
        }
    }
    
    public static int getERROR_CODE_SERVICE_UNAVAILABLE() {
        if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
            org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hms.wallet.constant.WalletPassConstant.ERROR_CODE_SERVICE_UNAVAILABLE");
            return com.huawei.hms.wallet.constant.WalletPassConstant.ERROR_CODE_SERVICE_UNAVAILABLE;
        } else {
            org.xms.g.utils.XmsLog.d("XMSRouter", "com.google.android.gms.wallet.WalletConstants.ERROR_CODE_SERVICE_UNAVAILABLE");
            return com.google.android.gms.wallet.WalletConstants.ERROR_CODE_SERVICE_UNAVAILABLE;
        }
    }
    
    public static int getERROR_CODE_SPENDING_LIMIT_EXCEEDED() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static int getERROR_CODE_UNKNOWN() {
        if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
            org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hms.wallet.constant.WalletPassConstant.ERROR_CODE_OTHERS");
            return com.huawei.hms.wallet.constant.WalletPassConstant.ERROR_CODE_OTHERS;
        } else {
            org.xms.g.utils.XmsLog.d("XMSRouter", "com.google.android.gms.wallet.WalletConstants.ERROR_CODE_UNKNOWN");
            return com.google.android.gms.wallet.WalletConstants.ERROR_CODE_UNKNOWN;
        }
    }
    
    public static int getERROR_CODE_UNSUPPORTED_API_VERSION() {
        if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
            org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hms.wallet.constant.WalletPassConstant.ERROR_CODE_UNSUPPORTED_API_REQUEST");
            return com.huawei.hms.wallet.constant.WalletPassConstant.ERROR_CODE_UNSUPPORTED_API_REQUEST;
        } else {
            org.xms.g.utils.XmsLog.d("XMSRouter", "com.google.android.gms.wallet.WalletConstants.ERROR_CODE_UNSUPPORTED_API_VERSION");
            return com.google.android.gms.wallet.WalletConstants.ERROR_CODE_UNSUPPORTED_API_VERSION;
        }
    }
    
    public static java.lang.String getEXTRA_ERROR_CODE() {
        if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
            org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hms.wallet.constant.WalletPassConstant.EXTRA_ERROR_CODE");
            return com.huawei.hms.wallet.constant.WalletPassConstant.EXTRA_ERROR_CODE;
        } else {
            org.xms.g.utils.XmsLog.d("XMSRouter", "com.google.android.gms.wallet.WalletConstants.EXTRA_ERROR_CODE");
            return com.google.android.gms.wallet.WalletConstants.EXTRA_ERROR_CODE;
        }
    }
    
    public static java.lang.String getEXTRA_IS_READY_TO_PAY() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static java.lang.String getEXTRA_IS_USER_PREAUTHORIZED() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static java.lang.String getMETADATA_TAG_WALLET_API_ENABLED() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static int getPAYMENT_METHOD_CARD() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static int getPAYMENT_METHOD_TOKENIZATION_TYPE_DIRECT() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static int getPAYMENT_METHOD_TOKENIZATION_TYPE_NETWORK_TOKEN() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static int getPAYMENT_METHOD_TOKENIZATION_TYPE_PAYMENT_GATEWAY() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static int getPAYMENT_METHOD_TOKENIZED_CARD() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static int getPAYMENT_METHOD_UNKNOWN() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static int getRESULT_ERROR() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static int getTHEME_DARK() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static int getTHEME_HOLO_DARK() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static int getTHEME_HOLO_LIGHT() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static int getTHEME_LIGHT() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static int getTOTAL_PRICE_STATUS_ESTIMATED() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static int getTOTAL_PRICE_STATUS_FINAL() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static int getTOTAL_PRICE_STATUS_NOT_CURRENTLY_KNOWN() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static org.xms.g.wallet.WalletConstants dynamicCast(java.lang.Object param0) {
        return ((org.xms.g.wallet.WalletConstants) param0);
    }
    
    public static boolean isInstance(java.lang.Object param0) {
        if (!(param0 instanceof org.xms.g.utils.XGettable)) {
            return false;
        }
        if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
            return ((org.xms.g.utils.XGettable) param0).getHInstance() instanceof com.huawei.hms.wallet.constant.WalletPassConstant;
        } else {
            return ((org.xms.g.utils.XGettable) param0).getGInstance() instanceof com.google.android.gms.wallet.WalletConstants;
        }
    }
    
    public static interface CardNetwork extends org.xms.g.utils.XInterface, java.lang.annotation.Annotation {
        
        public static int getAMEX() {
            throw new java.lang.RuntimeException("Not Supported");
        }
        
        public static int getDISCOVER() {
            throw new java.lang.RuntimeException("Not Supported");
        }
        
        public static int getINTERAC() {
            throw new java.lang.RuntimeException("Not Supported");
        }
        
        public static int getJCB() {
            throw new java.lang.RuntimeException("Not Supported");
        }
        
        public static int getMASTERCARD() {
            throw new java.lang.RuntimeException("Not Supported");
        }
        
        public static int getOTHER() {
            throw new java.lang.RuntimeException("Not Supported");
        }
        
        public static int getVISA() {
            throw new java.lang.RuntimeException("Not Supported");
        }
        
        default com.google.android.gms.wallet.WalletConstants.CardNetwork getGInstanceCardNetwork() {
            throw new java.lang.RuntimeException("Not Supported");
        }
        
        default java.lang.Object getHInstanceCardNetwork() {
            throw new java.lang.RuntimeException("Not Supported");
        }
        
        public static org.xms.g.wallet.WalletConstants.CardNetwork dynamicCast(java.lang.Object param0) {
            throw new java.lang.RuntimeException("Not Supported");
        }
        
        public static boolean isInstance(java.lang.Object param0) {
            throw new java.lang.RuntimeException("Not Supported");
        }
        
        public static class XImpl extends org.xms.g.utils.XObject implements org.xms.g.wallet.WalletConstants.CardNetwork {
            
            public XImpl(com.google.android.gms.wallet.WalletConstants.CardNetwork param0, java.lang.Object param1) {
                super(param0, param1);
            }
            
            public boolean equals(java.lang.Object param0) {
                throw new java.lang.RuntimeException("Not Supported");
            }
            
            public int hashCode() {
                throw new java.lang.RuntimeException("Not Supported");
            }
            
            public java.lang.String toString() {
                throw new java.lang.RuntimeException("Not Supported");
            }
            
            public java.lang.Class<? extends java.lang.annotation.Annotation> annotationType() {
                throw new java.lang.RuntimeException("Not Supported");
            }
        }
    }
}