package org.xms.g.wallet.wobs;

public final class LabelValue extends org.xms.g.utils.XObject implements android.os.Parcelable {
    public static final android.os.Parcelable.Creator CREATOR = new android.os.Parcelable.Creator() {
        
        public org.xms.g.wallet.wobs.LabelValue createFromParcel(android.os.Parcel param0) {
            com.google.android.gms.wallet.wobs.LabelValue gReturn = null;
            com.huawei.hms.wallet.pass.AppendField hReturn = null;
            if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
                hReturn = com.huawei.hms.wallet.pass.AppendField.CREATOR.createFromParcel(param0);
            } else {
                gReturn = com.google.android.gms.wallet.wobs.LabelValue.CREATOR.createFromParcel(param0);
            }
            return new org.xms.g.wallet.wobs.LabelValue(gReturn, hReturn);
        }
        
        public org.xms.g.wallet.wobs.LabelValue[] newArray(int param0) {
            return new org.xms.g.wallet.wobs.LabelValue[param0];
        }
    };
    
    public LabelValue(com.google.android.gms.wallet.wobs.LabelValue param0, com.huawei.hms.wallet.pass.AppendField param1) {
        super(param0, null);
        this.setHInstance(param1);
    }
    
    public LabelValue(java.lang.String param0, java.lang.String param1) {
        super(((com.google.android.gms.wallet.wobs.LabelValue) null), null);
        if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
            org.xms.g.utils.XmsLog.d("XMSRouter", "hms LabelValue constructor");
            com.huawei.hms.wallet.pass.AppendField.Builder builder =
                    com.huawei.hms.wallet.pass.AppendField.getBuilder();
            builder.setKey("text_" + builder.hashCode()).setLabel(param0).setValue(param1);
            this.setHInstance(builder.build());
        } else {
            this.setGInstance(new com.google.android.gms.wallet.wobs.LabelValue(param0, param1));
        }
    }
    
    public final java.lang.String getLabel() {
        if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
            org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.wallet.pass.AppendField) this.getHInstance()).getLabel()");
            return ((com.huawei.hms.wallet.pass.AppendField) this.getHInstance()).getLabel();
        } else {
            org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.wallet.wobs.LabelValue) this.getGInstance()).getLabel()");
            return ((com.google.android.gms.wallet.wobs.LabelValue) this.getGInstance()).getLabel();
        }
    }
    
    public final java.lang.String getValue() {
        if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
            org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.wallet.pass.AppendField) this.getHInstance()).getValue()");
            return ((com.huawei.hms.wallet.pass.AppendField) this.getHInstance()).getValue();
        } else {
            org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.wallet.wobs.LabelValue) this.getGInstance()).getValue()");
            return ((com.google.android.gms.wallet.wobs.LabelValue) this.getGInstance()).getValue();
        }
    }
    
    public final void writeToParcel(android.os.Parcel param0, int param1) {
        if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
            org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.wallet.pass.AppendField) this.getHInstance()).writeToParcel(param0, param1)");
            ((com.huawei.hms.wallet.pass.AppendField) this.getHInstance()).writeToParcel(param0, param1);
        } else {
            org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.wallet.wobs.LabelValue) this.getGInstance()).writeToParcel(param0, param1)");
            ((com.google.android.gms.wallet.wobs.LabelValue) this.getGInstance()).writeToParcel(param0, param1);
        }
    }
    
    public int describeContents() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static org.xms.g.wallet.wobs.LabelValue dynamicCast(java.lang.Object param0) {
        return ((org.xms.g.wallet.wobs.LabelValue) param0);
    }
    
    public static boolean isInstance(java.lang.Object param0) {
        if (!(param0 instanceof org.xms.g.utils.XGettable)) {
            return false;
        }
        if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
            return ((org.xms.g.utils.XGettable) param0).getHInstance() instanceof com.huawei.hms.wallet.pass.AppendField;
        } else {
            return ((org.xms.g.utils.XGettable) param0).getGInstance() instanceof com.google.android.gms.wallet.wobs.LabelValue;
        }
    }
}