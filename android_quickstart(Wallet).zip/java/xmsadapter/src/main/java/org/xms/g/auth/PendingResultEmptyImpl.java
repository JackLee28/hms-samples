
package org.xms.g.auth;

import android.os.Looper;

import com.huawei.hms.support.api.client.Result;
import com.huawei.hms.support.api.client.ResultCallback;

import java.util.concurrent.TimeUnit;

public class PendingResultEmptyImpl extends com.huawei.hms.support.api.client.PendingResult {
    @Override
    public Result await() {
        return new Result() {};
    }

    @Override
    public Result await(long l, TimeUnit timeUnit) {
        return new Result() {};
    }

    @Override
    public void setResultCallback(ResultCallback resultCallback) {

    }

    @Override
    public void setResultCallback(Looper looper, ResultCallback resultCallback) {

    }

    @Override
    public void cancel() {

    }

    @Override
    public boolean isCanceled() {
        return false;
    }

    @Override
    public void setResultCallback(ResultCallback resultCallback, long l, TimeUnit timeUnit) {

    }
}
