package org.xms.g.auth.api.accounttransfer;

public final class AccountTransfer extends org.xms.g.utils.XObject {
    
    public AccountTransfer(com.google.android.gms.auth.api.accounttransfer.AccountTransfer param0, java.lang.Object param1) {
        super(param0, null);
    }
    
    public static java.lang.String getACTION_ACCOUNT_EXPORT_DATA_AVAILABLE() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static java.lang.String getACTION_ACCOUNT_IMPORT_DATA_AVAILABLE() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static java.lang.String getACTION_START_ACCOUNT_EXPORT() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static java.lang.String getKEY_EXTRA_ACCOUNT_TYPE() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static org.xms.g.auth.api.accounttransfer.AccountTransferClient getAccountTransferClient(android.content.Context param0) {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static org.xms.g.auth.api.accounttransfer.AccountTransferClient getAccountTransferClient(android.app.Activity param0) {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static org.xms.g.auth.api.accounttransfer.AccountTransfer dynamicCast(java.lang.Object param0) {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static boolean isInstance(java.lang.Object param0) {
        throw new java.lang.RuntimeException("Not Supported");
    }
}