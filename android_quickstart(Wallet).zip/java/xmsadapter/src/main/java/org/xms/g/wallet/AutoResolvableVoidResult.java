package org.xms.g.wallet;

public class AutoResolvableVoidResult extends org.xms.g.utils.XObject implements org.xms.g.wallet.AutoResolvableResult {
    private boolean wrapper = true;
    
    public AutoResolvableVoidResult(com.google.android.gms.wallet.AutoResolvableVoidResult param0, com.huawei.hms.wallet.AutoResolvableForegroundIntentResult param1) {
        super(param0, null);
        this.setHInstance(param1);
        wrapper = true;
    }
    
    public AutoResolvableVoidResult() {
        super(((com.google.android.gms.wallet.AutoResolvableVoidResult) null), null);
        if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
            this.setHInstance(new HImpl());
        } else {
            this.setGInstance(new GImpl());
        }
        wrapper = false;
    }
    
    public void putIntoIntent(android.content.Intent param0) {
        if (wrapper) {
            if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
                org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.wallet.AutoResolvableForegroundIntentResult) this.getHInstance()).addIntent(param0)");
                ((com.huawei.hms.wallet.AutoResolvableForegroundIntentResult) this.getHInstance()).addIntent(param0);
            } else {
                org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.wallet.AutoResolvableVoidResult) this.getGInstance()).putIntoIntent(param0)");
                ((com.google.android.gms.wallet.AutoResolvableVoidResult) this.getGInstance()).putIntoIntent(param0);
            }
        } else {
            if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
                org.xms.g.utils.XmsLog.d("XMSRouter", "((HImpl) ((com.huawei.hms.wallet.AutoResolvableForegroundIntentResult) this.getHInstance())).addIntentCallSuper(param0)");
                ((HImpl) ((com.huawei.hms.wallet.AutoResolvableForegroundIntentResult) this.getHInstance())).addIntentCallSuper(param0);
            } else {
                org.xms.g.utils.XmsLog.d("XMSRouter", "((GImpl) ((com.google.android.gms.wallet.AutoResolvableVoidResult) this.getGInstance())).putIntoIntentCallSuper(param0)");
                ((GImpl) ((com.google.android.gms.wallet.AutoResolvableVoidResult) this.getGInstance())).putIntoIntentCallSuper(param0);
            }
        }
    }
    
    public static org.xms.g.wallet.AutoResolvableVoidResult dynamicCast(java.lang.Object param0) {
        if (param0 instanceof org.xms.g.wallet.AutoResolvableVoidResult) {
            return ((org.xms.g.wallet.AutoResolvableVoidResult) param0);
        }
        if (param0 instanceof org.xms.g.utils.XGettable) {
            com.google.android.gms.wallet.AutoResolvableVoidResult gReturn = ((com.google.android.gms.wallet.AutoResolvableVoidResult) ((org.xms.g.utils.XGettable) param0).getGInstance());
            com.huawei.hms.wallet.AutoResolvableForegroundIntentResult hReturn = ((com.huawei.hms.wallet.AutoResolvableForegroundIntentResult) ((org.xms.g.utils.XGettable) param0).getHInstance());
            return new org.xms.g.wallet.AutoResolvableVoidResult(gReturn, hReturn);
        }
        return ((org.xms.g.wallet.AutoResolvableVoidResult) param0);
    }
    
    public static boolean isInstance(java.lang.Object param0) {
        if (!(param0 instanceof org.xms.g.utils.XGettable)) {
            return false;
        }
        if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
            return ((org.xms.g.utils.XGettable) param0).getHInstance() instanceof com.huawei.hms.wallet.AutoResolvableForegroundIntentResult;
        } else {
            return ((org.xms.g.utils.XGettable) param0).getGInstance() instanceof com.google.android.gms.wallet.AutoResolvableVoidResult;
        }
    }
    
    private class GImpl extends com.google.android.gms.wallet.AutoResolvableVoidResult {
        
        public void putIntoIntent(android.content.Intent param0) {
            org.xms.g.wallet.AutoResolvableVoidResult.this.putIntoIntent(param0);
        }
        
        public void putIntoIntentCallSuper(android.content.Intent param0) {
            super.putIntoIntent(param0);
        }
        
        public GImpl() {
            super();
        }
    }
    
    private class HImpl extends com.huawei.hms.wallet.AutoResolvableForegroundIntentResult {
        
        public void addIntent(android.content.Intent param0) {
            org.xms.g.wallet.AutoResolvableVoidResult.this.putIntoIntent(param0);
        }
        
        public void addIntentCallSuper(android.content.Intent param0) {
            super.addIntent(param0);
        }
        
        public HImpl() {
            super();
        }
    }
}