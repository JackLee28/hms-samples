package org.xms.g.wallet;

public final class InstrumentInfo extends org.xms.g.utils.XObject implements android.os.Parcelable {
    public static final android.os.Parcelable.Creator CREATOR = new android.os.Parcelable.Creator() {
        
        public org.xms.g.wallet.InstrumentInfo createFromParcel(android.os.Parcel param0) {
            throw new java.lang.RuntimeException("Not Supported");
        }
        
        public org.xms.g.wallet.InstrumentInfo[] newArray(int param0) {
            throw new java.lang.RuntimeException("Not Supported");
        }
    };
    
    public InstrumentInfo(com.google.android.gms.wallet.InstrumentInfo param0, java.lang.Object param1) {
        super(param0, null);
    }
    
    public static int getCARD_CLASS_CREDIT() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static int getCARD_CLASS_DEBIT() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static int getCARD_CLASS_PREPAID() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static int getCARD_CLASS_UNKNOWN() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public final int getCardClass() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public final java.lang.String getInstrumentDetails() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public final java.lang.String getInstrumentType() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public final void writeToParcel(android.os.Parcel param0, int param1) {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public int describeContents() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static org.xms.g.wallet.InstrumentInfo dynamicCast(java.lang.Object param0) {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static boolean isInstance(java.lang.Object param0) {
        throw new java.lang.RuntimeException("Not Supported");
    }
}