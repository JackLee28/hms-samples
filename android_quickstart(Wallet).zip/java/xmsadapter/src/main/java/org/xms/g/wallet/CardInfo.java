package org.xms.g.wallet;

public final class CardInfo extends org.xms.g.utils.XObject implements android.os.Parcelable {
    public static final android.os.Parcelable.Creator CREATOR = new android.os.Parcelable.Creator() {
        
        public org.xms.g.wallet.CardInfo createFromParcel(android.os.Parcel param0) {
            throw new java.lang.RuntimeException("Not Supported");
        }
        
        public org.xms.g.wallet.CardInfo[] newArray(int param0) {
            throw new java.lang.RuntimeException("Not Supported");
        }
    };
    
    public CardInfo(com.google.android.gms.wallet.CardInfo param0, java.lang.Object param1) {
        super(param0, null);
    }
    
    public final org.xms.g.identity.intents.model.UserAddress getBillingAddress() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public final int getCardClass() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public final java.lang.String getCardDescription() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public final java.lang.String getCardDetails() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public final java.lang.String getCardNetwork() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public final void writeToParcel(android.os.Parcel param0, int param1) {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public int describeContents() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static org.xms.g.wallet.CardInfo dynamicCast(java.lang.Object param0) {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static boolean isInstance(java.lang.Object param0) {
        throw new java.lang.RuntimeException("Not Supported");
    }
}