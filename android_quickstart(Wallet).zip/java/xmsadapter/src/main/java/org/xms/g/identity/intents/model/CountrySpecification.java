package org.xms.g.identity.intents.model;

public class CountrySpecification extends org.xms.g.utils.XObject implements android.os.Parcelable {
    private boolean wrapper = true;
    public static final android.os.Parcelable.Creator CREATOR = new android.os.Parcelable.Creator() {
        
        public org.xms.g.identity.intents.model.CountrySpecification createFromParcel(android.os.Parcel param0) {
            throw new java.lang.RuntimeException("Not Supported");
        }
        
        public org.xms.g.identity.intents.model.CountrySpecification[] newArray(int param0) {
            throw new java.lang.RuntimeException("Not Supported");
        }
    };
    public CountrySpecification(com.google.android.gms.identity.intents.model.CountrySpecification param0, java.lang.Object param1) {
        super(param0, null);
        this.setHInstance(param1);
        wrapper = true;
    }
    
    
    public CountrySpecification(java.lang.String param0) {
        super(((com.google.android.gms.identity.intents.model.CountrySpecification) null), null);
        if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
            org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hms.identity.CountrySpecification");
            this.setHInstance(null);
        } else {
            this.setGInstance(new GImpl(param0));
        }
        wrapper = false;
    }
    
    public java.lang.String getCountryCode() {
        if (wrapper) {
            if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
                org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hms.identity.CountrySpecification.getCountryCode");
            return "";
            } else {
                org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.identity.intents.model.CountrySpecification) this.getGInstance()).getCountryCode()");
                return ((com.google.android.gms.identity.intents.model.CountrySpecification) this.getGInstance()).getCountryCode();
            }
        } else {
            if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
                org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hms.identity.CountrySpecification.getCountryCode");
            return "";
            } else {
                org.xms.g.utils.XmsLog.d("XMSRouter", "((GImpl) ((com.google.android.gms.identity.intents.model.CountrySpecification) this.getGInstance())).getCountryCodeCallSuper()");
                return ((GImpl) ((com.google.android.gms.identity.intents.model.CountrySpecification) this.getGInstance())).getCountryCodeCallSuper();
            }
        }
    }
    
    public void writeToParcel(android.os.Parcel param0, int param1) {
        if (wrapper) {
            if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
                throw new RuntimeException("HMS does not support this writeToParcel(android.os.Parcel,int) method");
            } else {
                org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.identity.intents.model.CountrySpecification) this.getGInstance()).writeToParcel(param0, param1)");
                ((com.google.android.gms.identity.intents.model.CountrySpecification) this.getGInstance()).writeToParcel(param0, param1);
            }
        } else {
            if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
                throw new RuntimeException("HMS does not support this writeToParcel(android.os.Parcel,int) method");
            } else {
                org.xms.g.utils.XmsLog.d("XMSRouter", "((GImpl) ((com.google.android.gms.identity.intents.model.CountrySpecification) this.getGInstance())).writeToParcelCallSuper(param0, param1)");
                ((GImpl) ((com.google.android.gms.identity.intents.model.CountrySpecification) this.getGInstance())).writeToParcelCallSuper(param0, param1);
            }
        }
    }
    
    public int describeContents() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static org.xms.g.identity.intents.model.CountrySpecification dynamicCast(java.lang.Object param0) {
        return ((org.xms.g.identity.intents.model.CountrySpecification) param0);
    }
    
    public static boolean isInstance(java.lang.Object param0) {
        if (!(param0 instanceof org.xms.g.utils.XGettable)) {
            return false;
        }
        if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
            throw new RuntimeException("hms branch not support");
        } else {
            return ((org.xms.g.utils.XGettable) param0).getGInstance() instanceof com.google.android.gms.identity.intents.model.CountrySpecification;
        }
    }
    
    private class GImpl extends com.google.android.gms.identity.intents.model.CountrySpecification {
        
        public java.lang.String getCountryCode() {
            return org.xms.g.identity.intents.model.CountrySpecification.this.getCountryCode();
        }
        
        public void writeToParcel(android.os.Parcel param0, int param1) {
            org.xms.g.identity.intents.model.CountrySpecification.this.writeToParcel(param0, param1);
        }
        
        public java.lang.String getCountryCodeCallSuper() {
            return super.getCountryCode();
        }
        
        public void writeToParcelCallSuper(android.os.Parcel param0, int param1) {
            super.writeToParcel(param0, param1);
        }
        
        public GImpl(java.lang.String param0) {
            super(param0);
        }
    }
}