package org.xms.g.wallet;

public class PaymentsClient extends org.xms.g.common.api.ExtensionApi<org.xms.g.wallet.Wallet.WalletOptions> {
    private boolean wrapper = true;
    
    public PaymentsClient(com.google.android.gms.wallet.PaymentsClient param0, java.lang.Object param1) {
        super(param0, null);
    }
    
    public org.xms.g.tasks.Task<java.lang.Boolean> isReadyToPay(org.xms.g.wallet.IsReadyToPayRequest param0) {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public org.xms.g.tasks.Task<org.xms.g.wallet.PaymentData> loadPaymentData(org.xms.g.wallet.PaymentDataRequest param0) {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public java.lang.Object getApiKey() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static org.xms.g.wallet.PaymentsClient dynamicCast(java.lang.Object param0) {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static boolean isInstance(java.lang.Object param0) {
        throw new java.lang.RuntimeException("Not Supported");
    }
}