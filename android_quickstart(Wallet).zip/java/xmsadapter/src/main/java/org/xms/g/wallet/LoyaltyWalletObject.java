package org.xms.g.wallet;

public final class LoyaltyWalletObject extends org.xms.g.utils.XObject implements android.os.Parcelable {
    public static final android.os.Parcelable.Creator CREATOR = new android.os.Parcelable.Creator() {
        
        public org.xms.g.wallet.LoyaltyWalletObject createFromParcel(android.os.Parcel param0) {
            throw new java.lang.RuntimeException("Not Supported");
        }
        
        public org.xms.g.wallet.LoyaltyWalletObject[] newArray(int param0) {
            throw new java.lang.RuntimeException("Not Supported");
        }
    };
    private java.lang.String getCommonFieldValueByKey(java.lang.String key) {
        if (key == null || key.isEmpty()) {
            return null;
        }
        java.util.ArrayList<com.huawei.hms.wallet.pass.CommonField> commonFields =
                ((com.huawei.hms.wallet.pass.PassObject) this.getHInstance()).getCommonField();
        for (com.huawei.hms.wallet.pass.CommonField field : commonFields) {
            if (key.equals(field.getKey())) {
                return field.getValue();
            }
        }
        return null;
    }
    
    public LoyaltyWalletObject(com.google.android.gms.wallet.LoyaltyWalletObject param0, com.huawei.hms.wallet.pass.PassObject param1) {
        super(param0, null);
        this.setHInstance(param1);
    }
    
    public final java.lang.String getAccountId() {
        if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
            org.xms.g.utils.XmsLog.d("XMSRouter", "hms getAccountId");
            return getCommonFieldValueByKey(
                    com.huawei.hms.wallet.constant.WalletPassConstant.PASS_COMMON_FIELD_KEY_CARD_NUMBER);
        } else {
            org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.wallet.LoyaltyWalletObject) this.getGInstance()).getAccountId()");
            return ((com.google.android.gms.wallet.LoyaltyWalletObject) this.getGInstance()).getAccountId();
        }
    }
    
    public final java.lang.String getAccountName() {
        if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
            org.xms.g.utils.XmsLog.d("XMSRouter", "hms getAccountName");
            return getCommonFieldValueByKey(
                    com.huawei.hms.wallet.constant.WalletPassConstant.PASS_COMMON_FIELD_KEY_MEMBER_NAME);
        } else {
            org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.wallet.LoyaltyWalletObject) this.getGInstance()).getAccountName()");
            return ((com.google.android.gms.wallet.LoyaltyWalletObject) this.getGInstance()).getAccountName();
        }
    }
    
    public final java.lang.String getBarcodeAlternateText() {
        if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
            org.xms.g.utils.XmsLog.d("XMSRouter", "hms getBarcodeAlternateText");
            com.huawei.hms.wallet.pass.BarCode barCode = ((com.huawei.hms.wallet.pass.PassObject) this.getHInstance()).getBarCode();
            if (barCode == null) {
                return null;
            } else {
                return barCode.getText();
            }
        } else {
            org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.wallet.LoyaltyWalletObject) this.getGInstance()).getBarcodeAlternateText()");
            return ((com.google.android.gms.wallet.LoyaltyWalletObject) this.getGInstance()).getBarcodeAlternateText();
        }
    }
    
    public final java.lang.String getBarcodeLabel() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public final java.lang.String getBarcodeType() {
        if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
            org.xms.g.utils.XmsLog.d("XMSRouter", "hms getBarcodeType");
            com.huawei.hms.wallet.pass.BarCode barCode = ((com.huawei.hms.wallet.pass.PassObject) this.getHInstance()).getBarCode();
            if (barCode == null) {
                return null;
            } else {
                return barCode.getType();
            }
        } else {
            org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.wallet.LoyaltyWalletObject) this.getGInstance()).getBarcodeType()");
            return ((com.google.android.gms.wallet.LoyaltyWalletObject) this.getGInstance()).getBarcodeType();
        }
    }
    
    public final java.lang.String getBarcodeValue() {
        if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
            org.xms.g.utils.XmsLog.d("XMSRouter", "hms getBarcodeValue");
            com.huawei.hms.wallet.pass.BarCode barCode = ((com.huawei.hms.wallet.pass.PassObject) this.getHInstance()).getBarCode();
            if (barCode == null) {
                return null;
            } else {
                return barCode.getValue();
            }
        } else {
            org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.wallet.LoyaltyWalletObject) this.getGInstance()).getBarcodeValue()");
            return ((com.google.android.gms.wallet.LoyaltyWalletObject) this.getGInstance()).getBarcodeValue();
        }
    }
    
    public final java.lang.String getClassId() {
        if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
            org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.wallet.pass.PassObject) this.getHInstance()).getPassStyleIdentifier()");
            return ((com.huawei.hms.wallet.pass.PassObject) this.getHInstance()).getPassStyleIdentifier();
        } else {
            org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.wallet.LoyaltyWalletObject) this.getGInstance()).getClassId()");
            return ((com.google.android.gms.wallet.LoyaltyWalletObject) this.getGInstance()).getClassId();
        }
    }
    
    public final java.lang.String getId() {
        if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
            org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.wallet.pass.PassObject) this.getHInstance()).getOrganizationPassId()");
            return ((com.huawei.hms.wallet.pass.PassObject) this.getHInstance()).getOrganizationPassId();
        } else {
            org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.wallet.LoyaltyWalletObject) this.getGInstance()).getId()");
            return ((com.google.android.gms.wallet.LoyaltyWalletObject) this.getGInstance()).getId();
        }
    }
    
    public java.util.ArrayList<org.xms.g.wallet.wobs.UriData> getImageModuleDataMainImageUris() {
        if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
            org.xms.g.utils.XmsLog.d("XMSRouter", "hms getImageModuleDataMainImageUris");
            java.util.ArrayList hReturn = ((com.huawei.hms.wallet.pass.PassObject) this.getHInstance()).getImageList();
            return ((java.util.ArrayList) org.xms.g.utils.Utils.mapCollection(hReturn, new org.xms.g.utils.Function<com.huawei.hms.wallet.pass.AppendField, org.xms.g.wallet.wobs.UriData>() {
                public org.xms.g.wallet.wobs.UriData apply(com.huawei.hms.wallet.pass.AppendField param0) {
                    return new org.xms.g.wallet.wobs.UriData(null, param0);
                }
            }));
        } else {
            org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.wallet.LoyaltyWalletObject) this.getGInstance()).getImageModuleDataMainImageUris()");
            java.util.ArrayList gReturn = ((com.google.android.gms.wallet.LoyaltyWalletObject) this.getGInstance()).getImageModuleDataMainImageUris();
            return ((java.util.ArrayList) org.xms.g.utils.Utils.mapCollection(gReturn, new org.xms.g.utils.Function<com.google.android.gms.wallet.wobs.UriData, org.xms.g.wallet.wobs.UriData>() {
                
                public org.xms.g.wallet.wobs.UriData apply(com.google.android.gms.wallet.wobs.UriData param0) {
                    return new org.xms.g.wallet.wobs.UriData(param0, null);
                }
            }));
        }
    }
    
    public final java.lang.String getInfoModuleDataHexBackgroundColor() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public final java.lang.String getInfoModuleDataHexFontColor() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public java.util.ArrayList<org.xms.g.wallet.wobs.LabelValueRow> getInfoModuleDataLabelValueRows() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public final boolean getInfoModuleDataShowLastUpdateTime() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public final java.lang.String getIssuerName() {
        if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
            org.xms.g.utils.XmsLog.d("XMSRouter", "hms getIssuerName");
            return getCommonFieldValueByKey(
                    com.huawei.hms.wallet.constant.WalletPassConstant.PASS_COMMON_FIELD_KEY_MERCHANT_NAME);
        } else {
            org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.wallet.LoyaltyWalletObject) this.getGInstance()).getIssuerName()");
            return ((com.google.android.gms.wallet.LoyaltyWalletObject) this.getGInstance()).getIssuerName();
        }
    }
    
    public java.util.ArrayList<org.xms.g.wallet.wobs.UriData> getLinksModuleDataUris() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public java.util.ArrayList<org.xms.g.maps.model.LatLng> getLocations() {
        if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
            org.xms.g.utils.XmsLog.d("XMSRouter", "hms getLocations");
            java.util.ArrayList hReturn = ((com.huawei.hms.wallet.pass.PassObject) this.getHInstance()).getLocationList();
            return ((java.util.ArrayList) org.xms.g.utils.Utils.mapCollection(hReturn, new org.xms.g.utils.Function<com.huawei.hms.wallet.pass.Location, org.xms.g.maps.model.LatLng>() {
                public org.xms.g.maps.model.LatLng apply(com.huawei.hms.wallet.pass.Location param0) {
                    com.huawei.hms.maps.model.LatLng latLng = null;
                    if (param0 != null) {
                        latLng = new com.huawei.hms.maps.model.LatLng(
                                Double.parseDouble(param0.getLatitude()), Double.parseDouble(param0.getLongitude())
                        );
                    }
                    return new org.xms.g.maps.model.LatLng(null, latLng);
                }
            }));
        } else {
            org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.wallet.LoyaltyWalletObject) this.getGInstance()).getLocations()");
            java.util.ArrayList gReturn = ((com.google.android.gms.wallet.LoyaltyWalletObject) this.getGInstance()).getLocations();
            return ((java.util.ArrayList) org.xms.g.utils.Utils.mapCollection(gReturn, new org.xms.g.utils.Function<com.google.android.gms.maps.model.LatLng, org.xms.g.maps.model.LatLng>() {
                
                public org.xms.g.maps.model.LatLng apply(com.google.android.gms.maps.model.LatLng param0) {
                    return new org.xms.g.maps.model.LatLng(param0, null);
                }
            }));
        }
    }
    
    public final org.xms.g.wallet.wobs.LoyaltyPoints getLoyaltyPoints() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public java.util.ArrayList<org.xms.g.wallet.wobs.WalletObjectMessage> getMessages() {
        if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
            org.xms.g.utils.XmsLog.d("XMSRouter", "hms getMessages");
            java.util.ArrayList hReturn = ((com.huawei.hms.wallet.pass.PassObject) this.getHInstance()).getMessageList();
            return ((java.util.ArrayList) org.xms.g.utils.Utils.mapCollection(hReturn, new org.xms.g.utils.Function<com.huawei.hms.wallet.pass.AppendField, org.xms.g.wallet.wobs.WalletObjectMessage>() {
                public org.xms.g.wallet.wobs.WalletObjectMessage apply(com.huawei.hms.wallet.pass.AppendField param0) {
                    return new org.xms.g.wallet.wobs.WalletObjectMessage(null, param0);
                }
            }));
        } else {
            org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.wallet.LoyaltyWalletObject) this.getGInstance()).getMessages()");
            java.util.ArrayList gReturn = ((com.google.android.gms.wallet.LoyaltyWalletObject) this.getGInstance()).getMessages();
            return ((java.util.ArrayList) org.xms.g.utils.Utils.mapCollection(gReturn, new org.xms.g.utils.Function<com.google.android.gms.wallet.wobs.WalletObjectMessage, org.xms.g.wallet.wobs.WalletObjectMessage>() {
                
                public org.xms.g.wallet.wobs.WalletObjectMessage apply(com.google.android.gms.wallet.wobs.WalletObjectMessage param0) {
                    return new org.xms.g.wallet.wobs.WalletObjectMessage(param0, null);
                }
            }));
        }
    }
    
    public final java.lang.String getProgramName() {
        if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
            org.xms.g.utils.XmsLog.d("XMSRouter", "hms getProgramName");
            return getCommonFieldValueByKey(
                    com.huawei.hms.wallet.constant.WalletPassConstant.PASS_COMMON_FIELD_KEY_NAME);
        } else {
            org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.wallet.LoyaltyWalletObject) this.getGInstance()).getProgramName()");
            return ((com.google.android.gms.wallet.LoyaltyWalletObject) this.getGInstance()).getProgramName();
        }
    }
    
    public final int getState() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public java.util.ArrayList<org.xms.g.wallet.wobs.TextModuleData> getTextModulesData() {
        if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
            org.xms.g.utils.XmsLog.d("XMSRouter", "hms getTextModulesData");
            java.util.ArrayList hReturn = ((com.huawei.hms.wallet.pass.PassObject) this.getHInstance()).getTextList();
            return ((java.util.ArrayList) org.xms.g.utils.Utils.mapCollection(hReturn, new org.xms.g.utils.Function<com.huawei.hms.wallet.pass.AppendField, org.xms.g.wallet.wobs.TextModuleData>() {
                public org.xms.g.wallet.wobs.TextModuleData apply(com.huawei.hms.wallet.pass.AppendField param0) {
                    return new org.xms.g.wallet.wobs.TextModuleData(null, param0);
                }
            }));
        } else {
            org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.wallet.LoyaltyWalletObject) this.getGInstance()).getTextModulesData()");
            java.util.ArrayList gReturn = ((com.google.android.gms.wallet.LoyaltyWalletObject) this.getGInstance()).getTextModulesData();
            return ((java.util.ArrayList) org.xms.g.utils.Utils.mapCollection(gReturn, new org.xms.g.utils.Function<com.google.android.gms.wallet.wobs.TextModuleData, org.xms.g.wallet.wobs.TextModuleData>() {
                
                public org.xms.g.wallet.wobs.TextModuleData apply(com.google.android.gms.wallet.wobs.TextModuleData param0) {
                    return new org.xms.g.wallet.wobs.TextModuleData(param0, null);
                }
            }));
        }
    }
    
    public final org.xms.g.wallet.wobs.TimeInterval getValidTimeInterval() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static org.xms.g.wallet.LoyaltyWalletObject.Builder newBuilder() {
        if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
            org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hms.wallet.pass.PassObject.getBuilder()");
            com.huawei.hms.wallet.pass.PassObject.Builder hReturn = com.huawei.hms.wallet.pass.PassObject.getBuilder();
            return ((hReturn) == null ? null : (new org.xms.g.wallet.LoyaltyWalletObject.Builder(null, hReturn)));
        } else {
            org.xms.g.utils.XmsLog.d("XMSRouter", "com.google.android.gms.wallet.LoyaltyWalletObject.newBuilder()");
            com.google.android.gms.wallet.LoyaltyWalletObject.Builder gReturn = com.google.android.gms.wallet.LoyaltyWalletObject.newBuilder();
            return ((gReturn) == null ? null : (new org.xms.g.wallet.LoyaltyWalletObject.Builder(gReturn, null)));
        }
    }
    
    public final void writeToParcel(android.os.Parcel param0, int param1) {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public int describeContents() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static org.xms.g.wallet.LoyaltyWalletObject dynamicCast(java.lang.Object param0) {
        return ((org.xms.g.wallet.LoyaltyWalletObject) param0);
    }
    
    public static boolean isInstance(java.lang.Object param0) {
        if (!(param0 instanceof org.xms.g.utils.XGettable)) {
            return false;
        }
        if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
            return ((org.xms.g.utils.XGettable) param0).getHInstance() instanceof com.huawei.hms.wallet.pass.PassObject;
        } else {
            return ((org.xms.g.utils.XGettable) param0).getGInstance() instanceof com.google.android.gms.wallet.LoyaltyWalletObject;
        }
    }
    
    public static final class Builder extends org.xms.g.utils.XObject {
        
        public Builder(com.google.android.gms.wallet.LoyaltyWalletObject.Builder param0, com.huawei.hms.wallet.pass.PassObject.Builder param1) {
            super(param0, null);
            this.setHInstance(param1);
        }
        
        public final org.xms.g.wallet.LoyaltyWalletObject.Builder addImageModuleDataMainImageUri(org.xms.g.wallet.wobs.UriData param0) {
            if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
                org.xms.g.utils.XmsLog.d("XMSRouter", "addImageModuleDataMainImageUri");
                java.util.ArrayList<com.huawei.hms.wallet.pass.AppendField> imageList = new java.util.ArrayList<>();
                com.huawei.hms.wallet.pass.AppendField field = (com.huawei.hms.wallet.pass.AppendField) param0.getHInstance();
                imageList.add(field);
                com.huawei.hms.wallet.pass.PassObject.Builder hReturn =
                        ((com.huawei.hms.wallet.pass.PassObject.Builder) this.getHInstance()).addImageList(imageList);
                if (hReturn == null) {
                    return null;
                }
                return new org.xms.g.wallet.LoyaltyWalletObject.Builder(null, hReturn);
            } else {
                org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.wallet.LoyaltyWalletObject.Builder) this.getGInstance()).addImageModuleDataMainImageUri(((com.google.android.gms.wallet.wobs.UriData) ((param0) == null ? null : (param0.getGInstance()))))");
                com.google.android.gms.wallet.LoyaltyWalletObject.Builder gReturn = ((com.google.android.gms.wallet.LoyaltyWalletObject.Builder) this.getGInstance()).addImageModuleDataMainImageUri(((com.google.android.gms.wallet.wobs.UriData) ((param0) == null ? null : (param0.getGInstance()))));
                return ((gReturn) == null ? null : (new org.xms.g.wallet.LoyaltyWalletObject.Builder(gReturn, null)));
            }
        }
        
        public final org.xms.g.wallet.LoyaltyWalletObject.Builder addImageModuleDataMainImageUris(java.util.Collection<org.xms.g.wallet.wobs.UriData> param0) {
            if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
                org.xms.g.utils.XmsLog.d("XMSRouter", "addImageModuleDataMainImageUris");
                java.util.ArrayList<com.huawei.hms.wallet.pass.AppendField> imageList = new java.util.ArrayList<>();
                for (org.xms.g.wallet.wobs.UriData uriData : param0) {
                    com.huawei.hms.wallet.pass.AppendField field = (com.huawei.hms.wallet.pass.AppendField) uriData.getHInstance();
                    imageList.add(field);
                }
                com.huawei.hms.wallet.pass.PassObject.Builder hReturn =
                        ((com.huawei.hms.wallet.pass.PassObject.Builder) this.getHInstance()).addImageList(imageList);
                if (hReturn == null) {
                    return null;
                }
                return new org.xms.g.wallet.LoyaltyWalletObject.Builder(null, hReturn);
            } else {
                org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.wallet.LoyaltyWalletObject.Builder) this.getGInstance()).addImageModuleDataMainImageUris(org.xms.g.utils.Utils.mapCollection2GH(param0, false))");
                com.google.android.gms.wallet.LoyaltyWalletObject.Builder gReturn = ((com.google.android.gms.wallet.LoyaltyWalletObject.Builder) this.getGInstance()).addImageModuleDataMainImageUris(org.xms.g.utils.Utils.mapCollection2GH(param0, false));
                return ((gReturn) == null ? null : (new org.xms.g.wallet.LoyaltyWalletObject.Builder(gReturn, null)));
            }
        }
        
        public final org.xms.g.wallet.LoyaltyWalletObject.Builder addInfoModuleDataLabeValueRow(org.xms.g.wallet.wobs.LabelValueRow param0) {
            if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
                org.xms.g.utils.XmsLog.d("XMSRouter", "addInfoModuleDataLabeValueRow");
                java.util.ArrayList<com.huawei.hms.wallet.pass.AppendField> textList = new java.util.ArrayList<>();
                com.google.android.gms.wallet.wobs.LabelValueRow gTextModuleData = (com.google.android.gms.wallet.wobs.LabelValueRow) param0.getGInstance();
                java.util.ArrayList<com.google.android.gms.wallet.wobs.LabelValue> columns = gTextModuleData.getColumns();
                if (columns != null && !columns.isEmpty()) {
                    for (com.google.android.gms.wallet.wobs.LabelValue labelValue : columns) {
                        com.huawei.hms.wallet.pass.AppendField.Builder builder = com.huawei.hms.wallet.pass.AppendField.getBuilder();
                        com.huawei.hms.wallet.pass.AppendField field = builder.setKey("text"+ builder.hashCode()).setValue(labelValue.getValue()).setLabel(labelValue.getLabel()).build();
                        textList.add(field);
                    }
                }
                com.huawei.hms.wallet.pass.PassObject.Builder hReturn =
                        ((com.huawei.hms.wallet.pass.PassObject.Builder) this.getHInstance()).addTextList(textList);
                if (hReturn == null) {
                    return null;
                }
                return new org.xms.g.wallet.LoyaltyWalletObject.Builder(null, hReturn);
            } else {
                org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.wallet.LoyaltyWalletObject.Builder) this.getGInstance()).addInfoModuleDataLabeValueRow(((com.google.android.gms.wallet.wobs.LabelValueRow) ((param0) == null ? null : (param0.getGInstance()))))");
                com.google.android.gms.wallet.LoyaltyWalletObject.Builder gReturn = ((com.google.android.gms.wallet.LoyaltyWalletObject.Builder) this.getGInstance()).addInfoModuleDataLabeValueRow(((com.google.android.gms.wallet.wobs.LabelValueRow) ((param0) == null ? null : (param0.getGInstance()))));
                return ((gReturn) == null ? null : (new org.xms.g.wallet.LoyaltyWalletObject.Builder(gReturn, null)));
            }
        }
        
        public final org.xms.g.wallet.LoyaltyWalletObject.Builder addInfoModuleDataLabelValueRows(java.util.Collection<org.xms.g.wallet.wobs.LabelValueRow> param0) {
            if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
                org.xms.g.utils.XmsLog.d("XMSRouter", "addInfoModuleDataLabelValueRows");
                java.util.ArrayList<com.huawei.hms.wallet.pass.AppendField> textList = new java.util.ArrayList<>();
                for (org.xms.g.wallet.wobs.LabelValueRow textModuleData : param0) {
                    com.google.android.gms.wallet.wobs.LabelValueRow gTextModuleData = (com.google.android.gms.wallet.wobs.LabelValueRow) textModuleData.getGInstance();
                    java.util.ArrayList<com.google.android.gms.wallet.wobs.LabelValue> columns = gTextModuleData.getColumns();
                    if (columns != null && !columns.isEmpty()) {
                        for (com.google.android.gms.wallet.wobs.LabelValue labelValue : columns) {
                            com.huawei.hms.wallet.pass.AppendField.Builder builder = com.huawei.hms.wallet.pass.AppendField.getBuilder();
                            com.huawei.hms.wallet.pass.AppendField field = builder.setKey("text"+ builder.hashCode()).setValue(labelValue.getValue()).setLabel(labelValue.getLabel()).build();
                            textList.add(field);
                        }
                    }
                }
                com.huawei.hms.wallet.pass.PassObject.Builder hReturn =
                        ((com.huawei.hms.wallet.pass.PassObject.Builder) this.getHInstance()).addTextList(textList);
                if (hReturn == null) {
                    return null;
                }
                return new org.xms.g.wallet.LoyaltyWalletObject.Builder(null, hReturn);
            } else {
                org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.wallet.LoyaltyWalletObject.Builder) this.getGInstance()).addInfoModuleDataLabelValueRows(org.xms.g.utils.Utils.mapCollection2GH(param0, false))");
                com.google.android.gms.wallet.LoyaltyWalletObject.Builder gReturn = ((com.google.android.gms.wallet.LoyaltyWalletObject.Builder) this.getGInstance()).addInfoModuleDataLabelValueRows(org.xms.g.utils.Utils.mapCollection2GH(param0, false));
                return ((gReturn) == null ? null : (new org.xms.g.wallet.LoyaltyWalletObject.Builder(gReturn, null)));
            }
        }
        
        public final org.xms.g.wallet.LoyaltyWalletObject.Builder addLinksModuleDataUri(org.xms.g.wallet.wobs.UriData param0) {
            throw new java.lang.RuntimeException("Not Supported");
        }
        
        public final org.xms.g.wallet.LoyaltyWalletObject.Builder addLinksModuleDataUris(java.util.Collection<org.xms.g.wallet.wobs.UriData> param0) {
            throw new java.lang.RuntimeException("Not Supported");
        }
        
        public final org.xms.g.wallet.LoyaltyWalletObject.Builder addLocation(org.xms.g.maps.model.LatLng param0) {
            if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
                org.xms.g.utils.XmsLog.d("XMSRouter", "addLocation");
                java.util.ArrayList<com.huawei.hms.wallet.pass.Location> locationList = new java.util.ArrayList<>();
                com.huawei.hms.maps.model.LatLng hLatLng = (com.huawei.hms.maps.model.LatLng) param0.getHInstance();
                com.huawei.hms.wallet.pass.Location location = new com.huawei.hms.wallet.pass.Location(String.valueOf(hLatLng.longitude), String.valueOf(hLatLng.latitude));
                locationList.add(location);
                com.huawei.hms.wallet.pass.PassObject.Builder hReturn =
                        ((com.huawei.hms.wallet.pass.PassObject.Builder) this.getHInstance()).addLocationList(locationList);
                if (hReturn == null) {
                    return null;
                }
                return new org.xms.g.wallet.LoyaltyWalletObject.Builder(null, hReturn);
            } else {
                org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.wallet.LoyaltyWalletObject.Builder) this.getGInstance()).addLocation(((com.google.android.gms.maps.model.LatLng) ((param0) == null ? null : (param0.getGInstance()))))");
                com.google.android.gms.wallet.LoyaltyWalletObject.Builder gReturn = ((com.google.android.gms.wallet.LoyaltyWalletObject.Builder) this.getGInstance()).addLocation(((com.google.android.gms.maps.model.LatLng) ((param0) == null ? null : (param0.getGInstance()))));
                return ((gReturn) == null ? null : (new org.xms.g.wallet.LoyaltyWalletObject.Builder(gReturn, null)));
            }
        }
        
        public final org.xms.g.wallet.LoyaltyWalletObject.Builder addLocations(java.util.Collection<org.xms.g.maps.model.LatLng> param0) {
            if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
                org.xms.g.utils.XmsLog.d("XMSRouter", "addLocations");
                java.util.ArrayList<com.huawei.hms.wallet.pass.Location> locationList = new java.util.ArrayList<>();
                for (org.xms.g.maps.model.LatLng latLng : param0) {
                    com.huawei.hms.maps.model.LatLng hLatLng = (com.huawei.hms.maps.model.LatLng) latLng.getHInstance();
                    com.huawei.hms.wallet.pass.Location location = new com.huawei.hms.wallet.pass.Location(String.valueOf(hLatLng.longitude), String.valueOf(hLatLng.latitude));
                    locationList.add(location);
                }
                com.huawei.hms.wallet.pass.PassObject.Builder hReturn =
                        ((com.huawei.hms.wallet.pass.PassObject.Builder) this.getHInstance()).addLocationList(locationList);
                if (hReturn == null) {
                    return null;
                }
                return new org.xms.g.wallet.LoyaltyWalletObject.Builder(null, hReturn);
            } else {
                org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.wallet.LoyaltyWalletObject.Builder) this.getGInstance()).addLocations(org.xms.g.utils.Utils.mapCollection2GH(param0, false))");
                com.google.android.gms.wallet.LoyaltyWalletObject.Builder gReturn = ((com.google.android.gms.wallet.LoyaltyWalletObject.Builder) this.getGInstance()).addLocations(org.xms.g.utils.Utils.mapCollection2GH(param0, false));
                return ((gReturn) == null ? null : (new org.xms.g.wallet.LoyaltyWalletObject.Builder(gReturn, null)));
            }
        }
        
        public final org.xms.g.wallet.LoyaltyWalletObject.Builder addMessage(org.xms.g.wallet.wobs.WalletObjectMessage param0) {
            if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
                org.xms.g.utils.XmsLog.d("XMSRouter", "addMessage");
                java.util.ArrayList<com.huawei.hms.wallet.pass.AppendField> messageList = new java.util.ArrayList<>();
                com.huawei.hms.wallet.pass.AppendField field = (com.huawei.hms.wallet.pass.AppendField) param0.getHInstance();
                messageList.add(field);
                com.huawei.hms.wallet.pass.PassObject.Builder hReturn =
                        ((com.huawei.hms.wallet.pass.PassObject.Builder) this.getHInstance()).addMessageList(messageList);
                if (hReturn == null) {
                    return null;
                }
                return new org.xms.g.wallet.LoyaltyWalletObject.Builder(null, hReturn);
            } else {
                org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.wallet.LoyaltyWalletObject.Builder) this.getGInstance()).addMessage(((com.google.android.gms.wallet.wobs.WalletObjectMessage) ((param0) == null ? null : (param0.getGInstance()))))");
                com.google.android.gms.wallet.LoyaltyWalletObject.Builder gReturn = ((com.google.android.gms.wallet.LoyaltyWalletObject.Builder) this.getGInstance()).addMessage(((com.google.android.gms.wallet.wobs.WalletObjectMessage) ((param0) == null ? null : (param0.getGInstance()))));
                return ((gReturn) == null ? null : (new org.xms.g.wallet.LoyaltyWalletObject.Builder(gReturn, null)));
            }
        }
        
        public final org.xms.g.wallet.LoyaltyWalletObject.Builder addMessages(java.util.Collection<org.xms.g.wallet.wobs.WalletObjectMessage> param0) {
            if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
                org.xms.g.utils.XmsLog.d("XMSRouter", "addMessages");
                java.util.ArrayList<com.huawei.hms.wallet.pass.AppendField> messageList = new java.util.ArrayList<>();
                for (org.xms.g.wallet.wobs.WalletObjectMessage message : param0) {
                    com.huawei.hms.wallet.pass.AppendField field = (com.huawei.hms.wallet.pass.AppendField) message.getHInstance();
                    messageList.add(field);
                }
                com.huawei.hms.wallet.pass.PassObject.Builder hReturn =
                        ((com.huawei.hms.wallet.pass.PassObject.Builder) this.getHInstance()).addMessageList(messageList);
                if (hReturn == null) {
                    return null;
                }
                return new org.xms.g.wallet.LoyaltyWalletObject.Builder(null, hReturn);
            } else {
                org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.wallet.LoyaltyWalletObject.Builder) this.getGInstance()).addMessages(org.xms.g.utils.Utils.mapCollection2GH(param0, false))");
                com.google.android.gms.wallet.LoyaltyWalletObject.Builder gReturn = ((com.google.android.gms.wallet.LoyaltyWalletObject.Builder) this.getGInstance()).addMessages(org.xms.g.utils.Utils.mapCollection2GH(param0, false));
                return ((gReturn) == null ? null : (new org.xms.g.wallet.LoyaltyWalletObject.Builder(gReturn, null)));
            }
        }
        
        public final org.xms.g.wallet.LoyaltyWalletObject.Builder addTextModuleData(org.xms.g.wallet.wobs.TextModuleData param0) {
            if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
                org.xms.g.utils.XmsLog.d("XMSRouter", "addTextModuleData");
                java.util.ArrayList<com.huawei.hms.wallet.pass.AppendField> textList = new java.util.ArrayList<>();
                com.huawei.hms.wallet.pass.AppendField field = (com.huawei.hms.wallet.pass.AppendField) param0.getHInstance();
                textList.add(field);
                com.huawei.hms.wallet.pass.PassObject.Builder hReturn =
                        ((com.huawei.hms.wallet.pass.PassObject.Builder) this.getHInstance()).addTextList(textList);
                if (hReturn == null) {
                    return null;
                }
                return new org.xms.g.wallet.LoyaltyWalletObject.Builder(null, hReturn);
            } else {
                org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.wallet.LoyaltyWalletObject.Builder) this.getGInstance()).addTextModuleData(((com.google.android.gms.wallet.wobs.TextModuleData) ((param0) == null ? null : (param0.getGInstance()))))");
                com.google.android.gms.wallet.LoyaltyWalletObject.Builder gReturn = ((com.google.android.gms.wallet.LoyaltyWalletObject.Builder) this.getGInstance()).addTextModuleData(((com.google.android.gms.wallet.wobs.TextModuleData) ((param0) == null ? null : (param0.getGInstance()))));
                return ((gReturn) == null ? null : (new org.xms.g.wallet.LoyaltyWalletObject.Builder(gReturn, null)));
            }
        }
        
        public final org.xms.g.wallet.LoyaltyWalletObject.Builder addTextModulesData(java.util.Collection<org.xms.g.wallet.wobs.TextModuleData> param0) {
            if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
                org.xms.g.utils.XmsLog.d("XMSRouter", "addTextModulesData");
                java.util.ArrayList<com.huawei.hms.wallet.pass.AppendField> textList = new java.util.ArrayList<>();
                for (org.xms.g.wallet.wobs.TextModuleData textModuleData : param0) {
                    com.huawei.hms.wallet.pass.AppendField field = (com.huawei.hms.wallet.pass.AppendField) textModuleData.getHInstance();
                    textList.add(field);
                }
                com.huawei.hms.wallet.pass.PassObject.Builder hReturn =
                        ((com.huawei.hms.wallet.pass.PassObject.Builder) this.getHInstance()).addTextList(textList);
                if (hReturn == null) {
                    return null;
                }
                return new org.xms.g.wallet.LoyaltyWalletObject.Builder(null, hReturn);
            } else {
                org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.wallet.LoyaltyWalletObject.Builder) this.getGInstance()).addTextModulesData(org.xms.g.utils.Utils.mapCollection2GH(param0, false))");
                com.google.android.gms.wallet.LoyaltyWalletObject.Builder gReturn = ((com.google.android.gms.wallet.LoyaltyWalletObject.Builder) this.getGInstance()).addTextModulesData(org.xms.g.utils.Utils.mapCollection2GH(param0, false));
                return ((gReturn) == null ? null : (new org.xms.g.wallet.LoyaltyWalletObject.Builder(gReturn, null)));
            }
        }
        
        public final org.xms.g.wallet.LoyaltyWalletObject build() {
            if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
                org.xms.g.utils.XmsLog.d("XMSRouter", "hms LoyaltyWalletObject.Builder.build");
                com.huawei.hms.wallet.pass.PassObject.Builder builder = ((com.huawei.hms.wallet.pass.PassObject.Builder) this.getHInstance());
                builder.setPassTypeIdentifier("hwpass.type.loyalty.hmspublic");
                com.huawei.hms.wallet.pass.PassObject hReturn = builder.build();
                return ((hReturn) == null ? null : (new org.xms.g.wallet.LoyaltyWalletObject(null, hReturn)));
            } else {
                org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.wallet.LoyaltyWalletObject.Builder) this.getGInstance()).build()");
                com.google.android.gms.wallet.LoyaltyWalletObject gReturn = ((com.google.android.gms.wallet.LoyaltyWalletObject.Builder) this.getGInstance()).build();
                return ((gReturn) == null ? null : (new org.xms.g.wallet.LoyaltyWalletObject(gReturn, null)));
            }
        }
        
        public final org.xms.g.wallet.LoyaltyWalletObject.Builder setAccountId(java.lang.String param0) {
            if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
                org.xms.g.utils.XmsLog.d("XMSRouter", "setAccountId");
                java.util.ArrayList<com.huawei.hms.wallet.pass.CommonField> fieldList = new java.util.ArrayList<>();
                com.huawei.hms.wallet.pass.CommonField field = com.huawei.hms.wallet.pass.CommonField.getBuilder().setKey(com.huawei.hms.wallet.constant.WalletPassConstant.PASS_COMMON_FIELD_KEY_CARD_NUMBER).setValue(param0).build();
                fieldList.add(field);
                com.huawei.hms.wallet.pass.PassObject.Builder hReturn =
                        ((com.huawei.hms.wallet.pass.PassObject.Builder) this.getHInstance()).addCommonFields(fieldList).setOrganizationPassId(param0);
                if (hReturn == null) {
                    return null;
                }
                return new org.xms.g.wallet.LoyaltyWalletObject.Builder(null, hReturn);
            } else {
                org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.wallet.LoyaltyWalletObject.Builder) this.getGInstance()).setAccountId(param0)");
                com.google.android.gms.wallet.LoyaltyWalletObject.Builder gReturn = ((com.google.android.gms.wallet.LoyaltyWalletObject.Builder) this.getGInstance()).setAccountId(param0);
                return ((gReturn) == null ? null : (new org.xms.g.wallet.LoyaltyWalletObject.Builder(gReturn, null)));
            }
        }
        
        public final org.xms.g.wallet.LoyaltyWalletObject.Builder setAccountName(java.lang.String param0) {
            if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
                org.xms.g.utils.XmsLog.d("XMSRouter", "setAccountName");
                java.util.ArrayList<com.huawei.hms.wallet.pass.CommonField> fieldList = new java.util.ArrayList<>();
                com.huawei.hms.wallet.pass.CommonField field = com.huawei.hms.wallet.pass.CommonField.getBuilder().setKey(com.huawei.hms.wallet.constant.WalletPassConstant.PASS_COMMON_FIELD_KEY_MEMBER_NAME).setValue(param0).build();
                fieldList.add(field);
                com.huawei.hms.wallet.pass.PassObject.Builder hReturn =
                        ((com.huawei.hms.wallet.pass.PassObject.Builder) this.getHInstance()).addCommonFields(fieldList);
                if (hReturn == null) {
                    return null;
                }
                return new org.xms.g.wallet.LoyaltyWalletObject.Builder(null, hReturn);
            } else {
                org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.wallet.LoyaltyWalletObject.Builder) this.getGInstance()).setAccountName(param0)");
                com.google.android.gms.wallet.LoyaltyWalletObject.Builder gReturn = ((com.google.android.gms.wallet.LoyaltyWalletObject.Builder) this.getGInstance()).setAccountName(param0);
                return ((gReturn) == null ? null : (new org.xms.g.wallet.LoyaltyWalletObject.Builder(gReturn, null)));
            }
        }
        
        public final org.xms.g.wallet.LoyaltyWalletObject.Builder setBarcodeAlternateText(java.lang.String param0) {
            throw new java.lang.RuntimeException("Not Supported");
        }
        
        public final org.xms.g.wallet.LoyaltyWalletObject.Builder setBarcodeLabel(java.lang.String param0) {
            throw new java.lang.RuntimeException("Not Supported");
        }
        
        public final org.xms.g.wallet.LoyaltyWalletObject.Builder setBarcodeType(java.lang.String param0) {
            throw new java.lang.RuntimeException("Not Supported");
        }
        
        public final org.xms.g.wallet.LoyaltyWalletObject.Builder setBarcodeValue(java.lang.String param0) {
            throw new java.lang.RuntimeException("Not Supported");
        }
        
        public final org.xms.g.wallet.LoyaltyWalletObject.Builder setClassId(java.lang.String param0) {
            if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
                org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.wallet.pass.PassObject.Builder) this.getHInstance()).setPassStyleIdentifier(param0)");
                com.huawei.hms.wallet.pass.PassObject.Builder hReturn = ((com.huawei.hms.wallet.pass.PassObject.Builder) this.getHInstance()).setPassStyleIdentifier(param0);
                return ((hReturn) == null ? null : (new org.xms.g.wallet.LoyaltyWalletObject.Builder(null, hReturn)));
            } else {
                org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.wallet.LoyaltyWalletObject.Builder) this.getGInstance()).setClassId(param0)");
                com.google.android.gms.wallet.LoyaltyWalletObject.Builder gReturn = ((com.google.android.gms.wallet.LoyaltyWalletObject.Builder) this.getGInstance()).setClassId(param0);
                return ((gReturn) == null ? null : (new org.xms.g.wallet.LoyaltyWalletObject.Builder(gReturn, null)));
            }
        }
        
        public final org.xms.g.wallet.LoyaltyWalletObject.Builder setId(java.lang.String param0) {
            if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
                org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.wallet.pass.PassObject.Builder) this.getHInstance()).setSerialNumber(param0)");
                com.huawei.hms.wallet.pass.PassObject.Builder hReturn = ((com.huawei.hms.wallet.pass.PassObject.Builder) this.getHInstance()).setSerialNumber(param0);
                return ((hReturn) == null ? null : (new org.xms.g.wallet.LoyaltyWalletObject.Builder(null, hReturn)));
            } else {
                org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.wallet.LoyaltyWalletObject.Builder) this.getGInstance()).setId(param0)");
                com.google.android.gms.wallet.LoyaltyWalletObject.Builder gReturn = ((com.google.android.gms.wallet.LoyaltyWalletObject.Builder) this.getGInstance()).setId(param0);
                return ((gReturn) == null ? null : (new org.xms.g.wallet.LoyaltyWalletObject.Builder(gReturn, null)));
            }
        }
        
        public final org.xms.g.wallet.LoyaltyWalletObject.Builder setInfoModuleDataHexBackgroundColor(java.lang.String param0) {
            throw new java.lang.RuntimeException("Not Supported");
        }
        
        public final org.xms.g.wallet.LoyaltyWalletObject.Builder setInfoModuleDataHexFontColor(java.lang.String param0) {
            throw new java.lang.RuntimeException("Not Supported");
        }
        
        public final org.xms.g.wallet.LoyaltyWalletObject.Builder setInfoModuleDataShowLastUpdateTime(boolean param0) {
            if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
                org.xms.g.utils.XmsLog.d("XMSRouter", "hms setInfoModuleDataShowLastUpdateTime");
                return this;
            } else {
                org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.wallet.LoyaltyWalletObject.Builder) this.getGInstance()).setInfoModuleDataShowLastUpdateTime(param0)");
                com.google.android.gms.wallet.LoyaltyWalletObject.Builder gReturn = ((com.google.android.gms.wallet.LoyaltyWalletObject.Builder) this.getGInstance()).setInfoModuleDataShowLastUpdateTime(param0);
                return ((gReturn) == null ? null : (new org.xms.g.wallet.LoyaltyWalletObject.Builder(gReturn, null)));
            }
        }
        
        public final org.xms.g.wallet.LoyaltyWalletObject.Builder setIssuerName(java.lang.String param0) {
            if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
                org.xms.g.utils.XmsLog.d("XMSRouter", "setIssuerName");
                java.util.ArrayList<com.huawei.hms.wallet.pass.CommonField> fieldList = new java.util.ArrayList<>();
                com.huawei.hms.wallet.pass.CommonField field = com.huawei.hms.wallet.pass.CommonField.getBuilder().setKey(com.huawei.hms.wallet.constant.WalletPassConstant.PASS_COMMON_FIELD_KEY_MERCHANT_NAME).setValue(param0).build();
                fieldList.add(field);
                com.huawei.hms.wallet.pass.PassObject.Builder hReturn =
                        ((com.huawei.hms.wallet.pass.PassObject.Builder) this.getHInstance()).addCommonFields(fieldList);
                if (hReturn == null) {
                    return null;
                }
                return new org.xms.g.wallet.LoyaltyWalletObject.Builder(null, hReturn);
            } else {
                org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.wallet.LoyaltyWalletObject.Builder) this.getGInstance()).setIssuerName(param0)");
                com.google.android.gms.wallet.LoyaltyWalletObject.Builder gReturn = ((com.google.android.gms.wallet.LoyaltyWalletObject.Builder) this.getGInstance()).setIssuerName(param0);
                return ((gReturn) == null ? null : (new org.xms.g.wallet.LoyaltyWalletObject.Builder(gReturn, null)));
            }
        }
        
        public final org.xms.g.wallet.LoyaltyWalletObject.Builder setLoyaltyPoints(org.xms.g.wallet.wobs.LoyaltyPoints param0) {
            if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
                org.xms.g.utils.XmsLog.d("XMSRouter", "setLoyaltyPoints");
                com.google.android.gms.wallet.wobs.LoyaltyPoints gLoyaltyPoints = (com.google.android.gms.wallet.wobs.LoyaltyPoints) param0.getGInstance();
                com.google.android.gms.wallet.wobs.LoyaltyPointsBalance gBalance = gLoyaltyPoints.getBalance();
                int balanceType = gBalance.getType();
                String value = "";
                switch (balanceType) {
                    case com.google.android.gms.wallet.wobs.LoyaltyPointsBalance.Type.DOUBLE:
                        value = String.valueOf(gBalance.getDouble());
                        break;
                    case com.google.android.gms.wallet.wobs.LoyaltyPointsBalance.Type.INT:
                        value = String.valueOf(gBalance.getInt());
                        break;
                    case com.google.android.gms.wallet.wobs.LoyaltyPointsBalance.Type.STRING:
                        value = gBalance.getString();
                        break;
                    case com.google.android.gms.wallet.wobs.LoyaltyPointsBalance.Type.MONEY:
                        value = String.valueOf(gBalance.getCurrencyMicros());
                        ((com.huawei.hms.wallet.pass.PassObject.Builder) this.getHInstance())
                                .setCurrencyCode(gBalance.getCurrencyCode());
                        break;
                    default:
                        break;
                }
                java.util.ArrayList<com.huawei.hms.wallet.pass.AppendField> balanceList = new java.util.ArrayList<>();
                com.huawei.hms.wallet.pass.AppendField balance = com.huawei.hms.wallet.pass.AppendField.getBuilder()
                        .setKey(com.huawei.hms.wallet.constant.WalletPassConstant.PASS_APPEND_FIELD_KEY_POINTS)
                        .setValue(value)
                        .setLabel(gLoyaltyPoints.getLabel())
                        .build();
                balanceList.add(balance);
                com.huawei.hms.wallet.pass.PassObject.Builder hReturn =
                        ((com.huawei.hms.wallet.pass.PassObject.Builder) this.getHInstance()).addAppendFields(balanceList);
                if (hReturn == null) {
                    return null;
                }
                return new org.xms.g.wallet.LoyaltyWalletObject.Builder(null, hReturn);
            } else {
                org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.wallet.LoyaltyWalletObject.Builder) this.getGInstance()).setLoyaltyPoints(((com.google.android.gms.wallet.wobs.LoyaltyPoints) ((param0) == null ? null : (param0.getGInstance()))))");
                com.google.android.gms.wallet.LoyaltyWalletObject.Builder gReturn = ((com.google.android.gms.wallet.LoyaltyWalletObject.Builder) this.getGInstance()).setLoyaltyPoints(((com.google.android.gms.wallet.wobs.LoyaltyPoints) ((param0) == null ? null : (param0.getGInstance()))));
                return ((gReturn) == null ? null : (new org.xms.g.wallet.LoyaltyWalletObject.Builder(gReturn, null)));
            }
        }
        
        public final org.xms.g.wallet.LoyaltyWalletObject.Builder setProgramName(java.lang.String param0) {
            if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
                org.xms.g.utils.XmsLog.d("XMSRouter", "setProgramName");
                java.util.ArrayList<com.huawei.hms.wallet.pass.CommonField> textList = new java.util.ArrayList<>();
                com.huawei.hms.wallet.pass.CommonField field = com.huawei.hms.wallet.pass.CommonField.getBuilder().setKey(com.huawei.hms.wallet.constant.WalletPassConstant.PASS_COMMON_FIELD_KEY_NAME).setValue(param0).build();
                textList.add(field);
                com.huawei.hms.wallet.pass.PassObject.Builder hReturn =
                        ((com.huawei.hms.wallet.pass.PassObject.Builder) this.getHInstance()).addCommonFields(textList);
                if (hReturn == null) {
                    return null;
                }
                return new org.xms.g.wallet.LoyaltyWalletObject.Builder(null, hReturn);
            } else {
                org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.wallet.LoyaltyWalletObject.Builder) this.getGInstance()).setProgramName(param0)");
                com.google.android.gms.wallet.LoyaltyWalletObject.Builder gReturn = ((com.google.android.gms.wallet.LoyaltyWalletObject.Builder) this.getGInstance()).setProgramName(param0);
                return ((gReturn) == null ? null : (new org.xms.g.wallet.LoyaltyWalletObject.Builder(gReturn, null)));
            }
        }
        
        public final org.xms.g.wallet.LoyaltyWalletObject.Builder setState(int param0) {
            throw new java.lang.RuntimeException("Not Supported");
        }
        
        public final org.xms.g.wallet.LoyaltyWalletObject.Builder setValidTimeInterval(org.xms.g.wallet.wobs.TimeInterval param0) {
            throw new java.lang.RuntimeException("Not Supported");
        }
        
        public static org.xms.g.wallet.LoyaltyWalletObject.Builder dynamicCast(java.lang.Object param0) {
            return ((org.xms.g.wallet.LoyaltyWalletObject.Builder) param0);
        }
        
        public static boolean isInstance(java.lang.Object param0) {
            if (!(param0 instanceof org.xms.g.utils.XGettable)) {
                return false;
            }
            if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
                return ((org.xms.g.utils.XGettable) param0).getHInstance() instanceof com.huawei.hms.wallet.pass.PassObject.Builder;
            } else {
                return ((org.xms.g.utils.XGettable) param0).getGInstance() instanceof com.google.android.gms.wallet.LoyaltyWalletObject.Builder;
            }
        }
    }
}