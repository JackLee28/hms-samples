package org.xms.g.wallet;

public final class IsReadyToPayRequest extends org.xms.g.utils.XObject implements android.os.Parcelable {
    public static final android.os.Parcelable.Creator CREATOR = new android.os.Parcelable.Creator() {
        
        public org.xms.g.wallet.IsReadyToPayRequest createFromParcel(android.os.Parcel param0) {
            throw new java.lang.RuntimeException("Not Supported");
        }
        
        public org.xms.g.wallet.IsReadyToPayRequest[] newArray(int param0) {
            throw new java.lang.RuntimeException("Not Supported");
        }
    };
    
    public IsReadyToPayRequest(com.google.android.gms.wallet.IsReadyToPayRequest param0, java.lang.Object param1) {
        super(param0, null);
    }
    
    public static org.xms.g.wallet.IsReadyToPayRequest fromJson(java.lang.String param0) {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public java.util.ArrayList<java.lang.Integer> getAllowedCardNetworks() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public java.util.ArrayList<java.lang.Integer> getAllowedPaymentMethods() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public final boolean isExistingPaymentMethodRequired() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static synchronized org.xms.g.wallet.IsReadyToPayRequest.Builder newBuilder() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public final java.lang.String toJson() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public final void writeToParcel(android.os.Parcel param0, int param1) {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public int describeContents() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static org.xms.g.wallet.IsReadyToPayRequest dynamicCast(java.lang.Object param0) {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static boolean isInstance(java.lang.Object param0) {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static final class Builder extends org.xms.g.utils.XObject {
        
        public Builder(com.google.android.gms.wallet.IsReadyToPayRequest.Builder param0, java.lang.Object param1) {
            super(param0, null);
        }
        
        public final org.xms.g.wallet.IsReadyToPayRequest.Builder addAllowedCardNetwork(int param0) {
            throw new java.lang.RuntimeException("Not Supported");
        }
        
        public final org.xms.g.wallet.IsReadyToPayRequest.Builder addAllowedCardNetworks(java.util.Collection<java.lang.Integer> param0) {
            throw new java.lang.RuntimeException("Not Supported");
        }
        
        public final org.xms.g.wallet.IsReadyToPayRequest.Builder addAllowedPaymentMethod(int param0) {
            throw new java.lang.RuntimeException("Not Supported");
        }
        
        public final org.xms.g.wallet.IsReadyToPayRequest.Builder addAllowedPaymentMethods(java.util.Collection<java.lang.Integer> param0) {
            throw new java.lang.RuntimeException("Not Supported");
        }
        
        public final org.xms.g.wallet.IsReadyToPayRequest build() {
            throw new java.lang.RuntimeException("Not Supported");
        }
        
        public final org.xms.g.wallet.IsReadyToPayRequest.Builder setExistingPaymentMethodRequired(boolean param0) {
            throw new java.lang.RuntimeException("Not Supported");
        }
        
        public static org.xms.g.wallet.IsReadyToPayRequest.Builder dynamicCast(java.lang.Object param0) {
            throw new java.lang.RuntimeException("Not Supported");
        }
        
        public static boolean isInstance(java.lang.Object param0) {
            throw new java.lang.RuntimeException("Not Supported");
        }
    }
}