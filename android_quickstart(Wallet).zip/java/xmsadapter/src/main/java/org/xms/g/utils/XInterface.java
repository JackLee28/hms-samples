package org.xms.g.utils;

public interface XInterface {
}
