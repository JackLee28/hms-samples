package org.xms.g.wallet;

public class WalletObjectsClient extends org.xms.g.common.api.ExtensionApi {
    private boolean wrapper = true;
    
    public WalletObjectsClient(com.google.android.gms.wallet.WalletObjectsClient param0, com.huawei.hms.wallet.WalletPassClient param1) {
        super(param0, null);
        this.setHInstance(param1);
        wrapper = true;
    }
    
    public org.xms.g.tasks.Task<org.xms.g.wallet.AutoResolvableVoidResult> createWalletObjects(org.xms.g.wallet.CreateWalletObjectsRequest param0) {
        if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
            org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.wallet.WalletPassClient) this.getHInstance()).createWalletPass(((com.huawei.hms.wallet.CreateWalletPassRequest) ((param0) == null ? null : (param0.getHInstance()))))");
            com.huawei.hmf.tasks.Task hReturn = ((com.huawei.hms.wallet.WalletPassClient) this.getHInstance()).createWalletPass(((com.huawei.hms.wallet.CreateWalletPassRequest) ((param0) == null ? null : (param0.getHInstance()))));
            return ((hReturn) == null ? null : (new org.xms.g.tasks.Task.XImpl(null, hReturn)));
        } else {
            org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.wallet.WalletObjectsClient) this.getGInstance()).createWalletObjects(((com.google.android.gms.wallet.CreateWalletObjectsRequest) ((param0) == null ? null : (param0.getGInstance()))))");
            com.google.android.gms.tasks.Task gReturn = ((com.google.android.gms.wallet.WalletObjectsClient) this.getGInstance()).createWalletObjects(((com.google.android.gms.wallet.CreateWalletObjectsRequest) ((param0) == null ? null : (param0.getGInstance()))));
            return ((gReturn) == null ? null : (new org.xms.g.tasks.Task.XImpl(gReturn, null)));
        }
    }
    
    public java.lang.Object getApiKey() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static org.xms.g.wallet.WalletObjectsClient dynamicCast(java.lang.Object param0) {
        if (param0 instanceof org.xms.g.wallet.WalletObjectsClient) {
            return ((org.xms.g.wallet.WalletObjectsClient) param0);
        }
        if (param0 instanceof org.xms.g.utils.XGettable) {
            com.google.android.gms.wallet.WalletObjectsClient gReturn = ((com.google.android.gms.wallet.WalletObjectsClient) ((org.xms.g.utils.XGettable) param0).getGInstance());
            com.huawei.hms.wallet.WalletPassClient hReturn = ((com.huawei.hms.wallet.WalletPassClient) ((org.xms.g.utils.XGettable) param0).getHInstance());
            return new org.xms.g.wallet.WalletObjectsClient(gReturn, hReturn);
        }
        return ((org.xms.g.wallet.WalletObjectsClient) param0);
    }
    
    public static boolean isInstance(java.lang.Object param0) {
        if (!(param0 instanceof org.xms.g.utils.XGettable)) {
            return false;
        }
        if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
            return ((org.xms.g.utils.XGettable) param0).getHInstance() instanceof com.huawei.hms.wallet.WalletPassClient;
        } else {
            return ((org.xms.g.utils.XGettable) param0).getGInstance() instanceof com.google.android.gms.wallet.WalletObjectsClient;
        }
    }
}