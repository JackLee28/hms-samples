package org.xms.g.wallet;

public final class GiftCardWalletObject extends org.xms.g.utils.XObject implements android.os.Parcelable {
    public static final android.os.Parcelable.Creator CREATOR = new android.os.Parcelable.Creator() {
        
        public org.xms.g.wallet.GiftCardWalletObject createFromParcel(android.os.Parcel param0) {
            throw new java.lang.RuntimeException("Not Supported");
        }
        
        public org.xms.g.wallet.GiftCardWalletObject[] newArray(int param0) {
            throw new java.lang.RuntimeException("Not Supported");
        }
    };
    private java.lang.String getAppendFieldValueByKey(java.lang.String key) {
        if (key == null || key.isEmpty()) {
            return null;
        }
        java.util.ArrayList<com.huawei.hms.wallet.pass.AppendField> appendFields =
                ((com.huawei.hms.wallet.pass.PassObject) this.getHInstance()).getAppendFields();
        for (com.huawei.hms.wallet.pass.AppendField field : appendFields) {
            if (key.equals(field.getKey())) {
                return field.getValue();
            }
        }
        return null;
    }
    private java.lang.String getCommonFieldValueByKey(java.lang.String key) {
        if (key == null || key.isEmpty()) {
            return null;
        }
        java.util.ArrayList<com.huawei.hms.wallet.pass.CommonField> commonFields =
                ((com.huawei.hms.wallet.pass.PassObject) this.getHInstance()).getCommonField();
        for (com.huawei.hms.wallet.pass.CommonField field : commonFields) {
            if (key.equals(field.getKey())) {
                return field.getValue();
            }
        }
        return null;
    }
    private long revertTime(String formatTime) {
        java.text.SimpleDateFormat format = new java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
        try {
            java.util.Date date = format.parse(formatTime);
            return date.getTime();
        } catch (java.text.ParseException e) {
            return 0;
        }
    }
    
    public GiftCardWalletObject(com.google.android.gms.wallet.GiftCardWalletObject param0, com.huawei.hms.wallet.pass.PassObject param1) {
        super(param0, null);
        this.setHInstance(param1);
    }
    
    public final java.lang.String getBalanceCurrencyCode() {
        if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
            org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.wallet.pass.PassObject) this.getHInstance()).getCurrencyCode()");
            return ((com.huawei.hms.wallet.pass.PassObject) this.getHInstance()).getCurrencyCode();
        } else {
            org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.wallet.GiftCardWalletObject) this.getGInstance()).getBalanceCurrencyCode()");
            return ((com.google.android.gms.wallet.GiftCardWalletObject) this.getGInstance()).getBalanceCurrencyCode();
        }
    }
    
    public final long getBalanceMicros() {
        if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
            org.xms.g.utils.XmsLog.d("XMSRouter", "hms getBalanceMicros");
            java.lang.String balance = getCommonFieldValueByKey(
                    com.huawei.hms.wallet.constant.WalletPassConstant.PASS_COMMON_FIELD_KEY_BALANCE);
            try {
                return Long.parseLong(balance);
            } catch (java.lang.NumberFormatException e) {
                return 0;
            }
        } else {
            org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.wallet.GiftCardWalletObject) this.getGInstance()).getBalanceMicros()");
            return ((com.google.android.gms.wallet.GiftCardWalletObject) this.getGInstance()).getBalanceMicros();
        }
    }
    
    public final long getBalanceUpdateTime() {
        if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
            org.xms.g.utils.XmsLog.d("XMSRouter", "hms getBalanceUpdateTime");
            java.lang.String balanceUpdateTime = getCommonFieldValueByKey(
                    com.huawei.hms.wallet.constant.WalletPassConstant.PASS_COMMON_FIELD_KEY_BALANCE_REFRESH_TIME);
            return revertTime(balanceUpdateTime);
        } else {
            org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.wallet.GiftCardWalletObject) this.getGInstance()).getBalanceUpdateTime()");
            return ((com.google.android.gms.wallet.GiftCardWalletObject) this.getGInstance()).getBalanceUpdateTime();
        }
    }
    
    public final java.lang.String getBarcodeAlternateText() {
        if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
            org.xms.g.utils.XmsLog.d("XMSRouter", "hms getBarcodeAlternateText");
            com.huawei.hms.wallet.pass.BarCode barCode = ((com.huawei.hms.wallet.pass.PassObject) this.getHInstance()).getBarCode();
            if (barCode == null) {
                return null;
            } else {
                return barCode.getText();
            }
        } else {
            org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.wallet.GiftCardWalletObject) this.getGInstance()).getBarcodeAlternateText()");
            return ((com.google.android.gms.wallet.GiftCardWalletObject) this.getGInstance()).getBarcodeAlternateText();
        }
    }
    
    public final java.lang.String getBarcodeLabel() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public final java.lang.String getBarcodeType() {
        if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
            org.xms.g.utils.XmsLog.d("XMSRouter", "hms getBarcodeType");
            com.huawei.hms.wallet.pass.BarCode barCode = ((com.huawei.hms.wallet.pass.PassObject) this.getHInstance()).getBarCode();
            if (barCode == null) {
                return null;
            } else {
                return barCode.getType();
            }
        } else {
            org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.wallet.GiftCardWalletObject) this.getGInstance()).getBarcodeType()");
            return ((com.google.android.gms.wallet.GiftCardWalletObject) this.getGInstance()).getBarcodeType();
        }
    }
    
    public final java.lang.String getBarcodeValue() {
        if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
            org.xms.g.utils.XmsLog.d("XMSRouter", "hms getBarcodeValue");
            com.huawei.hms.wallet.pass.BarCode barCode = ((com.huawei.hms.wallet.pass.PassObject) this.getHInstance()).getBarCode();
            if (barCode == null) {
                return null;
            } else {
                return barCode.getValue();
            }
        } else {
            org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.wallet.GiftCardWalletObject) this.getGInstance()).getBarcodeValue()");
            return ((com.google.android.gms.wallet.GiftCardWalletObject) this.getGInstance()).getBarcodeValue();
        }
    }
    
    public final java.lang.String getCardIdentifier() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public final java.lang.String getCardNumber() {
        if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
            org.xms.g.utils.XmsLog.d("XMSRouter", "hms getCardNumber");
            return getCommonFieldValueByKey(
                    com.huawei.hms.wallet.constant.WalletPassConstant.PASS_COMMON_FIELD_KEY_CARD_NUMBER);
        } else {
            org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.wallet.GiftCardWalletObject) this.getGInstance()).getCardNumber()");
            return ((com.google.android.gms.wallet.GiftCardWalletObject) this.getGInstance()).getCardNumber();
        }
    }
    
    public final java.lang.String getClassId() {
        if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
            org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.wallet.pass.PassObject) this.getHInstance()).getPassStyleIdentifier()");
            return ((com.huawei.hms.wallet.pass.PassObject) this.getHInstance()).getPassStyleIdentifier();
        } else {
            org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.wallet.GiftCardWalletObject) this.getGInstance()).getClassId()");
            return ((com.google.android.gms.wallet.GiftCardWalletObject) this.getGInstance()).getClassId();
        }
    }
    
    public final java.lang.String getEventNumber() {
        if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
            org.xms.g.utils.XmsLog.d("XMSRouter", "hms getEventNumber");
            return getAppendFieldValueByKey(
                    com.huawei.hms.wallet.constant.WalletPassConstant.PASS_APPEND_FIELD_KEY_EVENT_NUMBER);
        } else {
            org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.wallet.GiftCardWalletObject) this.getGInstance()).getEventNumber()");
            return ((com.google.android.gms.wallet.GiftCardWalletObject) this.getGInstance()).getEventNumber();
        }
    }
    
    public final java.lang.String getId() {
        if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
            org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.wallet.pass.PassObject) this.getHInstance()).getOrganizationPassId()");
            return ((com.huawei.hms.wallet.pass.PassObject) this.getHInstance()).getOrganizationPassId();
        } else {
            org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.wallet.GiftCardWalletObject) this.getGInstance()).getId()");
            return ((com.google.android.gms.wallet.GiftCardWalletObject) this.getGInstance()).getId();
        }
    }
    
    public java.util.ArrayList<org.xms.g.wallet.wobs.UriData> getImageModuleDataMainImageUris() {
        if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
            org.xms.g.utils.XmsLog.d("XMSRouter", "hms getImageModuleDataMainImageUris");
            java.util.ArrayList hReturn = ((com.huawei.hms.wallet.pass.PassObject) this.getHInstance()).getImageList();
            return ((java.util.ArrayList) org.xms.g.utils.Utils.mapCollection(hReturn, new org.xms.g.utils.Function<com.huawei.hms.wallet.pass.AppendField, org.xms.g.wallet.wobs.UriData>() {
                public org.xms.g.wallet.wobs.UriData apply(com.huawei.hms.wallet.pass.AppendField param0) {
                    return new org.xms.g.wallet.wobs.UriData(null, param0);
                }
            }));
        } else {
            org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.wallet.GiftCardWalletObject) this.getGInstance()).getImageModuleDataMainImageUris()");
            java.util.ArrayList gReturn = ((com.google.android.gms.wallet.GiftCardWalletObject) this.getGInstance()).getImageModuleDataMainImageUris();
            return ((java.util.ArrayList) org.xms.g.utils.Utils.mapCollection(gReturn, new org.xms.g.utils.Function<com.google.android.gms.wallet.wobs.UriData, org.xms.g.wallet.wobs.UriData>() {
                
                public org.xms.g.wallet.wobs.UriData apply(com.google.android.gms.wallet.wobs.UriData param0) {
                    return new org.xms.g.wallet.wobs.UriData(param0, null);
                }
            }));
        }
    }
    
    public final java.lang.String getInfoModuleDataHexBackgroundColor() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public final java.lang.String getInfoModuleDataHexFontColor() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public java.util.ArrayList<org.xms.g.wallet.wobs.LabelValueRow> getInfoModuleDataLabelValueRows() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public final boolean getInfoModuleDataShowLastUpdateTime() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public final java.lang.String getIssuerName() {
        if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
            org.xms.g.utils.XmsLog.d("XMSRouter", "hms getIssuerName");
            return getCommonFieldValueByKey(
                    com.huawei.hms.wallet.constant.WalletPassConstant.PASS_COMMON_FIELD_KEY_MERCHANT_NAME);
        } else {
            org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.wallet.GiftCardWalletObject) this.getGInstance()).getIssuerName()");
            return ((com.google.android.gms.wallet.GiftCardWalletObject) this.getGInstance()).getIssuerName();
        }
    }
    
    public java.util.ArrayList<org.xms.g.wallet.wobs.UriData> getLinksModuleDataUris() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public java.util.ArrayList<org.xms.g.maps.model.LatLng> getLocations() {
        if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
            org.xms.g.utils.XmsLog.d("XMSRouter", "hms getLocations");
            java.util.ArrayList hReturn = ((com.huawei.hms.wallet.pass.PassObject) this.getHInstance()).getLocationList();
            return ((java.util.ArrayList) org.xms.g.utils.Utils.mapCollection(hReturn, new org.xms.g.utils.Function<com.huawei.hms.wallet.pass.Location, org.xms.g.maps.model.LatLng>() {
                public org.xms.g.maps.model.LatLng apply(com.huawei.hms.wallet.pass.Location param0) {
                    com.huawei.hms.maps.model.LatLng latLng = null;
                    if (param0 != null) {
                        latLng = new com.huawei.hms.maps.model.LatLng(
                                Double.parseDouble(param0.getLatitude()), Double.parseDouble(param0.getLongitude())
                        );
                    }
                    return new org.xms.g.maps.model.LatLng(null, latLng);
                }
            }));
        } else {
            org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.wallet.GiftCardWalletObject) this.getGInstance()).getLocations()");
            java.util.ArrayList gReturn = ((com.google.android.gms.wallet.GiftCardWalletObject) this.getGInstance()).getLocations();
            return ((java.util.ArrayList) org.xms.g.utils.Utils.mapCollection(gReturn, new org.xms.g.utils.Function<com.google.android.gms.maps.model.LatLng, org.xms.g.maps.model.LatLng>() {
                
                public org.xms.g.maps.model.LatLng apply(com.google.android.gms.maps.model.LatLng param0) {
                    return new org.xms.g.maps.model.LatLng(param0, null);
                }
            }));
        }
    }
    
    public java.util.ArrayList<org.xms.g.wallet.wobs.WalletObjectMessage> getMessages() {
        if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
            org.xms.g.utils.XmsLog.d("XMSRouter", "hms getMessages");
            java.util.ArrayList hReturn = ((com.huawei.hms.wallet.pass.PassObject) this.getHInstance()).getMessageList();
            return ((java.util.ArrayList) org.xms.g.utils.Utils.mapCollection(hReturn, new org.xms.g.utils.Function<com.huawei.hms.wallet.pass.AppendField, org.xms.g.wallet.wobs.WalletObjectMessage>() {
                public org.xms.g.wallet.wobs.WalletObjectMessage apply(com.huawei.hms.wallet.pass.AppendField param0) {
                    return new org.xms.g.wallet.wobs.WalletObjectMessage(null, param0);
                }
            }));
        } else {
            org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.wallet.GiftCardWalletObject) this.getGInstance()).getMessages()");
            java.util.ArrayList gReturn = ((com.google.android.gms.wallet.GiftCardWalletObject) this.getGInstance()).getMessages();
            return ((java.util.ArrayList) org.xms.g.utils.Utils.mapCollection(gReturn, new org.xms.g.utils.Function<com.google.android.gms.wallet.wobs.WalletObjectMessage, org.xms.g.wallet.wobs.WalletObjectMessage>() {
                
                public org.xms.g.wallet.wobs.WalletObjectMessage apply(com.google.android.gms.wallet.wobs.WalletObjectMessage param0) {
                    return new org.xms.g.wallet.wobs.WalletObjectMessage(param0, null);
                }
            }));
        }
    }
    
    public final java.lang.String getPin() {
        if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
            org.xms.g.utils.XmsLog.d("XMSRouter", "hms getPin");
            return getCommonFieldValueByKey(
                    com.huawei.hms.wallet.constant.WalletPassConstant.PASS_COMMON_FIELD_KEY_BLANCE_PIN);
        } else {
            org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.wallet.GiftCardWalletObject) this.getGInstance()).getPin()");
            return ((com.google.android.gms.wallet.GiftCardWalletObject) this.getGInstance()).getPin();
        }
    }
    
    public final int getState() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public java.util.ArrayList<org.xms.g.wallet.wobs.TextModuleData> getTextModulesData() {
        if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
            org.xms.g.utils.XmsLog.d("XMSRouter", "hms getTextModulesData");
            java.util.ArrayList hReturn = ((com.huawei.hms.wallet.pass.PassObject) this.getHInstance()).getTextList();
            return ((java.util.ArrayList) org.xms.g.utils.Utils.mapCollection(hReturn, new org.xms.g.utils.Function<com.huawei.hms.wallet.pass.AppendField, org.xms.g.wallet.wobs.TextModuleData>() {
                public org.xms.g.wallet.wobs.TextModuleData apply(com.huawei.hms.wallet.pass.AppendField param0) {
                    return new org.xms.g.wallet.wobs.TextModuleData(null, param0);
                }
            }));
        } else {
            org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.wallet.GiftCardWalletObject) this.getGInstance()).getTextModulesData()");
            java.util.ArrayList gReturn = ((com.google.android.gms.wallet.GiftCardWalletObject) this.getGInstance()).getTextModulesData();
            return ((java.util.ArrayList) org.xms.g.utils.Utils.mapCollection(gReturn, new org.xms.g.utils.Function<com.google.android.gms.wallet.wobs.TextModuleData, org.xms.g.wallet.wobs.TextModuleData>() {
                
                public org.xms.g.wallet.wobs.TextModuleData apply(com.google.android.gms.wallet.wobs.TextModuleData param0) {
                    return new org.xms.g.wallet.wobs.TextModuleData(param0, null);
                }
            }));
        }
    }
    
    public final java.lang.String getTitle() {
        if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
            org.xms.g.utils.XmsLog.d("XMSRouter", "hms getTitle");
            return getCommonFieldValueByKey(
                    com.huawei.hms.wallet.constant.WalletPassConstant.PASS_COMMON_FIELD_KEY_NAME);
        } else {
            org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.wallet.GiftCardWalletObject) this.getGInstance()).getTitle()");
            return ((com.google.android.gms.wallet.GiftCardWalletObject) this.getGInstance()).getTitle();
        }
    }
    
    public final org.xms.g.wallet.wobs.TimeInterval getValidTimeInterval() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static org.xms.g.wallet.GiftCardWalletObject.Builder newBuilder() {
        if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
            org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hms.wallet.pass.PassObject.getBuilder()");
            com.huawei.hms.wallet.pass.PassObject.Builder hReturn = com.huawei.hms.wallet.pass.PassObject.getBuilder();
            return ((hReturn) == null ? null : (new org.xms.g.wallet.GiftCardWalletObject.Builder(null, hReturn)));
        } else {
            org.xms.g.utils.XmsLog.d("XMSRouter", "com.google.android.gms.wallet.GiftCardWalletObject.newBuilder()");
            com.google.android.gms.wallet.GiftCardWalletObject.Builder gReturn = com.google.android.gms.wallet.GiftCardWalletObject.newBuilder();
            return ((gReturn) == null ? null : (new org.xms.g.wallet.GiftCardWalletObject.Builder(gReturn, null)));
        }
    }
    
    public final void writeToParcel(android.os.Parcel param0, int param1) {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public int describeContents() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static org.xms.g.wallet.GiftCardWalletObject dynamicCast(java.lang.Object param0) {
        return ((org.xms.g.wallet.GiftCardWalletObject) param0);
    }
    
    public static boolean isInstance(java.lang.Object param0) {
        if (!(param0 instanceof org.xms.g.utils.XGettable)) {
            return false;
        }
        if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
            return ((org.xms.g.utils.XGettable) param0).getHInstance() instanceof com.huawei.hms.wallet.pass.PassObject;
        } else {
            return ((org.xms.g.utils.XGettable) param0).getGInstance() instanceof com.google.android.gms.wallet.GiftCardWalletObject;
        }
    }
    
    public static final class Builder extends org.xms.g.utils.XObject {
        private String formatTime(long srcTime) {
            org.xms.g.utils.XmsLog.d("XMSRouter", "formatTime");
            String time = "";
            java.text.SimpleDateFormat format = new java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
            if (srcTime > 0L) {
                time = format.format(new java.util.Date(srcTime));
            }
            return time;
        }
        
        public Builder(com.google.android.gms.wallet.GiftCardWalletObject.Builder param0, com.huawei.hms.wallet.pass.PassObject.Builder param1) {
            super(param0, null);
            this.setHInstance(param1);
        }
        
        public final org.xms.g.wallet.GiftCardWalletObject.Builder addImageModuleDataMainImageUri(org.xms.g.wallet.wobs.UriData param0) {
            if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
                org.xms.g.utils.XmsLog.d("XMSRouter", "addImageModuleDataMainImageUri");
                java.util.ArrayList<com.huawei.hms.wallet.pass.AppendField> imageList = new java.util.ArrayList<>();
                com.huawei.hms.wallet.pass.AppendField field = (com.huawei.hms.wallet.pass.AppendField) param0.getHInstance();
                imageList.add(field);
                com.huawei.hms.wallet.pass.PassObject.Builder hReturn =
                        ((com.huawei.hms.wallet.pass.PassObject.Builder) this.getHInstance()).addImageList(imageList);
                if (hReturn == null) {
                    return null;
                }
                return new org.xms.g.wallet.GiftCardWalletObject.Builder(null, hReturn);
            } else {
                org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.wallet.GiftCardWalletObject.Builder) this.getGInstance()).addImageModuleDataMainImageUri(((com.google.android.gms.wallet.wobs.UriData) ((param0) == null ? null : (param0.getGInstance()))))");
                com.google.android.gms.wallet.GiftCardWalletObject.Builder gReturn = ((com.google.android.gms.wallet.GiftCardWalletObject.Builder) this.getGInstance()).addImageModuleDataMainImageUri(((com.google.android.gms.wallet.wobs.UriData) ((param0) == null ? null : (param0.getGInstance()))));
                return ((gReturn) == null ? null : (new org.xms.g.wallet.GiftCardWalletObject.Builder(gReturn, null)));
            }
        }
        
        public final org.xms.g.wallet.GiftCardWalletObject.Builder addImageModuleDataMainImageUris(java.util.Collection<org.xms.g.wallet.wobs.UriData> param0) {
            if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
                org.xms.g.utils.XmsLog.d("XMSRouter", "addImageModuleDataMainImageUris");
                java.util.ArrayList<com.huawei.hms.wallet.pass.AppendField> imageList = new java.util.ArrayList<>();
                for (org.xms.g.wallet.wobs.UriData uriData : param0) {
                    com.huawei.hms.wallet.pass.AppendField field = (com.huawei.hms.wallet.pass.AppendField) uriData.getHInstance();
                    imageList.add(field);
                }
                com.huawei.hms.wallet.pass.PassObject.Builder hReturn =
                        ((com.huawei.hms.wallet.pass.PassObject.Builder) this.getHInstance()).addImageList(imageList);
                if (hReturn == null) {
                    return null;
                }
                return new org.xms.g.wallet.GiftCardWalletObject.Builder(null, hReturn);
            } else {
                org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.wallet.GiftCardWalletObject.Builder) this.getGInstance()).addImageModuleDataMainImageUris(org.xms.g.utils.Utils.mapCollection2GH(param0, false))");
                com.google.android.gms.wallet.GiftCardWalletObject.Builder gReturn = ((com.google.android.gms.wallet.GiftCardWalletObject.Builder) this.getGInstance()).addImageModuleDataMainImageUris(org.xms.g.utils.Utils.mapCollection2GH(param0, false));
                return ((gReturn) == null ? null : (new org.xms.g.wallet.GiftCardWalletObject.Builder(gReturn, null)));
            }
        }
        
        public final org.xms.g.wallet.GiftCardWalletObject.Builder addInfoModuleDataLabelValueRow(org.xms.g.wallet.wobs.LabelValueRow param0) {
            if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
                org.xms.g.utils.XmsLog.d("XMSRouter", "addInfoModuleDataLabelValueRow");
                java.util.ArrayList<com.huawei.hms.wallet.pass.AppendField> textList = new java.util.ArrayList<>();
                com.google.android.gms.wallet.wobs.LabelValueRow gTextModuleData = (com.google.android.gms.wallet.wobs.LabelValueRow) param0.getGInstance();
                java.util.ArrayList<com.google.android.gms.wallet.wobs.LabelValue> columns = gTextModuleData.getColumns();
                if (columns != null && !columns.isEmpty()) {
                    for (com.google.android.gms.wallet.wobs.LabelValue labelValue : columns) {
                        com.huawei.hms.wallet.pass.AppendField.Builder builder = com.huawei.hms.wallet.pass.AppendField.getBuilder();
                        com.huawei.hms.wallet.pass.AppendField field = builder.setKey("text"+ builder.hashCode()).setValue(labelValue.getValue()).setLabel(labelValue.getLabel()).build();
                        textList.add(field);
                    }
                }
                com.huawei.hms.wallet.pass.PassObject.Builder hReturn =
                        ((com.huawei.hms.wallet.pass.PassObject.Builder) this.getHInstance()).addTextList(textList);
                if (hReturn == null) {
                    return null;
                }
                return new org.xms.g.wallet.GiftCardWalletObject.Builder(null, hReturn);
            } else {
                org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.wallet.GiftCardWalletObject.Builder) this.getGInstance()).addInfoModuleDataLabelValueRow(((com.google.android.gms.wallet.wobs.LabelValueRow) ((param0) == null ? null : (param0.getGInstance()))))");
                com.google.android.gms.wallet.GiftCardWalletObject.Builder gReturn = ((com.google.android.gms.wallet.GiftCardWalletObject.Builder) this.getGInstance()).addInfoModuleDataLabelValueRow(((com.google.android.gms.wallet.wobs.LabelValueRow) ((param0) == null ? null : (param0.getGInstance()))));
                return ((gReturn) == null ? null : (new org.xms.g.wallet.GiftCardWalletObject.Builder(gReturn, null)));
            }
        }
        
        public final org.xms.g.wallet.GiftCardWalletObject.Builder addInfoModuleDataLabelValueRows(java.util.Collection<org.xms.g.wallet.wobs.LabelValueRow> param0) {
            if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
                org.xms.g.utils.XmsLog.d("XMSRouter", "addInfoModuleDataLabelValueRows");
                java.util.ArrayList<com.huawei.hms.wallet.pass.AppendField> textList = new java.util.ArrayList<>();
                for (org.xms.g.wallet.wobs.LabelValueRow textModuleData : param0) {
                    com.google.android.gms.wallet.wobs.LabelValueRow gTextModuleData = (com.google.android.gms.wallet.wobs.LabelValueRow) textModuleData.getGInstance();
                    java.util.ArrayList<com.google.android.gms.wallet.wobs.LabelValue> columns = gTextModuleData.getColumns();
                    if (columns != null && !columns.isEmpty()) {
                        for (com.google.android.gms.wallet.wobs.LabelValue labelValue : columns) {
                            com.huawei.hms.wallet.pass.AppendField.Builder builder = com.huawei.hms.wallet.pass.AppendField.getBuilder();
                            com.huawei.hms.wallet.pass.AppendField field = builder.setKey("text"+ builder.hashCode()).setValue(labelValue.getValue()).setLabel(labelValue.getLabel()).build();
                            textList.add(field);
                        }
                    }
                }
                com.huawei.hms.wallet.pass.PassObject.Builder hReturn =
                        ((com.huawei.hms.wallet.pass.PassObject.Builder) this.getHInstance()).addTextList(textList);
                if (hReturn == null) {
                    return null;
                }
                return new org.xms.g.wallet.GiftCardWalletObject.Builder(null, hReturn);
            } else {
                org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.wallet.GiftCardWalletObject.Builder) this.getGInstance()).addInfoModuleDataLabelValueRows(org.xms.g.utils.Utils.mapCollection2GH(param0, false))");
                com.google.android.gms.wallet.GiftCardWalletObject.Builder gReturn = ((com.google.android.gms.wallet.GiftCardWalletObject.Builder) this.getGInstance()).addInfoModuleDataLabelValueRows(org.xms.g.utils.Utils.mapCollection2GH(param0, false));
                return ((gReturn) == null ? null : (new org.xms.g.wallet.GiftCardWalletObject.Builder(gReturn, null)));
            }
        }
        
        public final org.xms.g.wallet.GiftCardWalletObject.Builder addLinksModuleDataUri(org.xms.g.wallet.wobs.UriData param0) {
            throw new java.lang.RuntimeException("Not Supported");
        }
        
        public final org.xms.g.wallet.GiftCardWalletObject.Builder addLinksModuleDataUris(java.util.Collection<org.xms.g.wallet.wobs.UriData> param0) {
            throw new java.lang.RuntimeException("Not Supported");
        }
        
        public final org.xms.g.wallet.GiftCardWalletObject.Builder addLocation(org.xms.g.maps.model.LatLng param0) {
            if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
                org.xms.g.utils.XmsLog.d("XMSRouter", "addLocation");
                java.util.ArrayList<com.huawei.hms.wallet.pass.Location> locationList = new java.util.ArrayList<>();
                com.huawei.hms.maps.model.LatLng hLatLng = (com.huawei.hms.maps.model.LatLng) param0.getHInstance();
                com.huawei.hms.wallet.pass.Location location = new com.huawei.hms.wallet.pass.Location(String.valueOf(hLatLng.longitude), String.valueOf(hLatLng.latitude));
                locationList.add(location);
                com.huawei.hms.wallet.pass.PassObject.Builder hReturn =
                        ((com.huawei.hms.wallet.pass.PassObject.Builder) this.getHInstance()).addLocationList(locationList);
                if (hReturn == null) {
                    return null;
                }
                return new org.xms.g.wallet.GiftCardWalletObject.Builder(null, hReturn);
            } else {
                org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.wallet.GiftCardWalletObject.Builder) this.getGInstance()).addLocation(((com.google.android.gms.maps.model.LatLng) ((param0) == null ? null : (param0.getGInstance()))))");
                com.google.android.gms.wallet.GiftCardWalletObject.Builder gReturn = ((com.google.android.gms.wallet.GiftCardWalletObject.Builder) this.getGInstance()).addLocation(((com.google.android.gms.maps.model.LatLng) ((param0) == null ? null : (param0.getGInstance()))));
                return ((gReturn) == null ? null : (new org.xms.g.wallet.GiftCardWalletObject.Builder(gReturn, null)));
            }
        }
        
        public final org.xms.g.wallet.GiftCardWalletObject.Builder addLocations(java.util.Collection<org.xms.g.maps.model.LatLng> param0) {
            if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
                org.xms.g.utils.XmsLog.d("XMSRouter", "addLocations");
                java.util.ArrayList<com.huawei.hms.wallet.pass.Location> locationList = new java.util.ArrayList<>();
                for (org.xms.g.maps.model.LatLng latLng : param0) {
                    com.huawei.hms.maps.model.LatLng hLatLng = (com.huawei.hms.maps.model.LatLng) latLng.getHInstance();
                    com.huawei.hms.wallet.pass.Location location = new com.huawei.hms.wallet.pass.Location(String.valueOf(hLatLng.longitude), String.valueOf(hLatLng.latitude));
                    locationList.add(location);
                }
                com.huawei.hms.wallet.pass.PassObject.Builder hReturn =
                        ((com.huawei.hms.wallet.pass.PassObject.Builder) this.getHInstance()).addLocationList(locationList);
                if (hReturn == null) {
                    return null;
                }
                return new org.xms.g.wallet.GiftCardWalletObject.Builder(null, hReturn);
            } else {
                org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.wallet.GiftCardWalletObject.Builder) this.getGInstance()).addLocations(org.xms.g.utils.Utils.mapCollection2GH(param0, false))");
                com.google.android.gms.wallet.GiftCardWalletObject.Builder gReturn = ((com.google.android.gms.wallet.GiftCardWalletObject.Builder) this.getGInstance()).addLocations(org.xms.g.utils.Utils.mapCollection2GH(param0, false));
                return ((gReturn) == null ? null : (new org.xms.g.wallet.GiftCardWalletObject.Builder(gReturn, null)));
            }
        }
        
        public final org.xms.g.wallet.GiftCardWalletObject.Builder addMessage(org.xms.g.wallet.wobs.WalletObjectMessage param0) {
            if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
                org.xms.g.utils.XmsLog.d("XMSRouter", "addMessage");
                java.util.ArrayList<com.huawei.hms.wallet.pass.AppendField> messageList = new java.util.ArrayList<>();
                com.huawei.hms.wallet.pass.AppendField field = (com.huawei.hms.wallet.pass.AppendField) param0.getHInstance();
                messageList.add(field);
                com.huawei.hms.wallet.pass.PassObject.Builder hReturn =
                        ((com.huawei.hms.wallet.pass.PassObject.Builder) this.getHInstance()).addMessageList(messageList);
                if (hReturn == null) {
                    return null;
                }
                return new org.xms.g.wallet.GiftCardWalletObject.Builder(null, hReturn);
            } else {
                org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.wallet.GiftCardWalletObject.Builder) this.getGInstance()).addMessage(((com.google.android.gms.wallet.wobs.WalletObjectMessage) ((param0) == null ? null : (param0.getGInstance()))))");
                com.google.android.gms.wallet.GiftCardWalletObject.Builder gReturn = ((com.google.android.gms.wallet.GiftCardWalletObject.Builder) this.getGInstance()).addMessage(((com.google.android.gms.wallet.wobs.WalletObjectMessage) ((param0) == null ? null : (param0.getGInstance()))));
                return ((gReturn) == null ? null : (new org.xms.g.wallet.GiftCardWalletObject.Builder(gReturn, null)));
            }
        }
        
        public final org.xms.g.wallet.GiftCardWalletObject.Builder addMessages(java.util.Collection<org.xms.g.wallet.wobs.WalletObjectMessage> param0) {
            if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
                org.xms.g.utils.XmsLog.d("XMSRouter", "addMessages");
                java.util.ArrayList<com.huawei.hms.wallet.pass.AppendField> messageList = new java.util.ArrayList<>();
                for (org.xms.g.wallet.wobs.WalletObjectMessage message : param0) {
                    com.huawei.hms.wallet.pass.AppendField field = (com.huawei.hms.wallet.pass.AppendField) message.getHInstance();
                    messageList.add(field);
                }
                com.huawei.hms.wallet.pass.PassObject.Builder hReturn =
                        ((com.huawei.hms.wallet.pass.PassObject.Builder) this.getHInstance()).addMessageList(messageList);
                if (hReturn == null) {
                    return null;
                }
                return new org.xms.g.wallet.GiftCardWalletObject.Builder(null, hReturn);
            } else {
                org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.wallet.GiftCardWalletObject.Builder) this.getGInstance()).addMessages(org.xms.g.utils.Utils.mapCollection2GH(param0, false))");
                com.google.android.gms.wallet.GiftCardWalletObject.Builder gReturn = ((com.google.android.gms.wallet.GiftCardWalletObject.Builder) this.getGInstance()).addMessages(org.xms.g.utils.Utils.mapCollection2GH(param0, false));
                return ((gReturn) == null ? null : (new org.xms.g.wallet.GiftCardWalletObject.Builder(gReturn, null)));
            }
        }
        
        public final org.xms.g.wallet.GiftCardWalletObject.Builder addTextModuleData(org.xms.g.wallet.wobs.TextModuleData param0) {
            if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
                org.xms.g.utils.XmsLog.d("XMSRouter", "addTextModuleData");
                java.util.ArrayList<com.huawei.hms.wallet.pass.AppendField> textList = new java.util.ArrayList<>();
                com.huawei.hms.wallet.pass.AppendField field = (com.huawei.hms.wallet.pass.AppendField) param0.getHInstance();
                textList.add(field);
                com.huawei.hms.wallet.pass.PassObject.Builder hReturn =
                        ((com.huawei.hms.wallet.pass.PassObject.Builder) this.getHInstance()).addTextList(textList);
                if (hReturn == null) {
                    return null;
                }
                return new org.xms.g.wallet.GiftCardWalletObject.Builder(null, hReturn);
            } else {
                org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.wallet.GiftCardWalletObject.Builder) this.getGInstance()).addTextModuleData(((com.google.android.gms.wallet.wobs.TextModuleData) ((param0) == null ? null : (param0.getGInstance()))))");
                com.google.android.gms.wallet.GiftCardWalletObject.Builder gReturn = ((com.google.android.gms.wallet.GiftCardWalletObject.Builder) this.getGInstance()).addTextModuleData(((com.google.android.gms.wallet.wobs.TextModuleData) ((param0) == null ? null : (param0.getGInstance()))));
                return ((gReturn) == null ? null : (new org.xms.g.wallet.GiftCardWalletObject.Builder(gReturn, null)));
            }
        }
        
        public final org.xms.g.wallet.GiftCardWalletObject.Builder addTextModulesData(java.util.Collection<org.xms.g.wallet.wobs.TextModuleData> param0) {
            if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
                org.xms.g.utils.XmsLog.d("XMSRouter", "addTextModulesData");
                java.util.ArrayList<com.huawei.hms.wallet.pass.AppendField> textList = new java.util.ArrayList<>();
                for (org.xms.g.wallet.wobs.TextModuleData textModuleData : param0) {
                    com.huawei.hms.wallet.pass.AppendField field = (com.huawei.hms.wallet.pass.AppendField) textModuleData.getHInstance();
                    textList.add(field);
                }
                com.huawei.hms.wallet.pass.PassObject.Builder hReturn =
                        ((com.huawei.hms.wallet.pass.PassObject.Builder) this.getHInstance()).addTextList(textList);
                if (hReturn == null) {
                    return null;
                }
                return new org.xms.g.wallet.GiftCardWalletObject.Builder(null, hReturn);
            } else {
                org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.wallet.GiftCardWalletObject.Builder) this.getGInstance()).addTextModulesData(org.xms.g.utils.Utils.mapCollection2GH(param0, false))");
                com.google.android.gms.wallet.GiftCardWalletObject.Builder gReturn = ((com.google.android.gms.wallet.GiftCardWalletObject.Builder) this.getGInstance()).addTextModulesData(org.xms.g.utils.Utils.mapCollection2GH(param0, false));
                return ((gReturn) == null ? null : (new org.xms.g.wallet.GiftCardWalletObject.Builder(gReturn, null)));
            }
        }
        
        public final org.xms.g.wallet.GiftCardWalletObject build() {
            if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
                org.xms.g.utils.XmsLog.d("XMSRouter", "hms LoyaltyWalletObject.Builder.build");
                com.huawei.hms.wallet.pass.PassObject.Builder builder = ((com.huawei.hms.wallet.pass.PassObject.Builder) this.getHInstance());
                builder.setPassTypeIdentifier("hwpass.type.giftcard.hmspublic");
                com.huawei.hms.wallet.pass.PassObject hReturn = builder.build();
                return ((hReturn) == null ? null : (new org.xms.g.wallet.GiftCardWalletObject(null, hReturn)));
            } else {
                org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.wallet.GiftCardWalletObject.Builder) this.getGInstance()).build()");
                com.google.android.gms.wallet.GiftCardWalletObject gReturn = ((com.google.android.gms.wallet.GiftCardWalletObject.Builder) this.getGInstance()).build();
                return ((gReturn) == null ? null : (new org.xms.g.wallet.GiftCardWalletObject(gReturn, null)));
            }
        }
        
        public final org.xms.g.wallet.GiftCardWalletObject.Builder setBalanceCurrencyCode(java.lang.String param0) {
            if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
                org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.wallet.pass.PassObject.Builder) this.getHInstance()).setCurrencyCode(param0)");
                com.huawei.hms.wallet.pass.PassObject.Builder hReturn = ((com.huawei.hms.wallet.pass.PassObject.Builder) this.getHInstance()).setCurrencyCode(param0);
                return ((hReturn) == null ? null : (new org.xms.g.wallet.GiftCardWalletObject.Builder(null, hReturn)));
            } else {
                org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.wallet.GiftCardWalletObject.Builder) this.getGInstance()).setBalanceCurrencyCode(param0)");
                com.google.android.gms.wallet.GiftCardWalletObject.Builder gReturn = ((com.google.android.gms.wallet.GiftCardWalletObject.Builder) this.getGInstance()).setBalanceCurrencyCode(param0);
                return ((gReturn) == null ? null : (new org.xms.g.wallet.GiftCardWalletObject.Builder(gReturn, null)));
            }
        }
        
        public final org.xms.g.wallet.GiftCardWalletObject.Builder setBalanceMicros(long param0) {
            if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
                org.xms.g.utils.XmsLog.d("XMSRouter", "setBalanceMicros");
                java.util.ArrayList<com.huawei.hms.wallet.pass.CommonField> fieldList = new java.util.ArrayList<>();
                com.huawei.hms.wallet.pass.CommonField field = com.huawei.hms.wallet.pass.CommonField.getBuilder().setKey(com.huawei.hms.wallet.constant.WalletPassConstant.PASS_COMMON_FIELD_KEY_BALANCE).setValue(String.valueOf(param0)).build();
                fieldList.add(field);
                com.huawei.hms.wallet.pass.PassObject.Builder hReturn =
                        ((com.huawei.hms.wallet.pass.PassObject.Builder) this.getHInstance()).addCommonFields(fieldList);
                if (hReturn == null) {
                    return null;
                }
                return new org.xms.g.wallet.GiftCardWalletObject.Builder(null, hReturn);
            } else {
                org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.wallet.GiftCardWalletObject.Builder) this.getGInstance()).setBalanceMicros(param0)");
                com.google.android.gms.wallet.GiftCardWalletObject.Builder gReturn = ((com.google.android.gms.wallet.GiftCardWalletObject.Builder) this.getGInstance()).setBalanceMicros(param0);
                return ((gReturn) == null ? null : (new org.xms.g.wallet.GiftCardWalletObject.Builder(gReturn, null)));
            }
        }
        
        public final org.xms.g.wallet.GiftCardWalletObject.Builder setBalanceUpdateTime(long param0) {
            if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
                org.xms.g.utils.XmsLog.d("XMSRouter", "setBalanceUpdateTime");
                java.util.ArrayList<com.huawei.hms.wallet.pass.CommonField> fieldList = new java.util.ArrayList<>();
                com.huawei.hms.wallet.pass.CommonField field = com.huawei.hms.wallet.pass.CommonField.getBuilder().setKey(com.huawei.hms.wallet.constant.WalletPassConstant.PASS_COMMON_FIELD_KEY_BALANCE_REFRESH_TIME).setValue(formatTime(param0)).build();
                fieldList.add(field);
                com.huawei.hms.wallet.pass.PassObject.Builder hReturn =
                        ((com.huawei.hms.wallet.pass.PassObject.Builder) this.getHInstance()).addCommonFields(fieldList);
                if (hReturn == null) {
                    return null;
                }
                return new org.xms.g.wallet.GiftCardWalletObject.Builder(null, hReturn);
            } else {
                org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.wallet.GiftCardWalletObject.Builder) this.getGInstance()).setBalanceUpdateTime(param0)");
                com.google.android.gms.wallet.GiftCardWalletObject.Builder gReturn = ((com.google.android.gms.wallet.GiftCardWalletObject.Builder) this.getGInstance()).setBalanceUpdateTime(param0);
                return ((gReturn) == null ? null : (new org.xms.g.wallet.GiftCardWalletObject.Builder(gReturn, null)));
            }
        }
        
        public final org.xms.g.wallet.GiftCardWalletObject.Builder setBarcodeAlternateText(java.lang.String param0) {
            throw new java.lang.RuntimeException("Not Supported");
        }
        
        public final org.xms.g.wallet.GiftCardWalletObject.Builder setBarcodeLabel(java.lang.String param0) {
            throw new java.lang.RuntimeException("Not Supported");
        }
        
        public final org.xms.g.wallet.GiftCardWalletObject.Builder setBarcodeType(java.lang.String param0) {
            throw new java.lang.RuntimeException("Not Supported");
        }
        
        public final org.xms.g.wallet.GiftCardWalletObject.Builder setBarcodeValue(java.lang.String param0) {
            throw new java.lang.RuntimeException("Not Supported");
        }
        
        public final org.xms.g.wallet.GiftCardWalletObject.Builder setCardIdentifier(java.lang.String param0) {
            throw new java.lang.RuntimeException("Not Supported");
        }
        
        public final org.xms.g.wallet.GiftCardWalletObject.Builder setCardNumber(java.lang.String param0) {
            if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
                org.xms.g.utils.XmsLog.d("XMSRouter", "setCardNumber");
                java.util.ArrayList<com.huawei.hms.wallet.pass.CommonField> fieldList = new java.util.ArrayList<>();
                com.huawei.hms.wallet.pass.CommonField field = com.huawei.hms.wallet.pass.CommonField.getBuilder().setKey(com.huawei.hms.wallet.constant.WalletPassConstant.PASS_COMMON_FIELD_KEY_CARD_NUMBER).setValue(param0).build();
                fieldList.add(field);
                com.huawei.hms.wallet.pass.PassObject.Builder hReturn =
                        ((com.huawei.hms.wallet.pass.PassObject.Builder) this.getHInstance()).addCommonFields(fieldList).setOrganizationPassId(param0);
                if (hReturn == null) {
                    return null;
                }
                return new org.xms.g.wallet.GiftCardWalletObject.Builder(null, hReturn);
            } else {
                org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.wallet.GiftCardWalletObject.Builder) this.getGInstance()).setCardNumber(param0)");
                com.google.android.gms.wallet.GiftCardWalletObject.Builder gReturn = ((com.google.android.gms.wallet.GiftCardWalletObject.Builder) this.getGInstance()).setCardNumber(param0);
                return ((gReturn) == null ? null : (new org.xms.g.wallet.GiftCardWalletObject.Builder(gReturn, null)));
            }
        }
        
        public final org.xms.g.wallet.GiftCardWalletObject.Builder setClassId(java.lang.String param0) {
            if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
                org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.wallet.pass.PassObject.Builder) this.getHInstance()).setPassStyleIdentifier(param0)");
                com.huawei.hms.wallet.pass.PassObject.Builder hReturn = ((com.huawei.hms.wallet.pass.PassObject.Builder) this.getHInstance()).setPassStyleIdentifier(param0);
                return ((hReturn) == null ? null : (new org.xms.g.wallet.GiftCardWalletObject.Builder(null, hReturn)));
            } else {
                org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.wallet.GiftCardWalletObject.Builder) this.getGInstance()).setClassId(param0)");
                com.google.android.gms.wallet.GiftCardWalletObject.Builder gReturn = ((com.google.android.gms.wallet.GiftCardWalletObject.Builder) this.getGInstance()).setClassId(param0);
                return ((gReturn) == null ? null : (new org.xms.g.wallet.GiftCardWalletObject.Builder(gReturn, null)));
            }
        }
        
        public final org.xms.g.wallet.GiftCardWalletObject.Builder setEventNumber(java.lang.String param0) {
            if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
                org.xms.g.utils.XmsLog.d("XMSRouter", "setEventNumber");
                java.util.ArrayList<com.huawei.hms.wallet.pass.AppendField> fieldList = new java.util.ArrayList<>();
                com.huawei.hms.wallet.pass.AppendField field = com.huawei.hms.wallet.pass.AppendField.getBuilder().setKey(com.huawei.hms.wallet.constant.WalletPassConstant.PASS_APPEND_FIELD_KEY_EVENT_NUMBER).setValue(param0).build();
                fieldList.add(field);
                com.huawei.hms.wallet.pass.PassObject.Builder hReturn =
                        ((com.huawei.hms.wallet.pass.PassObject.Builder) this.getHInstance()).addAppendFields(fieldList);
                if (hReturn == null) {
                    return null;
                }
                return new org.xms.g.wallet.GiftCardWalletObject.Builder(null, hReturn);
            } else {
                org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.wallet.GiftCardWalletObject.Builder) this.getGInstance()).setEventNumber(param0)");
                com.google.android.gms.wallet.GiftCardWalletObject.Builder gReturn = ((com.google.android.gms.wallet.GiftCardWalletObject.Builder) this.getGInstance()).setEventNumber(param0);
                return ((gReturn) == null ? null : (new org.xms.g.wallet.GiftCardWalletObject.Builder(gReturn, null)));
            }
        }
        
        public final org.xms.g.wallet.GiftCardWalletObject.Builder setId(java.lang.String param0) {
            if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
                org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.wallet.pass.PassObject.Builder) this.getHInstance()).setSerialNumber(param0)");
                com.huawei.hms.wallet.pass.PassObject.Builder hReturn = ((com.huawei.hms.wallet.pass.PassObject.Builder) this.getHInstance()).setSerialNumber(param0);
                return ((hReturn) == null ? null : (new org.xms.g.wallet.GiftCardWalletObject.Builder(null, hReturn)));
            } else {
                org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.wallet.GiftCardWalletObject.Builder) this.getGInstance()).setId(param0)");
                com.google.android.gms.wallet.GiftCardWalletObject.Builder gReturn = ((com.google.android.gms.wallet.GiftCardWalletObject.Builder) this.getGInstance()).setId(param0);
                return ((gReturn) == null ? null : (new org.xms.g.wallet.GiftCardWalletObject.Builder(gReturn, null)));
            }
        }
        
        public final org.xms.g.wallet.GiftCardWalletObject.Builder setInfoModuleDataHexBackgroundColor(java.lang.String param0) {
            throw new java.lang.RuntimeException("Not Supported");
        }
        
        public final org.xms.g.wallet.GiftCardWalletObject.Builder setInfoModuleDataHexFontColor(java.lang.String param0) {
            throw new java.lang.RuntimeException("Not Supported");
        }
        
        public final org.xms.g.wallet.GiftCardWalletObject.Builder setInfoModuleDataShowLastUpdateTime(boolean param0) {
            if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
                org.xms.g.utils.XmsLog.d("XMSRouter", "hms setInfoModuleDataShowLastUpdateTime");
                return this;
            } else {
                org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.wallet.GiftCardWalletObject.Builder) this.getGInstance()).setInfoModuleDataShowLastUpdateTime(param0)");
                com.google.android.gms.wallet.GiftCardWalletObject.Builder gReturn = ((com.google.android.gms.wallet.GiftCardWalletObject.Builder) this.getGInstance()).setInfoModuleDataShowLastUpdateTime(param0);
                return ((gReturn) == null ? null : (new org.xms.g.wallet.GiftCardWalletObject.Builder(gReturn, null)));
            }
        }
        
        public final org.xms.g.wallet.GiftCardWalletObject.Builder setIssuerName(java.lang.String param0) {
            if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
                org.xms.g.utils.XmsLog.d("XMSRouter", "setIssuerName");
                java.util.ArrayList<com.huawei.hms.wallet.pass.CommonField> fieldList = new java.util.ArrayList<>();
                com.huawei.hms.wallet.pass.CommonField field = com.huawei.hms.wallet.pass.CommonField.getBuilder().setKey(com.huawei.hms.wallet.constant.WalletPassConstant.PASS_COMMON_FIELD_KEY_MERCHANT_NAME).setValue(param0).build();
                fieldList.add(field);
                com.huawei.hms.wallet.pass.PassObject.Builder hReturn =
                        ((com.huawei.hms.wallet.pass.PassObject.Builder) this.getHInstance()).addCommonFields(fieldList);
                if (hReturn == null) {
                    return null;
                }
                return new org.xms.g.wallet.GiftCardWalletObject.Builder(null, hReturn);
            } else {
                org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.wallet.GiftCardWalletObject.Builder) this.getGInstance()).setIssuerName(param0)");
                com.google.android.gms.wallet.GiftCardWalletObject.Builder gReturn = ((com.google.android.gms.wallet.GiftCardWalletObject.Builder) this.getGInstance()).setIssuerName(param0);
                return ((gReturn) == null ? null : (new org.xms.g.wallet.GiftCardWalletObject.Builder(gReturn, null)));
            }
        }
        
        public final org.xms.g.wallet.GiftCardWalletObject.Builder setPin(java.lang.String param0) {
            if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
                org.xms.g.utils.XmsLog.d("XMSRouter", "setPin");
                java.util.ArrayList<com.huawei.hms.wallet.pass.CommonField> fieldList = new java.util.ArrayList<>();
                com.huawei.hms.wallet.pass.CommonField field = com.huawei.hms.wallet.pass.CommonField.getBuilder().setKey(com.huawei.hms.wallet.constant.WalletPassConstant.PASS_COMMON_FIELD_KEY_BLANCE_PIN).setValue(param0).build();
                fieldList.add(field);
                com.huawei.hms.wallet.pass.PassObject.Builder hReturn =
                        ((com.huawei.hms.wallet.pass.PassObject.Builder) this.getHInstance()).addCommonFields(fieldList);
                if (hReturn == null) {
                    return null;
                }
                return new org.xms.g.wallet.GiftCardWalletObject.Builder(null, hReturn);
            } else {
                org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.wallet.GiftCardWalletObject.Builder) this.getGInstance()).setPin(param0)");
                com.google.android.gms.wallet.GiftCardWalletObject.Builder gReturn = ((com.google.android.gms.wallet.GiftCardWalletObject.Builder) this.getGInstance()).setPin(param0);
                return ((gReturn) == null ? null : (new org.xms.g.wallet.GiftCardWalletObject.Builder(gReturn, null)));
            }
        }
        
        public final org.xms.g.wallet.GiftCardWalletObject.Builder setState(int param0) {
            throw new java.lang.RuntimeException("Not Supported");
        }
        
        public final org.xms.g.wallet.GiftCardWalletObject.Builder setTitle(java.lang.String param0) {
            if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
                org.xms.g.utils.XmsLog.d("XMSRouter", "setTitle");
                java.util.ArrayList<com.huawei.hms.wallet.pass.CommonField> fieldList = new java.util.ArrayList<>();
                com.huawei.hms.wallet.pass.CommonField field = com.huawei.hms.wallet.pass.CommonField.getBuilder().setKey(com.huawei.hms.wallet.constant.WalletPassConstant.PASS_COMMON_FIELD_KEY_NAME).setValue(param0).build();
                fieldList.add(field);
                com.huawei.hms.wallet.pass.PassObject.Builder hReturn =
                        ((com.huawei.hms.wallet.pass.PassObject.Builder) this.getHInstance()).addCommonFields(fieldList);
                if (hReturn == null) {
                    return null;
                }
                return new org.xms.g.wallet.GiftCardWalletObject.Builder(null, hReturn);
            } else {
                org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.wallet.GiftCardWalletObject.Builder) this.getGInstance()).setTitle(param0)");
                com.google.android.gms.wallet.GiftCardWalletObject.Builder gReturn = ((com.google.android.gms.wallet.GiftCardWalletObject.Builder) this.getGInstance()).setTitle(param0);
                return ((gReturn) == null ? null : (new org.xms.g.wallet.GiftCardWalletObject.Builder(gReturn, null)));
            }
        }
        
        public final org.xms.g.wallet.GiftCardWalletObject.Builder setValidTimeInterval(org.xms.g.wallet.wobs.TimeInterval param0) {
            throw new java.lang.RuntimeException("Not Supported");
        }
        
        public static org.xms.g.wallet.GiftCardWalletObject.Builder dynamicCast(java.lang.Object param0) {
            return ((org.xms.g.wallet.GiftCardWalletObject.Builder) param0);
        }
        
        public static boolean isInstance(java.lang.Object param0) {
            if (!(param0 instanceof org.xms.g.utils.XGettable)) {
                return false;
            }
            if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
                return ((org.xms.g.utils.XGettable) param0).getHInstance() instanceof com.huawei.hms.wallet.pass.PassObject.Builder;
            } else {
                return ((org.xms.g.utils.XGettable) param0).getGInstance() instanceof com.google.android.gms.wallet.GiftCardWalletObject.Builder;
            }
        }
    }
}