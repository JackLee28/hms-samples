package org.xms.g.wallet;

public final class Wallet extends org.xms.g.utils.XObject {
    
    public Wallet(com.google.android.gms.wallet.Wallet param0, com.huawei.hms.wallet.Wallet param1) {
        super(param0, null);
        this.setHInstance(param1);
    }
    
    public static org.xms.g.common.api.Api getAPI() {
        if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
            org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hms.wallet.Wallet.API");
            com.huawei.hms.api.Api hReturn = null;
            hReturn = com.huawei.hms.wallet.Wallet.API;
            return ((hReturn) == null ? null : (new org.xms.g.common.api.Api(null, hReturn)));
        } else {
            org.xms.g.utils.XmsLog.d("XMSRouter", "com.google.android.gms.wallet.Wallet.API");
            com.google.android.gms.common.api.Api gReturn = null;
            gReturn = com.google.android.gms.wallet.Wallet.API;
            return ((gReturn) == null ? null : (new org.xms.g.common.api.Api(gReturn, null)));
        }
    }
    
    public static org.xms.g.wallet.PaymentsClient getPaymentsClient(android.app.Activity param0, org.xms.g.wallet.Wallet.WalletOptions param1) {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static org.xms.g.wallet.PaymentsClient getPaymentsClient(android.content.Context param0, org.xms.g.wallet.Wallet.WalletOptions param1) {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static org.xms.g.wallet.WalletObjectsClient getWalletObjectsClient(android.app.Activity param0, org.xms.g.wallet.Wallet.WalletOptions param1) {
        if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
            org.xms.g.utils.XmsLog.d("XMSRouter", "getWalletObjectsClient");
            com.huawei.hms.wallet.WalletPassClient hReturn = com.huawei.hms.wallet.Wallet.getWalletPassClient(param0);
            if (hReturn == null) {
                return null;
            }
            return new org.xms.g.wallet.WalletObjectsClient(null, hReturn);
        } else {
            org.xms.g.utils.XmsLog.d("XMSRouter", "com.google.android.gms.wallet.Wallet.getWalletObjectsClient(param0, ((com.google.android.gms.wallet.Wallet.WalletOptions) ((param1) == null ? null : (param1.getGInstance()))))");
            com.google.android.gms.wallet.WalletObjectsClient gReturn = com.google.android.gms.wallet.Wallet.getWalletObjectsClient(param0, ((com.google.android.gms.wallet.Wallet.WalletOptions) ((param1) == null ? null : (param1.getGInstance()))));
            return ((gReturn) == null ? null : (new org.xms.g.wallet.WalletObjectsClient(gReturn, null)));
        }
    }
    
    public static org.xms.g.wallet.Wallet dynamicCast(java.lang.Object param0) {
        return ((org.xms.g.wallet.Wallet) param0);
    }
    
    public static boolean isInstance(java.lang.Object param0) {
        if (!(param0 instanceof org.xms.g.utils.XGettable)) {
            return false;
        }
        if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
            return ((org.xms.g.utils.XGettable) param0).getHInstance() instanceof com.huawei.hms.wallet.Wallet;
        } else {
            return ((org.xms.g.utils.XGettable) param0).getGInstance() instanceof com.google.android.gms.wallet.Wallet;
        }
    }
    
    public static final class WalletOptions extends org.xms.g.utils.XObject implements org.xms.g.common.api.Api.ApiOptions.HasAccountOptions {
        
        public WalletOptions(com.google.android.gms.wallet.Wallet.WalletOptions param0, java.lang.Object param1) {
            super(param0, null);
        }
        
        public int getEnvironment() {
            throw new java.lang.RuntimeException("Not Supported");
        }
        
        public int getTheme() {
            throw new java.lang.RuntimeException("Not Supported");
        }
        
        public final boolean equals(java.lang.Object param0) {
            throw new java.lang.RuntimeException("Not Supported");
        }
        
        public final android.accounts.Account getAccount() {
            throw new java.lang.RuntimeException("Not Supported");
        }
        
        public final int hashCode() {
            throw new java.lang.RuntimeException("Not Supported");
        }
        
        public static org.xms.g.wallet.Wallet.WalletOptions dynamicCast(java.lang.Object param0) {
            throw new java.lang.RuntimeException("Not Supported");
        }
        
        public static boolean isInstance(java.lang.Object param0) {
            throw new java.lang.RuntimeException("Not Supported");
        }
        
        public static final class Builder extends org.xms.g.utils.XObject {
            
            public Builder(com.google.android.gms.wallet.Wallet.WalletOptions.Builder param0, java.lang.Object param1) {
                super(param0, null);
            }
            
            public Builder() {
                super(((com.google.android.gms.wallet.Wallet.WalletOptions.Builder) null), null);
            }
            
            public final org.xms.g.wallet.Wallet.WalletOptions build() {
                throw new java.lang.RuntimeException("Not Supported");
            }
            
            public final org.xms.g.wallet.Wallet.WalletOptions.Builder setEnvironment(int param0) {
                throw new java.lang.RuntimeException("Not Supported");
            }
            
            public final org.xms.g.wallet.Wallet.WalletOptions.Builder setTheme(int param0) {
                throw new java.lang.RuntimeException("Not Supported");
            }
            
            public final org.xms.g.wallet.Wallet.WalletOptions.Builder useGoogleWallet() {
                throw new java.lang.RuntimeException("Not Supported");
            }
            
            public static org.xms.g.wallet.Wallet.WalletOptions.Builder dynamicCast(java.lang.Object param0) {
                throw new java.lang.RuntimeException("Not Supported");
            }
            
            public static boolean isInstance(java.lang.Object param0) {
                throw new java.lang.RuntimeException("Not Supported");
            }
        }
    }
}