package org.xms.g.utils;

public interface XGettable extends XInterface {
    Object getGInstance();

    Object getHInstance();
}
