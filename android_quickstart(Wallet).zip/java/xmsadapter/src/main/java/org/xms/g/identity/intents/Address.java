package org.xms.g.identity.intents;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.util.Map;
import android.app.Activity;
import android.content.Context;
import android.content.IntentSender;
import org.xms.g.common.api.Api;
import com.huawei.hmf.tasks.OnFailureListener;
import com.huawei.hmf.tasks.OnSuccessListener;
import com.huawei.hmf.tasks.Task;
import com.huawei.hms.api.HuaweiApiClient;
import com.huawei.hms.identity.entity.GetUserAddressResult;
import com.huawei.hms.support.api.client.Status;

public final class Address extends org.xms.g.utils.XObject {
    private static Activity getCurrentActivity() {
        try {
            Class activityThreadClass = Class.forName("android.app.ActivityThread");
            Object activityThread = activityThreadClass.getMethod("currentActivityThread").invoke(
                    null);
            Field activitiesField = activityThreadClass.getDeclaredField("mActivities");
            activitiesField.setAccessible(true);
            Map activities = (Map) activitiesField.get(activityThread);
            for (Object activityRecord : activities.values()) {
                Class activityRecordClass = activityRecord.getClass();
                Field pausedField = activityRecordClass.getDeclaredField("paused");
                pausedField.setAccessible(true);
                if (!pausedField.getBoolean(activityRecord)) {
                    Field activityField = activityRecordClass.getDeclaredField("activity");
                    activityField.setAccessible(true);
                    Activity activity = (Activity) activityField.get(activityRecord);
                    return activity;
                }
            }
        } catch (ClassNotFoundException e) {
            org.xms.g.utils.XmsLog.e("Address", "", e);
        } catch (InvocationTargetException e) {
            org.xms.g.utils.XmsLog.e("Address", "", e);
        } catch (NoSuchMethodException e) {
            org.xms.g.utils.XmsLog.e("Address", "", e);
        } catch (NoSuchFieldException e) {
            org.xms.g.utils.XmsLog.e("Address", "", e);
        } catch (IllegalAccessException e) {
            org.xms.g.utils.XmsLog.e("Address", "", e);
        }
        return null;
    }
    public Address(com.google.android.gms.identity.intents.Address param0, java.lang.Object param1) {
        super(param0, null);
        this.setHInstance(param1);
    }
    
    
    public Address() {
        super(((com.google.android.gms.identity.intents.Address) null), null);
        if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
            throw new RuntimeException("hms branch not support");
        } else {
            this.setGInstance(new com.google.android.gms.identity.intents.Address());
        }
    }
    
    public static org.xms.g.common.api.Api getAPI() {
        if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
            org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hms.identity.Address.API");
            return new Api(null, new com.huawei.hms.api.Api(""));
        } else {
            org.xms.g.utils.XmsLog.d("XMSRouter", "com.google.android.gms.identity.intents.Address.API");
            com.google.android.gms.common.api.Api gReturn = null;
            gReturn = com.google.android.gms.identity.intents.Address.API;
            return ((gReturn) == null ? null : (new org.xms.g.common.api.Api(gReturn, null)));
        }
    }
    
    public static void requestUserAddress(org.xms.g.common.api.ExtensionApiClient param0, org.xms.g.identity.intents.UserAddressRequest param1, int param2) {
        if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
            org.xms.g.utils.XmsLog.d("XMSRouter","com.huawei.hms.identity.Address.getAddressClient()");
            final Context context = ((HuaweiApiClient)param0.getHInstance()).getContext();
            Task<GetUserAddressResult> task = com.huawei.hms.identity.Address.getAddressClient(context).getUserAddress((com.huawei.hms.identity.entity.UserAddressRequest)param1.getHInstance());
            task.addOnSuccessListener(new OnSuccessListener<GetUserAddressResult>() {
                @Override
                public void onSuccess(GetUserAddressResult result) {
                    Status status = result.getStatus();
                    if (status.hasResolution()) {
                        try {
                            status.startResolutionForResult(getCurrentActivity(), param2);
                        } catch (IntentSender.SendIntentException e) {
                            org.xms.g.utils.XmsLog.w("Address", "exception:", e);
                        }
                    } else {
                        org.xms.g.utils.XmsLog.w("Address", "The status have not resolution.");
                    }
                }
            }).addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(Exception e) {
                    org.xms.g.utils.XmsLog.i("Address", "Failed to get user address", e);
                }
            });
        } else {
            org.xms.g.utils.XmsLog.d("XMSRouter", "com.google.android.gms.identity.intents.Address.requestUserAddress(((com.google.android.gms.common.api.GoogleApiClient) ((param0) == null ? null : (param0.getGInstance()))), ((com.google.android.gms.identity.intents.UserAddressRequest) ((param1) == null ? null : (param1.getGInstance()))), param2)");
            com.google.android.gms.identity.intents.Address.requestUserAddress(((com.google.android.gms.common.api.GoogleApiClient) ((param0) == null ? null : (param0.getGInstance()))), ((com.google.android.gms.identity.intents.UserAddressRequest) ((param1) == null ? null : (param1.getGInstance()))), param2);
        }
    }
    
    public static org.xms.g.identity.intents.Address dynamicCast(java.lang.Object param0) {
        return ((org.xms.g.identity.intents.Address) param0);
    }
    
    public static boolean isInstance(java.lang.Object param0) {
        if (!(param0 instanceof org.xms.g.utils.XGettable)) {
            return false;
        }
        if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
            throw new RuntimeException("hms branch not support");
        } else {
            return ((org.xms.g.utils.XGettable) param0).getGInstance() instanceof com.google.android.gms.identity.intents.Address;
        }
    }
    
    public static final class AddressOptions extends org.xms.g.utils.XObject implements org.xms.g.common.api.Api.ApiOptions.HasOptions {
        public AddressOptions(com.google.android.gms.identity.intents.Address.AddressOptions param0, java.lang.Object param1) {
            super(param0, null);
            this.setHInstance(param1);
        }
        
        
        public AddressOptions() {
            super(((com.google.android.gms.identity.intents.Address.AddressOptions) null), null);
            if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
                org.xms.g.utils.XmsLog.d("XMSRouter","com.huawei.hms.identity.AddressOptions()");
                this.setHInstance(new com.huawei.hms.api.Api.ApiOptions.Optional() {
                    @Override
                    public int hashCode() {
                        return super.hashCode();
                    }
                    @Override
                    public boolean equals(Object obj) {
                        return super.equals(obj);
                    }
                    @Override
                    protected Object clone() throws CloneNotSupportedException {
                        return super.clone();
                    }
                    @Override
                    public String toString() {
                        return super.toString();
                    }
                    @Override
                    protected void finalize() throws Throwable {
                        super.finalize();
                    }
                });
            } else {
                this.setGInstance(new com.google.android.gms.identity.intents.Address.AddressOptions());
            }
        }
        
        public AddressOptions(int param0) {
            super(((com.google.android.gms.identity.intents.Address.AddressOptions) null), null);
            if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
                org.xms.g.utils.XmsLog.d("XMSRouter","com.huawei.hms.identity.AddressOptions()");
                this.setHInstance(new com.huawei.hms.api.Api.ApiOptions.Optional() {
                    @Override
                    public int hashCode() {
                        return super.hashCode();
                    }
                    @Override
                    public boolean equals(Object obj) {
                        return super.equals(obj);
                    }
                    @Override
                    protected Object clone() throws CloneNotSupportedException {
                        return super.clone();
                    }
                    @Override
                    public String toString() {
                        return super.toString();
                    }
                    @Override
                    protected void finalize() throws Throwable {
                        super.finalize();
                    }
                });
            } else {
                this.setGInstance(new com.google.android.gms.identity.intents.Address.AddressOptions(param0));
            }
        }
        
        public int getTheme() {
            if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
                org.xms.g.utils.XmsLog.d("XMSRouter","com.huawei.hms.identity.getTheme()");
                return 0;
            } else {
                org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.identity.intents.Address.AddressOptions) this.getGInstance()).theme");
                return ((com.google.android.gms.identity.intents.Address.AddressOptions) this.getGInstance()).theme;
            }
        }
        
        public static org.xms.g.identity.intents.Address.AddressOptions dynamicCast(java.lang.Object param0) {
            if (param0 instanceof org.xms.g.identity.intents.Address.AddressOptions) {
                return ((org.xms.g.identity.intents.Address.AddressOptions) param0);
            }
            if (param0 instanceof org.xms.g.utils.XGettable) {
                com.google.android.gms.identity.intents.Address.AddressOptions gReturn = ((com.google.android.gms.identity.intents.Address.AddressOptions) ((org.xms.g.utils.XGettable) param0).getGInstance());
                java.lang.Object hReturn = ((java.lang.Object) ((org.xms.g.utils.XGettable) param0).getHInstance());
                return new org.xms.g.identity.intents.Address.AddressOptions(gReturn, hReturn);
            }
            return ((org.xms.g.identity.intents.Address.AddressOptions) param0);
        }
        
        public static boolean isInstance(java.lang.Object param0) {
            if (!(param0 instanceof org.xms.g.utils.XGettable)) {
                return false;
            }
            if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
                throw new RuntimeException("hms branch not support");
            } else {
                return ((org.xms.g.utils.XGettable) param0).getGInstance() instanceof com.google.android.gms.identity.intents.Address.AddressOptions;
            }
        }
    }
}