package org.xms.g.wallet.wobs;

public final class LabelValueRow extends org.xms.g.utils.XObject implements android.os.Parcelable {
    public static final android.os.Parcelable.Creator CREATOR = new android.os.Parcelable.Creator() {
        
        public org.xms.g.wallet.wobs.LabelValueRow createFromParcel(android.os.Parcel param0) {
            throw new java.lang.RuntimeException("Not Supported");
        }
        
        public org.xms.g.wallet.wobs.LabelValueRow[] newArray(int param0) {
            throw new java.lang.RuntimeException("Not Supported");
        }
    };
    
    public LabelValueRow(com.google.android.gms.wallet.wobs.LabelValueRow param0, java.lang.Object param1) {
        super(param0, null);
    }
    
    public java.util.ArrayList<org.xms.g.wallet.wobs.LabelValue> getColumns() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public final java.lang.String getHexBackgroundColor() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public final java.lang.String getHexFontColor() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static org.xms.g.wallet.wobs.LabelValueRow.Builder newBuilder() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public final void writeToParcel(android.os.Parcel param0, int param1) {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public int describeContents() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static org.xms.g.wallet.wobs.LabelValueRow dynamicCast(java.lang.Object param0) {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static boolean isInstance(java.lang.Object param0) {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static final class Builder extends org.xms.g.utils.XObject {
        
        public Builder(com.google.android.gms.wallet.wobs.LabelValueRow.Builder param0, java.lang.Object param1) {
            super(param0, null);
        }
        
        public final org.xms.g.wallet.wobs.LabelValueRow.Builder addColumn(org.xms.g.wallet.wobs.LabelValue param0) {
            throw new java.lang.RuntimeException("Not Supported");
        }
        
        public final org.xms.g.wallet.wobs.LabelValueRow.Builder addColumns(java.util.Collection<org.xms.g.wallet.wobs.LabelValue> param0) {
            throw new java.lang.RuntimeException("Not Supported");
        }
        
        public final org.xms.g.wallet.wobs.LabelValueRow build() {
            throw new java.lang.RuntimeException("Not Supported");
        }
        
        public final org.xms.g.wallet.wobs.LabelValueRow.Builder setHexBackgroundColor(java.lang.String param0) {
            throw new java.lang.RuntimeException("Not Supported");
        }
        
        public final org.xms.g.wallet.wobs.LabelValueRow.Builder setHexFontColor(java.lang.String param0) {
            throw new java.lang.RuntimeException("Not Supported");
        }
        
        public static org.xms.g.wallet.wobs.LabelValueRow.Builder dynamicCast(java.lang.Object param0) {
            throw new java.lang.RuntimeException("Not Supported");
        }
        
        public static boolean isInstance(java.lang.Object param0) {
            throw new java.lang.RuntimeException("Not Supported");
        }
    }
}