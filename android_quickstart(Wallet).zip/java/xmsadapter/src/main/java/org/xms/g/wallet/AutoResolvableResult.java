package org.xms.g.wallet;

public interface AutoResolvableResult extends org.xms.g.utils.XInterface {
    
    public void putIntoIntent(android.content.Intent param0);
    
    default com.google.android.gms.wallet.AutoResolvableResult getGInstanceAutoResolvableResult() {
        if (this instanceof org.xms.g.utils.XGettable) {
            return ((com.google.android.gms.wallet.AutoResolvableResult) ((org.xms.g.utils.XGettable) this).getGInstance());
        }
        return new com.google.android.gms.wallet.AutoResolvableResult() {
            
            public void putIntoIntent(android.content.Intent param0) {
                org.xms.g.wallet.AutoResolvableResult.this.putIntoIntent(param0);
            }
        };
    }
    
    default com.huawei.hms.wallet.IResolvableTaskResult getHInstanceAutoResolvableResult() {
        if (this instanceof org.xms.g.utils.XGettable) {
            return ((com.huawei.hms.wallet.IResolvableTaskResult) ((org.xms.g.utils.XGettable) this).getHInstance());
        }
        return new com.huawei.hms.wallet.IResolvableTaskResult() {
            
            public void addIntent(android.content.Intent param0) {
                org.xms.g.wallet.AutoResolvableResult.this.putIntoIntent(param0);
            }
        };
    }
    
    public static org.xms.g.wallet.AutoResolvableResult dynamicCast(java.lang.Object param0) {
        if (param0 instanceof org.xms.g.wallet.AutoResolvableResult) {
            return ((org.xms.g.wallet.AutoResolvableResult) param0);
        }
        if (param0 instanceof org.xms.g.utils.XGettable) {
            com.google.android.gms.wallet.AutoResolvableResult gReturn = ((com.google.android.gms.wallet.AutoResolvableResult) ((org.xms.g.utils.XGettable) param0).getGInstance());
            com.huawei.hms.wallet.IResolvableTaskResult hReturn = ((com.huawei.hms.wallet.IResolvableTaskResult) ((org.xms.g.utils.XGettable) param0).getHInstance());
            return new org.xms.g.wallet.AutoResolvableResult.XImpl(gReturn, hReturn);
        }
        return ((org.xms.g.wallet.AutoResolvableResult) param0);
    }
    
    public static boolean isInstance(java.lang.Object param0) {
        if (!(param0 instanceof org.xms.g.utils.XInterface)) {
            return false;
        }
        if (param0 instanceof org.xms.g.utils.XGettable) {
            if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
                return ((org.xms.g.utils.XGettable) param0).getHInstance() instanceof com.huawei.hms.wallet.IResolvableTaskResult;
            } else {
                return ((org.xms.g.utils.XGettable) param0).getGInstance() instanceof com.google.android.gms.wallet.AutoResolvableResult;
            }
        }
        return param0 instanceof org.xms.g.wallet.AutoResolvableResult;
    }
    
    public static class XImpl extends org.xms.g.utils.XObject implements org.xms.g.wallet.AutoResolvableResult {
        
        public XImpl(com.google.android.gms.wallet.AutoResolvableResult param0, com.huawei.hms.wallet.IResolvableTaskResult param1) {
            super(param0, param1);
        }
        
        public void putIntoIntent(android.content.Intent param0) {
            if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
                org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.wallet.IResolvableTaskResult) this.getHInstance()).addIntent(param0)");
                ((com.huawei.hms.wallet.IResolvableTaskResult) this.getHInstance()).addIntent(param0);
            } else {
                org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.wallet.AutoResolvableResult) this.getGInstance()).putIntoIntent(param0)");
                ((com.google.android.gms.wallet.AutoResolvableResult) this.getGInstance()).putIntoIntent(param0);
            }
        }
    }
}