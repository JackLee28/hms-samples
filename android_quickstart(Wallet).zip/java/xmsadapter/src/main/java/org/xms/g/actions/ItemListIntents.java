package org.xms.g.actions;

public class ItemListIntents extends org.xms.g.utils.XObject {
    private boolean wrapper = true;
    
    public ItemListIntents(com.google.android.gms.actions.ItemListIntents param0, java.lang.Object param1) {
        super(param0, null);
    }
    
    public static java.lang.String getACTION_ACCEPT_ITEM() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static java.lang.String getACTION_APPEND_ITEM_LIST() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static java.lang.String getACTION_CREATE_ITEM_LIST() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static java.lang.String getACTION_DELETE_ITEM() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static java.lang.String getACTION_DELETE_ITEM_LIST() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static java.lang.String getACTION_REJECT_ITEM() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static java.lang.String getEXTRA_ITEM_NAME() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static java.lang.String getEXTRA_ITEM_NAMES() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static java.lang.String getEXTRA_ITEM_QUERY() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static java.lang.String getEXTRA_LIST_NAME() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static java.lang.String getEXTRA_LIST_QUERY() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static org.xms.g.actions.ItemListIntents dynamicCast(java.lang.Object param0) {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static boolean isInstance(java.lang.Object param0) {
        throw new java.lang.RuntimeException("Not Supported");
    }
}