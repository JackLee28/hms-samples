package org.xms.g.wallet.wobs;

public interface WalletObjectsConstants extends org.xms.g.utils.XInterface {
    
    default com.google.android.gms.wallet.wobs.WalletObjectsConstants getGInstanceWalletObjectsConstants() {
        if (this instanceof org.xms.g.utils.XGettable) {
            return ((com.google.android.gms.wallet.wobs.WalletObjectsConstants) ((org.xms.g.utils.XGettable) this).getGInstance());
        }
        return new com.google.android.gms.wallet.wobs.WalletObjectsConstants() {
        };
    }
    default java.lang.Object getHInstanceWalletObjectsConstants() {
        if (this instanceof org.xms.g.utils.XGettable) {
            return ((java.lang.Object) ((org.xms.g.utils.XGettable) this).getHInstance());
        }
        return new java.lang.Object();
    }
    
    
    public static org.xms.g.wallet.wobs.WalletObjectsConstants dynamicCast(java.lang.Object param0) {
        if (param0 instanceof org.xms.g.wallet.wobs.WalletObjectsConstants) {
            return ((org.xms.g.wallet.wobs.WalletObjectsConstants) param0);
        }
        if (param0 instanceof org.xms.g.utils.XGettable) {
            com.google.android.gms.wallet.wobs.WalletObjectsConstants gReturn = ((com.google.android.gms.wallet.wobs.WalletObjectsConstants) ((org.xms.g.utils.XGettable) param0).getGInstance());
            throw new RuntimeException("Hms branch not support");
        }
        return ((org.xms.g.wallet.wobs.WalletObjectsConstants) param0);
    }
    
    public static boolean isInstance(java.lang.Object param0) {
        if (!(param0 instanceof org.xms.g.utils.XInterface)) {
            return false;
        }
        if (param0 instanceof org.xms.g.utils.XGettable) {
            if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
                throw new RuntimeException("Hms branch not support");
            } else {
                return ((org.xms.g.utils.XGettable) param0).getGInstance() instanceof com.google.android.gms.wallet.wobs.WalletObjectsConstants;
            }
        }
        return param0 instanceof org.xms.g.wallet.wobs.WalletObjectsConstants;
    }
    
    public static class XImpl extends org.xms.g.utils.XObject implements org.xms.g.wallet.wobs.WalletObjectsConstants {
        
        public XImpl(com.google.android.gms.wallet.wobs.WalletObjectsConstants param0, java.lang.Object param1) {
            super(param0, param1);
        }
    }
    
    public static interface State extends org.xms.g.utils.XInterface {
        
        public static int getACTIVE() {
            throw new java.lang.RuntimeException("Not Supported");
        }
        
        public static int getCOMPLETED() {
            throw new java.lang.RuntimeException("Not Supported");
        }
        
        public static int getEXPIRED() {
            throw new java.lang.RuntimeException("Not Supported");
        }
        
        public static int getINACTIVE() {
            throw new java.lang.RuntimeException("Not Supported");
        }
        
        default com.google.android.gms.wallet.wobs.WalletObjectsConstants.State getGInstanceState() {
            throw new java.lang.RuntimeException("Not Supported");
        }
        
        default java.lang.Object getHInstanceState() {
            throw new java.lang.RuntimeException("Not Supported");
        }
        
        public static org.xms.g.wallet.wobs.WalletObjectsConstants.State dynamicCast(java.lang.Object param0) {
            throw new java.lang.RuntimeException("Not Supported");
        }
        
        public static boolean isInstance(java.lang.Object param0) {
            throw new java.lang.RuntimeException("Not Supported");
        }
        
        public static class XImpl extends org.xms.g.utils.XObject implements org.xms.g.wallet.wobs.WalletObjectsConstants.State {
            
            public XImpl(com.google.android.gms.wallet.wobs.WalletObjectsConstants.State param0, java.lang.Object param1) {
                super(param0, param1);
            }
        }
    }
}