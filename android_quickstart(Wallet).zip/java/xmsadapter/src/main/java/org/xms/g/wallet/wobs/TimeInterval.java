package org.xms.g.wallet.wobs;

public final class TimeInterval extends org.xms.g.utils.XObject implements android.os.Parcelable {
    public static final android.os.Parcelable.Creator CREATOR = new android.os.Parcelable.Creator() {
        
        public org.xms.g.wallet.wobs.TimeInterval createFromParcel(android.os.Parcel param0) {
            throw new java.lang.RuntimeException("Not Supported");
        }
        
        public org.xms.g.wallet.wobs.TimeInterval[] newArray(int param0) {
            throw new java.lang.RuntimeException("Not Supported");
        }
    };
    
    public TimeInterval(com.google.android.gms.wallet.wobs.TimeInterval param0, java.lang.Object param1) {
        super(param0, null);
    }
    
    public TimeInterval(long param0, long param1) {
        super(((com.google.android.gms.wallet.wobs.TimeInterval) null), null);
    }
    
    public final long getEndTimestamp() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public final long getStartTimestamp() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public final void writeToParcel(android.os.Parcel param0, int param1) {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public int describeContents() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static org.xms.g.wallet.wobs.TimeInterval dynamicCast(java.lang.Object param0) {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static boolean isInstance(java.lang.Object param0) {
        throw new java.lang.RuntimeException("Not Supported");
    }
}