package org.xms.g.utils;

public interface Function<T, R> {
    R apply(T t);
}
