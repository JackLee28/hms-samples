package org.xms.g.auth.api.accounttransfer;

public class DeviceMetaData extends org.xms.g.utils.XObject implements android.os.Parcelable {
    private boolean wrapper = true;
    public static final android.os.Parcelable.Creator CREATOR = new android.os.Parcelable.Creator() {
        
        public org.xms.g.auth.api.accounttransfer.DeviceMetaData createFromParcel(android.os.Parcel param0) {
            throw new java.lang.RuntimeException("Not Supported");
        }
        
        public org.xms.g.auth.api.accounttransfer.DeviceMetaData[] newArray(int param0) {
            throw new java.lang.RuntimeException("Not Supported");
        }
    };
    
    public DeviceMetaData(com.google.android.gms.auth.api.accounttransfer.DeviceMetaData param0, java.lang.Object param1) {
        super(param0, null);
    }
    
    public long getMinAgeOfLockScreen() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public boolean isChallengeAllowed() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public boolean isLockScreenSolved() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public int describeContents() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public void writeToParcel(android.os.Parcel param0, int param1) {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static org.xms.g.auth.api.accounttransfer.DeviceMetaData dynamicCast(java.lang.Object param0) {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static boolean isInstance(java.lang.Object param0) {
        throw new java.lang.RuntimeException("Not Supported");
    }
}