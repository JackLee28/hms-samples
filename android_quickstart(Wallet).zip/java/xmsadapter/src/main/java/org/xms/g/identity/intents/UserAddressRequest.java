package org.xms.g.identity.intents;

public final class UserAddressRequest extends org.xms.g.utils.XObject implements android.os.Parcelable {
    public static final android.os.Parcelable.Creator CREATOR = new android.os.Parcelable.Creator() {
        
        public org.xms.g.identity.intents.UserAddressRequest createFromParcel(android.os.Parcel param0) {
            throw new java.lang.RuntimeException("Not Supported");
        }
        
        public org.xms.g.identity.intents.UserAddressRequest[] newArray(int param0) {
            throw new java.lang.RuntimeException("Not Supported");
        }
    };
    public UserAddressRequest(com.google.android.gms.identity.intents.UserAddressRequest param0, java.lang.Object param1) {
        super(param0, null);
        this.setHInstance(param1);
    }
    
    
    public static org.xms.g.identity.intents.UserAddressRequest.Builder newBuilder() {
        if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
            org.xms.g.utils.XmsLog.d("XMSRouter", "org.xms.g.identity.intents.UserAddressRequest.newBuilder()");
            return new org.xms.g.identity.intents.UserAddressRequest.Builder(null, null);
        } else {
            org.xms.g.utils.XmsLog.d("XMSRouter", "com.google.android.gms.identity.intents.UserAddressRequest.newBuilder()");
            com.google.android.gms.identity.intents.UserAddressRequest.Builder gReturn = com.google.android.gms.identity.intents.UserAddressRequest.newBuilder();
            return ((gReturn) == null ? null : (new org.xms.g.identity.intents.UserAddressRequest.Builder(gReturn, null)));
        }
    }
    
    public void writeToParcel(android.os.Parcel param0, int param1) {
        if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
            throw new RuntimeException("HMS does not support this writeToParcel(android.os.Parcel,int) method");
        } else {
            org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.identity.intents.UserAddressRequest) this.getGInstance()).writeToParcel(param0, param1)");
            ((com.google.android.gms.identity.intents.UserAddressRequest) this.getGInstance()).writeToParcel(param0, param1);
        }
    }
    
    public int describeContents() {
        if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
            org.xms.g.utils.XmsLog.d("XMSRouter", "org.xms.g.identity.intents.UserAddressRequest.describeContents");
            return 0;
        } else {
            org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.identity.intents.UserAddressRequest) this.getGInstance()).describeContents()");
            return ((com.google.android.gms.identity.intents.UserAddressRequest) this.getGInstance()).describeContents();
        }
    }
    
    public static org.xms.g.identity.intents.UserAddressRequest dynamicCast(java.lang.Object param0) {
        return ((org.xms.g.identity.intents.UserAddressRequest) param0);
    }
    
    public static boolean isInstance(java.lang.Object param0) {
        if (!(param0 instanceof org.xms.g.utils.XGettable)) {
            return false;
        }
        if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
            throw new RuntimeException("hms branch not support");
        } else {
            return ((org.xms.g.utils.XGettable) param0).getGInstance() instanceof com.google.android.gms.identity.intents.UserAddressRequest;
        }
    }
    
    public static final class Builder extends org.xms.g.utils.XObject {
        public Builder(com.google.android.gms.identity.intents.UserAddressRequest.Builder param0, java.lang.Object param1) {
            super(param0, null);
            this.setHInstance(param1);
        }
        
        
        public final org.xms.g.identity.intents.UserAddressRequest.Builder addAllowedCountrySpecification(org.xms.g.identity.intents.model.CountrySpecification param0) {
            if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
                org.xms.g.utils.XmsLog.d("XMSRouter", "org.xms.g.identity.intents.UserAddressRequest.Builder(null, null)");
                return new org.xms.g.identity.intents.UserAddressRequest.Builder(null, null);
            } else {
                org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.identity.intents.UserAddressRequest.Builder) this.getGInstance()).addAllowedCountrySpecification(((com.google.android.gms.identity.intents.model.CountrySpecification) ((param0) == null ? null : (param0.getGInstance()))))");
                com.google.android.gms.identity.intents.UserAddressRequest.Builder gReturn = ((com.google.android.gms.identity.intents.UserAddressRequest.Builder) this.getGInstance()).addAllowedCountrySpecification(((com.google.android.gms.identity.intents.model.CountrySpecification) ((param0) == null ? null : (param0.getGInstance()))));
                return ((gReturn) == null ? null : (new org.xms.g.identity.intents.UserAddressRequest.Builder(gReturn, null)));
            }
        }
        
        public org.xms.g.identity.intents.UserAddressRequest.Builder addAllowedCountrySpecifications(java.util.Collection<org.xms.g.identity.intents.model.CountrySpecification> param0) {
            if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
                org.xms.g.utils.XmsLog.d("XMSRouter", "org.xms.g.identity.intents.UserAddressRequest.Builder(null, null)");
                return new org.xms.g.identity.intents.UserAddressRequest.Builder(null, null);
            } else {
                org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.identity.intents.UserAddressRequest.Builder) this.getGInstance()).addAllowedCountrySpecifications(org.xms.g.utils.Utils.mapCollection2GH(param0, false))");
                com.google.android.gms.identity.intents.UserAddressRequest.Builder gReturn = ((com.google.android.gms.identity.intents.UserAddressRequest.Builder) this.getGInstance()).addAllowedCountrySpecifications(org.xms.g.utils.Utils.mapCollection2GH(param0, false));
                return ((gReturn) == null ? null : (new org.xms.g.identity.intents.UserAddressRequest.Builder(gReturn, null)));
            }
        }
        
        public final org.xms.g.identity.intents.UserAddressRequest build() {
            if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
                org.xms.g.utils.XmsLog.d("XMSRouter", "org.xms.g.identity.intents.UserAddressRequest(null, new com.huawei.hms.identity.entity.UserAddressRequest())");
                return new org.xms.g.identity.intents.UserAddressRequest(null, new com.huawei.hms.identity.entity.UserAddressRequest());
            } else {
                org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.identity.intents.UserAddressRequest.Builder) this.getGInstance()).build()");
                com.google.android.gms.identity.intents.UserAddressRequest gReturn = ((com.google.android.gms.identity.intents.UserAddressRequest.Builder) this.getGInstance()).build();
                return ((gReturn) == null ? null : (new org.xms.g.identity.intents.UserAddressRequest(gReturn, null)));
            }
        }
        
        public static org.xms.g.identity.intents.UserAddressRequest.Builder dynamicCast(java.lang.Object param0) {
            return ((org.xms.g.identity.intents.UserAddressRequest.Builder) param0);
        }
        
        public static boolean isInstance(java.lang.Object param0) {
            if (!(param0 instanceof org.xms.g.utils.XGettable)) {
                return false;
            }
            if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
                throw new RuntimeException("hms branch not support");
            } else {
                return ((org.xms.g.utils.XGettable) param0).getGInstance() instanceof com.google.android.gms.identity.intents.UserAddressRequest.Builder;
            }
        }
    }
}