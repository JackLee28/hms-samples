package org.xms.g.wallet.wobs;

public final class LoyaltyPoints extends org.xms.g.utils.XObject implements android.os.Parcelable {
    public static final android.os.Parcelable.Creator CREATOR = new android.os.Parcelable.Creator() {
        
        public org.xms.g.wallet.wobs.LoyaltyPoints createFromParcel(android.os.Parcel param0) {
            throw new java.lang.RuntimeException("Not Supported");
        }
        
        public org.xms.g.wallet.wobs.LoyaltyPoints[] newArray(int param0) {
            throw new java.lang.RuntimeException("Not Supported");
        }
    };
    
    public LoyaltyPoints(com.google.android.gms.wallet.wobs.LoyaltyPoints param0, java.lang.Object param1) {
        super(param0, null);
    }
    
    public final org.xms.g.wallet.wobs.LoyaltyPointsBalance getBalance() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public final java.lang.String getLabel() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public final java.lang.String getType() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public final org.xms.g.wallet.wobs.TimeInterval getValidTimeInterval() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static org.xms.g.wallet.wobs.LoyaltyPoints.Builder newBuilder() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public final void writeToParcel(android.os.Parcel param0, int param1) {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public int describeContents() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static org.xms.g.wallet.wobs.LoyaltyPoints dynamicCast(java.lang.Object param0) {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static boolean isInstance(java.lang.Object param0) {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static final class Builder extends org.xms.g.utils.XObject {
        
        public Builder(com.google.android.gms.wallet.wobs.LoyaltyPoints.Builder param0, java.lang.Object param1) {
            super(param0, null);
        }
        
        public final org.xms.g.wallet.wobs.LoyaltyPoints build() {
            throw new java.lang.RuntimeException("Not Supported");
        }
        
        public final org.xms.g.wallet.wobs.LoyaltyPoints.Builder setBalance(org.xms.g.wallet.wobs.LoyaltyPointsBalance param0) {
            throw new java.lang.RuntimeException("Not Supported");
        }
        
        public final org.xms.g.wallet.wobs.LoyaltyPoints.Builder setLabel(java.lang.String param0) {
            throw new java.lang.RuntimeException("Not Supported");
        }
        
        public final org.xms.g.wallet.wobs.LoyaltyPoints.Builder setType(java.lang.String param0) {
            throw new java.lang.RuntimeException("Not Supported");
        }
        
        public final org.xms.g.wallet.wobs.LoyaltyPoints.Builder setValidTimeInterval(org.xms.g.wallet.wobs.TimeInterval param0) {
            throw new java.lang.RuntimeException("Not Supported");
        }
        
        public static org.xms.g.wallet.wobs.LoyaltyPoints.Builder dynamicCast(java.lang.Object param0) {
            throw new java.lang.RuntimeException("Not Supported");
        }
        
        public static boolean isInstance(java.lang.Object param0) {
            throw new java.lang.RuntimeException("Not Supported");
        }
    }
}