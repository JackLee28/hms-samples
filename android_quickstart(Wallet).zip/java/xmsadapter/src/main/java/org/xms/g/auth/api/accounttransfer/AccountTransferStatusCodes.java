package org.xms.g.auth.api.accounttransfer;

public final class AccountTransferStatusCodes extends org.xms.g.common.api.CommonStatusCodes {
    
    public AccountTransferStatusCodes(com.google.android.gms.auth.api.accounttransfer.AccountTransferStatusCodes param0, java.lang.Object param1) {
        super(param0, null);
    }
    
    public static int getCHALLENGE_NOT_ALLOWED() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static int getINVALID_REQUEST() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static int getNOT_ALLOWED_SECURITY() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static int getNO_DATA_AVAILABLE() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static int getSESSION_INACTIVE() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static java.lang.String getStatusCodeString(int param0) {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static org.xms.g.auth.api.accounttransfer.AccountTransferStatusCodes dynamicCast(java.lang.Object param0) {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static boolean isInstance(java.lang.Object param0) {
        throw new java.lang.RuntimeException("Not Supported");
    }
}