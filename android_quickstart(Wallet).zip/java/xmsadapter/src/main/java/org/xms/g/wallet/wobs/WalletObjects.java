package org.xms.g.wallet.wobs;

public interface WalletObjects extends org.xms.g.utils.XInterface {
    
    public void createWalletObjects(org.xms.g.common.api.ExtensionApiClient param0, org.xms.g.wallet.CreateWalletObjectsRequest param1, int param2);
    
    default com.google.android.gms.wallet.wobs.WalletObjects getGInstanceWalletObjects() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    default java.lang.Object getHInstanceWalletObjects() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static org.xms.g.wallet.wobs.WalletObjects dynamicCast(java.lang.Object param0) {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static boolean isInstance(java.lang.Object param0) {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static class XImpl extends org.xms.g.utils.XObject implements org.xms.g.wallet.wobs.WalletObjects {
        
        public XImpl(com.google.android.gms.wallet.wobs.WalletObjects param0, java.lang.Object param1) {
            super(param0, param1);
        }
        
        public void createWalletObjects(org.xms.g.common.api.ExtensionApiClient param0, org.xms.g.wallet.CreateWalletObjectsRequest param1, int param2) {
            throw new java.lang.RuntimeException("Not Supported");
        }
    }
}