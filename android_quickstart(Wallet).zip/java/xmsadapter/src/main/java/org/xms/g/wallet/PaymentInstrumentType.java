package org.xms.g.wallet;

public final class PaymentInstrumentType extends org.xms.g.utils.XObject {
    
    public PaymentInstrumentType(com.google.android.gms.wallet.PaymentInstrumentType param0, java.lang.Object param1) {
        super(param0, null);
    }
    
    public PaymentInstrumentType() {
        super(((com.google.android.gms.wallet.PaymentInstrumentType) null), null);
    }
    
    public static int getAMEX() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static int getDISCOVER() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static int getJCB() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static int getMASTER_CARD() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static int getVISA() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static java.util.ArrayList<java.lang.Integer> getAll() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static org.xms.g.wallet.PaymentInstrumentType dynamicCast(java.lang.Object param0) {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static boolean isInstance(java.lang.Object param0) {
        throw new java.lang.RuntimeException("Not Supported");
    }
}