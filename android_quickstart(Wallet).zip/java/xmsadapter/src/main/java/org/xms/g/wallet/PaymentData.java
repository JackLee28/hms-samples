package org.xms.g.wallet;

public final class PaymentData extends org.xms.g.utils.XObject implements android.os.Parcelable, org.xms.g.wallet.AutoResolvableResult {
    public static final android.os.Parcelable.Creator CREATOR = new android.os.Parcelable.Creator() {
        
        public org.xms.g.wallet.PaymentData createFromParcel(android.os.Parcel param0) {
            throw new java.lang.RuntimeException("Not Supported");
        }
        
        public org.xms.g.wallet.PaymentData[] newArray(int param0) {
            throw new java.lang.RuntimeException("Not Supported");
        }
    };
    
    public PaymentData(com.google.android.gms.wallet.PaymentData param0, java.lang.Object param1) {
        super(param0, null);
    }
    
    public static org.xms.g.wallet.PaymentData fromJson(java.lang.String param0) {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public final org.xms.g.wallet.CardInfo getCardInfo() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public final java.lang.String getEmail() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public final android.os.Bundle getExtraData() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static org.xms.g.wallet.PaymentData getFromIntent(android.content.Intent param0) {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public final java.lang.String getGoogleTransactionId() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public final org.xms.g.wallet.PaymentMethodToken getPaymentMethodToken() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public final org.xms.g.identity.intents.model.UserAddress getShippingAddress() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public final void putIntoIntent(android.content.Intent param0) {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public final java.lang.String toJson() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public final void writeToParcel(android.os.Parcel param0, int param1) {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public int describeContents() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static org.xms.g.wallet.PaymentData dynamicCast(java.lang.Object param0) {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static boolean isInstance(java.lang.Object param0) {
        throw new java.lang.RuntimeException("Not Supported");
    }
}