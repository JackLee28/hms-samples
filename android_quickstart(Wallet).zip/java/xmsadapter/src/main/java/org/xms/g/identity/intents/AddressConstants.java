package org.xms.g.identity.intents;

public interface AddressConstants extends org.xms.g.utils.XInterface {
    
    default com.google.android.gms.identity.intents.AddressConstants getGInstanceAddressConstants() {
        if (this instanceof org.xms.g.utils.XGettable) {
            return ((com.google.android.gms.identity.intents.AddressConstants) ((org.xms.g.utils.XGettable) this).getGInstance());
        }
        return new com.google.android.gms.identity.intents.AddressConstants() {
        };
    }
    
    default com.huawei.hms.identity.AddressConstants getHInstanceAddressConstants() {
        if (this instanceof org.xms.g.utils.XGettable) {
            return ((com.huawei.hms.identity.AddressConstants) ((org.xms.g.utils.XGettable) this).getHInstance());
        }
        return new com.huawei.hms.identity.AddressConstants() {
        };
    }
    
    public static org.xms.g.identity.intents.AddressConstants dynamicCast(java.lang.Object param0) {
        if (param0 instanceof org.xms.g.identity.intents.AddressConstants) {
            return ((org.xms.g.identity.intents.AddressConstants) param0);
        }
        if (param0 instanceof org.xms.g.utils.XGettable) {
            com.google.android.gms.identity.intents.AddressConstants gReturn = ((com.google.android.gms.identity.intents.AddressConstants) ((org.xms.g.utils.XGettable) param0).getGInstance());
            com.huawei.hms.identity.AddressConstants hReturn = ((com.huawei.hms.identity.AddressConstants) ((org.xms.g.utils.XGettable) param0).getHInstance());
            return new org.xms.g.identity.intents.AddressConstants.XImpl(gReturn, hReturn);
        }
        return ((org.xms.g.identity.intents.AddressConstants) param0);
    }
    
    public static boolean isInstance(java.lang.Object param0) {
        if (!(param0 instanceof org.xms.g.utils.XInterface)) {
            return false;
        }
        if (param0 instanceof org.xms.g.utils.XGettable) {
            if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
                return ((org.xms.g.utils.XGettable) param0).getHInstance() instanceof com.huawei.hms.identity.AddressConstants;
            } else {
                return ((org.xms.g.utils.XGettable) param0).getGInstance() instanceof com.google.android.gms.identity.intents.AddressConstants;
            }
        }
        return param0 instanceof org.xms.g.identity.intents.AddressConstants;
    }
    
    public static class XImpl extends org.xms.g.utils.XObject implements org.xms.g.identity.intents.AddressConstants {
        
        public XImpl(com.google.android.gms.identity.intents.AddressConstants param0, com.huawei.hms.identity.AddressConstants param1) {
            super(param0, param1);
        }
    }
    
    public static interface ErrorCodes extends org.xms.g.utils.XInterface {
        int hms_ERROR_CODE_NO_APPLICABLE_ADDRESSES = 555;
        
        public static int getERROR_CODE_NO_APPLICABLE_ADDRESSES() {
            if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
                org.xms.g.utils.XmsLog.d("XMSRouter","com.huawei.hms.identity.ERROR_CODE_NO_APPLICABLE_ADDRESSES");
                return hms_ERROR_CODE_NO_APPLICABLE_ADDRESSES;
            } else {
                org.xms.g.utils.XmsLog.d("XMSRouter", "com.google.android.gms.identity.intents.AddressConstants.ErrorCodes.ERROR_CODE_NO_APPLICABLE_ADDRESSES");
                return com.google.android.gms.identity.intents.AddressConstants.ErrorCodes.ERROR_CODE_NO_APPLICABLE_ADDRESSES;
            }
        }
        
        default com.google.android.gms.identity.intents.AddressConstants.ErrorCodes getGInstanceErrorCodes() {
            if (this instanceof org.xms.g.utils.XGettable) {
                return ((com.google.android.gms.identity.intents.AddressConstants.ErrorCodes) ((org.xms.g.utils.XGettable) this).getGInstance());
            }
            return new com.google.android.gms.identity.intents.AddressConstants.ErrorCodes() {
            };
        }
        default java.lang.Object getHInstanceErrorCodes() {
            if (this instanceof org.xms.g.utils.XGettable) {
                return ((java.lang.Object) ((org.xms.g.utils.XGettable) this).getHInstance());
            }
            return new java.lang.Object();
        }
        
        
        public static org.xms.g.identity.intents.AddressConstants.ErrorCodes dynamicCast(java.lang.Object param0) {
            if (param0 instanceof org.xms.g.identity.intents.AddressConstants.ErrorCodes) {
                return ((org.xms.g.identity.intents.AddressConstants.ErrorCodes) param0);
            }
            if (param0 instanceof org.xms.g.utils.XGettable) {
                com.google.android.gms.identity.intents.AddressConstants.ErrorCodes gReturn = ((com.google.android.gms.identity.intents.AddressConstants.ErrorCodes) ((org.xms.g.utils.XGettable) param0).getGInstance());
                throw new RuntimeException("hms branch not support");
            }
            return ((org.xms.g.identity.intents.AddressConstants.ErrorCodes) param0);
        }
        
        public static boolean isInstance(java.lang.Object param0) {
            if (!(param0 instanceof org.xms.g.utils.XInterface)) {
                return false;
            }
            if (param0 instanceof org.xms.g.utils.XGettable) {
                if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
                    throw new RuntimeException("hms branch not support");
                } else {
                    return ((org.xms.g.utils.XGettable) param0).getGInstance() instanceof com.google.android.gms.identity.intents.AddressConstants.ErrorCodes;
                }
            }
            return param0 instanceof org.xms.g.identity.intents.AddressConstants.ErrorCodes;
        }
        
        public static class XImpl extends org.xms.g.utils.XObject implements org.xms.g.identity.intents.AddressConstants.ErrorCodes {
            
            public XImpl(com.google.android.gms.identity.intents.AddressConstants.ErrorCodes param0, java.lang.Object param1) {
                super(param0, param1);
            }
        }
    }
    
    public static interface Extras extends org.xms.g.utils.XInterface {
        
        public static java.lang.String getEXTRA_ADDRESS() {
            if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
                org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hms.identity.AddressConstants.Extras.EXTRA_NAME_ADDRESS");
                return com.huawei.hms.identity.AddressConstants.Extras.EXTRA_NAME_ADDRESS;
            } else {
                org.xms.g.utils.XmsLog.d("XMSRouter", "com.google.android.gms.identity.intents.AddressConstants.Extras.EXTRA_ADDRESS");
                return com.google.android.gms.identity.intents.AddressConstants.Extras.EXTRA_ADDRESS;
            }
        }
        
        public static java.lang.String getEXTRA_ERROR_CODE() {
            if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
                org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hms.identity.AddressConstants.Extras.EXTRA_NAME_ERR_CODE");
                return com.huawei.hms.identity.AddressConstants.Extras.EXTRA_NAME_ERR_CODE;
            } else {
                org.xms.g.utils.XmsLog.d("XMSRouter", "com.google.android.gms.identity.intents.AddressConstants.Extras.EXTRA_ERROR_CODE");
                return com.google.android.gms.identity.intents.AddressConstants.Extras.EXTRA_ERROR_CODE;
            }
        }
        
        default com.google.android.gms.identity.intents.AddressConstants.Extras getGInstanceExtras() {
            if (this instanceof org.xms.g.utils.XGettable) {
                return ((com.google.android.gms.identity.intents.AddressConstants.Extras) ((org.xms.g.utils.XGettable) this).getGInstance());
            }
            return new com.google.android.gms.identity.intents.AddressConstants.Extras() {
            };
        }
        
        default com.huawei.hms.identity.AddressConstants.Extras getHInstanceExtras() {
            if (this instanceof org.xms.g.utils.XGettable) {
                return ((com.huawei.hms.identity.AddressConstants.Extras) ((org.xms.g.utils.XGettable) this).getHInstance());
            }
            return new com.huawei.hms.identity.AddressConstants.Extras() {
            };
        }
        
        public static org.xms.g.identity.intents.AddressConstants.Extras dynamicCast(java.lang.Object param0) {
            if (param0 instanceof org.xms.g.identity.intents.AddressConstants.Extras) {
                return ((org.xms.g.identity.intents.AddressConstants.Extras) param0);
            }
            if (param0 instanceof org.xms.g.utils.XGettable) {
                com.google.android.gms.identity.intents.AddressConstants.Extras gReturn = ((com.google.android.gms.identity.intents.AddressConstants.Extras) ((org.xms.g.utils.XGettable) param0).getGInstance());
                com.huawei.hms.identity.AddressConstants.Extras hReturn = ((com.huawei.hms.identity.AddressConstants.Extras) ((org.xms.g.utils.XGettable) param0).getHInstance());
                return new org.xms.g.identity.intents.AddressConstants.Extras.XImpl(gReturn, hReturn);
            }
            return ((org.xms.g.identity.intents.AddressConstants.Extras) param0);
        }
        
        public static boolean isInstance(java.lang.Object param0) {
            if (!(param0 instanceof org.xms.g.utils.XInterface)) {
                return false;
            }
            if (param0 instanceof org.xms.g.utils.XGettable) {
                if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
                    return ((org.xms.g.utils.XGettable) param0).getHInstance() instanceof com.huawei.hms.identity.AddressConstants.Extras;
                } else {
                    return ((org.xms.g.utils.XGettable) param0).getGInstance() instanceof com.google.android.gms.identity.intents.AddressConstants.Extras;
                }
            }
            return param0 instanceof org.xms.g.identity.intents.AddressConstants.Extras;
        }
        
        public static class XImpl extends org.xms.g.utils.XObject implements org.xms.g.identity.intents.AddressConstants.Extras {
            
            public XImpl(com.google.android.gms.identity.intents.AddressConstants.Extras param0, com.huawei.hms.identity.AddressConstants.Extras param1) {
                super(param0, param1);
            }
        }
    }
    
    public static interface ResultCodes extends org.xms.g.utils.XInterface {
        int hms_RESULT_ERROR = 1;
        
        public static int getRESULT_ERROR() {
            if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
                org.xms.g.utils.XmsLog.d("XMSRouter","com.huawei.hms.identity.RESULT_ERROR");
                return hms_RESULT_ERROR;
            } else {
                org.xms.g.utils.XmsLog.d("XMSRouter", "com.google.android.gms.identity.intents.AddressConstants.ResultCodes.RESULT_ERROR");
                return com.google.android.gms.identity.intents.AddressConstants.ResultCodes.RESULT_ERROR;
            }
        }
        
        default com.google.android.gms.identity.intents.AddressConstants.ResultCodes getGInstanceResultCodes() {
            if (this instanceof org.xms.g.utils.XGettable) {
                return ((com.google.android.gms.identity.intents.AddressConstants.ResultCodes) ((org.xms.g.utils.XGettable) this).getGInstance());
            }
            return new com.google.android.gms.identity.intents.AddressConstants.ResultCodes() {
            };
        }
        default java.lang.Object getHInstanceResultCodes() {
            if (this instanceof org.xms.g.utils.XGettable) {
                return ((java.lang.Object) ((org.xms.g.utils.XGettable) this).getHInstance());
            }
            return new java.lang.Object();
        }
        
        
        public static org.xms.g.identity.intents.AddressConstants.ResultCodes dynamicCast(java.lang.Object param0) {
            if (param0 instanceof org.xms.g.identity.intents.AddressConstants.ResultCodes) {
                return ((org.xms.g.identity.intents.AddressConstants.ResultCodes) param0);
            }
            if (param0 instanceof org.xms.g.utils.XGettable) {
                com.google.android.gms.identity.intents.AddressConstants.ResultCodes gReturn = ((com.google.android.gms.identity.intents.AddressConstants.ResultCodes) ((org.xms.g.utils.XGettable) param0).getGInstance());
                throw new RuntimeException("hms branch not support");
            }
            return ((org.xms.g.identity.intents.AddressConstants.ResultCodes) param0);
        }
        
        public static boolean isInstance(java.lang.Object param0) {
            if (!(param0 instanceof org.xms.g.utils.XInterface)) {
                return false;
            }
            if (param0 instanceof org.xms.g.utils.XGettable) {
                if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
                    throw new RuntimeException("hms branch not support");
                } else {
                    return ((org.xms.g.utils.XGettable) param0).getGInstance() instanceof com.google.android.gms.identity.intents.AddressConstants.ResultCodes;
                }
            }
            return param0 instanceof org.xms.g.identity.intents.AddressConstants.ResultCodes;
        }
        
        public static class XImpl extends org.xms.g.utils.XObject implements org.xms.g.identity.intents.AddressConstants.ResultCodes {
            
            public XImpl(com.google.android.gms.identity.intents.AddressConstants.ResultCodes param0, java.lang.Object param1) {
                super(param0, param1);
            }
        }
    }
    
    public static interface Themes extends org.xms.g.utils.XInterface {
        int hms_THEME_DARK = 0;
        int hms_THEME_HOLO_DARK = 0;
        int hms_THEME_HOLO_LIGHT = 1;
        int hms_THEME_LIGHT = 1;
        
        public static int getTHEME_DARK() {
            if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
                org.xms.g.utils.XmsLog.d("XMSRouter","com.huawei.hms.identity.THEME_DARK");
                return hms_THEME_DARK;
            } else {
                org.xms.g.utils.XmsLog.d("XMSRouter", "com.google.android.gms.identity.intents.AddressConstants.Themes.THEME_DARK");
                return com.google.android.gms.identity.intents.AddressConstants.Themes.THEME_DARK;
            }
        }
        
        public static int getTHEME_HOLO_DARK() {
            if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
                org.xms.g.utils.XmsLog.d("XMSRouter","com.huawei.hms.identity.THEME_HOLO_DARK");
                return hms_THEME_HOLO_DARK;
            } else {
                org.xms.g.utils.XmsLog.d("XMSRouter", "com.google.android.gms.identity.intents.AddressConstants.Themes.THEME_HOLO_DARK");
                return com.google.android.gms.identity.intents.AddressConstants.Themes.THEME_HOLO_DARK;
            }
        }
        
        public static int getTHEME_HOLO_LIGHT() {
            if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
                org.xms.g.utils.XmsLog.d("XMSRouter","com.huawei.hms.identity.THEME_HOLO_LIGHT");
                return hms_THEME_HOLO_LIGHT;
            } else {
                org.xms.g.utils.XmsLog.d("XMSRouter", "com.google.android.gms.identity.intents.AddressConstants.Themes.THEME_HOLO_LIGHT");
                return com.google.android.gms.identity.intents.AddressConstants.Themes.THEME_HOLO_LIGHT;
            }
        }
        
        public static int getTHEME_LIGHT() {
            if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
                org.xms.g.utils.XmsLog.d("XMSRouter","com.huawei.hms.identity.THEME_LIGHT");
                return hms_THEME_LIGHT;
            } else {
                org.xms.g.utils.XmsLog.d("XMSRouter", "com.google.android.gms.identity.intents.AddressConstants.Themes.THEME_LIGHT");
                return com.google.android.gms.identity.intents.AddressConstants.Themes.THEME_LIGHT;
            }
        }
        
        default com.google.android.gms.identity.intents.AddressConstants.Themes getGInstanceThemes() {
            if (this instanceof org.xms.g.utils.XGettable) {
                return ((com.google.android.gms.identity.intents.AddressConstants.Themes) ((org.xms.g.utils.XGettable) this).getGInstance());
            }
            return new com.google.android.gms.identity.intents.AddressConstants.Themes() {
            };
        }
        default java.lang.Object getHInstanceThemes() {
            if (this instanceof org.xms.g.utils.XGettable) {
                return ((java.lang.Object) ((org.xms.g.utils.XGettable) this).getHInstance());
            }
            return new java.lang.Object();
        }
        
        
        public static org.xms.g.identity.intents.AddressConstants.Themes dynamicCast(java.lang.Object param0) {
            if (param0 instanceof org.xms.g.identity.intents.AddressConstants.Themes) {
                return ((org.xms.g.identity.intents.AddressConstants.Themes) param0);
            }
            if (param0 instanceof org.xms.g.utils.XGettable) {
                com.google.android.gms.identity.intents.AddressConstants.Themes gReturn = ((com.google.android.gms.identity.intents.AddressConstants.Themes) ((org.xms.g.utils.XGettable) param0).getGInstance());
                throw new RuntimeException("hms branch not support");
            }
            return ((org.xms.g.identity.intents.AddressConstants.Themes) param0);
        }
        
        public static boolean isInstance(java.lang.Object param0) {
            if (!(param0 instanceof org.xms.g.utils.XInterface)) {
                return false;
            }
            if (param0 instanceof org.xms.g.utils.XGettable) {
                if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
                    throw new RuntimeException("hms branch not support");
                } else {
                    return ((org.xms.g.utils.XGettable) param0).getGInstance() instanceof com.google.android.gms.identity.intents.AddressConstants.Themes;
                }
            }
            return param0 instanceof org.xms.g.identity.intents.AddressConstants.Themes;
        }
        
        public static class XImpl extends org.xms.g.utils.XObject implements org.xms.g.identity.intents.AddressConstants.Themes {
            
            public XImpl(com.google.android.gms.identity.intents.AddressConstants.Themes param0, java.lang.Object param1) {
                super(param0, param1);
            }
        }
    }
}