package org.xms.g.common;

public final class SignInButton extends android.widget.FrameLayout implements android.view.View.OnClickListener, org.xms.g.utils.XGettable {
    public com.google.android.gms.common.SignInButton gInstance;
    public com.huawei.hms.support.hwid.ui.HuaweiIdAuthButton hInstance;
    
    public SignInButton(android.content.Context param0) {
        super(param0);
        if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
            this.setHInstance(new com.huawei.hms.support.hwid.ui.HuaweiIdAuthButton(param0));
        } else {
            this.setGInstance(new com.google.android.gms.common.SignInButton(param0));
        }
    }
    
    public SignInButton(android.content.Context param0, android.util.AttributeSet param1) {
        super(param0, param1);
        if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
            this.setHInstance(new com.huawei.hms.support.hwid.ui.HuaweiIdAuthButton(param0, param1));
        } else {
            this.setGInstance(new com.google.android.gms.common.SignInButton(param0, param1));
        }
    }
    
    public SignInButton(android.content.Context param0, android.util.AttributeSet param1, int param2) {
        super(param0, param1, param2);
        if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
            this.setHInstance(new com.huawei.hms.support.hwid.ui.HuaweiIdAuthButton(param0, param1, param2));
        } else {
            this.setGInstance(new com.google.android.gms.common.SignInButton(param0, param1, param2));
        }
    }
    
    public static int getCOLOR_AUTO() {
        if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
            org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hms.support.hwid.ui.HuaweiIdAuthButton.COLOR_POLICY_BLUE");
            return com.huawei.hms.support.hwid.ui.HuaweiIdAuthButton.COLOR_POLICY_BLUE;
        } else {
            org.xms.g.utils.XmsLog.d("XMSRouter", "com.google.android.gms.common.SignInButton.COLOR_AUTO");
            return com.google.android.gms.common.SignInButton.COLOR_AUTO;
        }
    }
    
    public static int getCOLOR_DARK() {
        if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
            org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hms.support.hwid.ui.HuaweiIdAuthButton.COLOR_POLICY_RED");
            return com.huawei.hms.support.hwid.ui.HuaweiIdAuthButton.COLOR_POLICY_RED;
        } else {
            org.xms.g.utils.XmsLog.d("XMSRouter", "com.google.android.gms.common.SignInButton.COLOR_DARK");
            return com.google.android.gms.common.SignInButton.COLOR_DARK;
        }
    }
    
    public static int getCOLOR_LIGHT() {
        if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
            org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hms.support.hwid.ui.HuaweiIdAuthButton.COLOR_POLICY_WHITE");
            return com.huawei.hms.support.hwid.ui.HuaweiIdAuthButton.COLOR_POLICY_WHITE;
        } else {
            org.xms.g.utils.XmsLog.d("XMSRouter", "com.google.android.gms.common.SignInButton.COLOR_LIGHT");
            return com.google.android.gms.common.SignInButton.COLOR_LIGHT;
        }
    }
    
    public static int getSIZE_ICON_ONLY() {
        if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
            org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hms.support.hwid.ui.HuaweiIdAuthButton.THEME_NO_TITLE");
            return com.huawei.hms.support.hwid.ui.HuaweiIdAuthButton.THEME_NO_TITLE;
        } else {
            org.xms.g.utils.XmsLog.d("XMSRouter", "com.google.android.gms.common.SignInButton.SIZE_ICON_ONLY");
            return com.google.android.gms.common.SignInButton.SIZE_ICON_ONLY;
        }
    }
    
    public static int getSIZE_STANDARD() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static int getSIZE_WIDE() {
        if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
            org.xms.g.utils.XmsLog.d("XMSRouter", "com.huawei.hms.support.hwid.ui.HuaweiIdAuthButton.THEME_FULL_TITLE");
            return com.huawei.hms.support.hwid.ui.HuaweiIdAuthButton.THEME_FULL_TITLE;
        } else {
            org.xms.g.utils.XmsLog.d("XMSRouter", "com.google.android.gms.common.SignInButton.SIZE_WIDE");
            return com.google.android.gms.common.SignInButton.SIZE_WIDE;
        }
    }
    
    public final void onClick(android.view.View param0) {
        if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
            org.xms.g.utils.XmsLog.d("XMSRouter", "org.xms.g.common.SignInButton.onClick(android.view.View)");
            ((com.huawei.hms.support.hwid.ui.HuaweiIdAuthButton) this.getHInstance()).performClick();
        } else {
            org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.common.SignInButton) this.getGInstance()).onClick(param0)");
            ((com.google.android.gms.common.SignInButton) this.getGInstance()).onClick(param0);
        }
    }
    
    public final void setColorScheme(int param0) {
        if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
            org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.support.hwid.ui.HuaweiIdAuthButton) this.getHInstance()).setColorPolicy(param0)");
            ((com.huawei.hms.support.hwid.ui.HuaweiIdAuthButton) this.getHInstance()).setColorPolicy(param0);
        } else {
            org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.common.SignInButton) this.getGInstance()).setColorScheme(param0)");
            ((com.google.android.gms.common.SignInButton) this.getGInstance()).setColorScheme(param0);
        }
    }
    
    public final void setEnabled(boolean param0) {
        if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
            org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.support.hwid.ui.HuaweiIdAuthButton) this.getHInstance()).setEnabled(param0)");
            ((com.huawei.hms.support.hwid.ui.HuaweiIdAuthButton) this.getHInstance()).setEnabled(param0);
        } else {
            org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.common.SignInButton) this.getGInstance()).setEnabled(param0)");
            ((com.google.android.gms.common.SignInButton) this.getGInstance()).setEnabled(param0);
        }
    }
    
    public final void setOnClickListener(android.view.View.OnClickListener param0) {
        if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
            org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.support.hwid.ui.HuaweiIdAuthButton) this.getHInstance()).setOnClickListener(param0)");
            ((com.huawei.hms.support.hwid.ui.HuaweiIdAuthButton) this.getHInstance()).setOnClickListener(param0);
        } else {
            org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.common.SignInButton) this.getGInstance()).setOnClickListener(param0)");
            ((com.google.android.gms.common.SignInButton) this.getGInstance()).setOnClickListener(param0);
        }
    }
    
    public final void setScopes(org.xms.g.common.api.Scope[] param0) {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public final void setSize(int param0) {
        if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
            org.xms.g.utils.XmsLog.d("XMSRouter", "((com.huawei.hms.support.hwid.ui.HuaweiIdAuthButton) this.getHInstance()).setTheme(param0)");
            ((com.huawei.hms.support.hwid.ui.HuaweiIdAuthButton) this.getHInstance()).setTheme(param0);
        } else {
            org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.common.SignInButton) this.getGInstance()).setSize(param0)");
            ((com.google.android.gms.common.SignInButton) this.getGInstance()).setSize(param0);
        }
    }
    
    public final void setStyle(int param0, int param1, org.xms.g.common.api.Scope[] param2) {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public final void setStyle(int param0, int param1) {
        if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
            org.xms.g.utils.XmsLog.d("XMSRouter", "org.xms.g.common.SignInButton.setStyle(intint)");
            ((com.huawei.hms.support.hwid.ui.HuaweiIdAuthButton) this.getHInstance()).setUIMode(param0, param1,
                com.huawei.hms.support.hwid.ui.HuaweiIdAuthButton.CORNER_RADIUS_MEDIUM);
        } else {
            org.xms.g.utils.XmsLog.d("XMSRouter", "((com.google.android.gms.common.SignInButton) this.getGInstance()).setStyle(param0, param1)");
            ((com.google.android.gms.common.SignInButton) this.getGInstance()).setStyle(param0, param1);
        }
    }
    
    public void setGInstance(com.google.android.gms.common.SignInButton param0) {
        this.gInstance = param0;
        this.removeAllViews();
        this.addView(gInstance);
        this.setClickable(true);
    }
    
    public void setHInstance(com.huawei.hms.support.hwid.ui.HuaweiIdAuthButton param0) {
        this.hInstance = param0;
        this.removeAllViews();
        this.addView(hInstance);
        this.setClickable(true);
    }
    
    public java.lang.Object getGInstance() {
        return this.gInstance;
    }
    
    public java.lang.Object getHInstance() {
        return this.hInstance;
    }
    
    public static org.xms.g.common.SignInButton dynamicCast(java.lang.Object param0) {
        return ((org.xms.g.common.SignInButton) param0);
    }
    
    public static boolean isInstance(java.lang.Object param0) {
        if (!(param0 instanceof org.xms.g.utils.XGettable)) {
            return false;
        }
        if (org.xms.g.utils.GlobalEnvSetting.isHms()) {
            return ((org.xms.g.utils.XGettable) param0).getHInstance() instanceof com.huawei.hms.support.hwid.ui.HuaweiIdAuthButton;
        } else {
            return ((org.xms.g.utils.XGettable) param0).getGInstance() instanceof com.google.android.gms.common.SignInButton;
        }
    }
    
    public org.xms.g.common.SignInButton wrapInst(com.google.android.gms.common.SignInButton param0, com.huawei.hms.support.hwid.ui.HuaweiIdAuthButton param1) {
        gInstance = param0;
        hInstance = param1;
        return this;
    }
}