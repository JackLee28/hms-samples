package org.xms.g.wallet;

public final class PaymentMethodTokenizationParameters extends org.xms.g.utils.XObject {
    public static final android.os.Parcelable.Creator CREATOR = new android.os.Parcelable.Creator() {
        
        public org.xms.g.wallet.PaymentMethodTokenizationParameters createFromParcel(android.os.Parcel param0) {
            throw new java.lang.RuntimeException("Not Supported");
        }
        
        public org.xms.g.wallet.PaymentMethodTokenizationParameters[] newArray(int param0) {
            throw new java.lang.RuntimeException("Not Supported");
        }
    };
    
    public PaymentMethodTokenizationParameters(com.google.android.gms.wallet.PaymentMethodTokenizationParameters param0, java.lang.Object param1) {
        super(param0, null);
    }
    
    public android.os.Bundle getParameters() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public int getPaymentMethodTokenizationType() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static org.xms.g.wallet.PaymentMethodTokenizationParameters.Builder newBuilder() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public void writeToParcel(android.os.Parcel param0, int param1) {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static org.xms.g.wallet.PaymentMethodTokenizationParameters dynamicCast(java.lang.Object param0) {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static boolean isInstance(java.lang.Object param0) {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static final class Builder extends org.xms.g.utils.XObject {
        
        public Builder(com.google.android.gms.wallet.PaymentMethodTokenizationParameters.Builder param0, java.lang.Object param1) {
            super(param0, null);
        }
        
        public org.xms.g.wallet.PaymentMethodTokenizationParameters addParameter(String param0, String param1) {
            throw new java.lang.RuntimeException("Not Supported");
        }
        
        public org.xms.g.wallet.PaymentMethodTokenizationParameters build() {
            throw new java.lang.RuntimeException("Not Supported");
        }
        
        public org.xms.g.wallet.PaymentMethodTokenizationParameters.Builder setPaymentMethodTokenizationType(int param0) {
            throw new java.lang.RuntimeException("Not Supported");
        }
        
        public static org.xms.g.wallet.PaymentMethodTokenizationParameters.Builder dynamicCast(java.lang.Object param0) {
            throw new java.lang.RuntimeException("Not Supported");
        }
        
        public static boolean isInstance(java.lang.Object param0) {
            throw new java.lang.RuntimeException("Not Supported");
        }
    }
}