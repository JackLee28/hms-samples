package org.xms.g.common.data;

public final class DataBufferObserverSet extends org.xms.g.utils.XObject implements org.xms.g.common.data.DataBufferObserver, org.xms.g.common.data.DataBufferObserver.Observable {
    
    public DataBufferObserverSet(com.google.android.gms.common.data.DataBufferObserverSet param0, java.lang.Object param1) {
        super(param0, null);
    }
    
    public DataBufferObserverSet() {
        super(((com.google.android.gms.common.data.DataBufferObserverSet) null), null);
    }
    
    public final void addObserver(org.xms.g.common.data.DataBufferObserver param0) {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public final void clear() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public final boolean hasObservers() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public final void onDataChanged() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public final void onDataRangeChanged(int param0, int param1) {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public final void onDataRangeInserted(int param0, int param1) {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public final void onDataRangeMoved(int param0, int param1, int param2) {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public final void onDataRangeRemoved(int param0, int param1) {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public final void removeObserver(org.xms.g.common.data.DataBufferObserver param0) {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static org.xms.g.common.data.DataBufferObserverSet dynamicCast(java.lang.Object param0) {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static boolean isInstance(java.lang.Object param0) {
        throw new java.lang.RuntimeException("Not Supported");
    }
}