package org.xms.g.wallet;

public final class CardRequirements extends org.xms.g.utils.XObject implements android.os.Parcelable {
    public static final android.os.Parcelable.Creator CREATOR = new android.os.Parcelable.Creator() {
        
        public org.xms.g.wallet.CardRequirements createFromParcel(android.os.Parcel param0) {
            throw new java.lang.RuntimeException("Not Supported");
        }
        
        public org.xms.g.wallet.CardRequirements[] newArray(int param0) {
            throw new java.lang.RuntimeException("Not Supported");
        }
    };
    
    public CardRequirements(com.google.android.gms.wallet.CardRequirements param0, java.lang.Object param1) {
        super(param0, null);
    }
    
    public final boolean allowPrepaidCards() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public java.util.ArrayList<java.lang.Integer> getAllowedCardNetworks() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public final int getBillingAddressFormat() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public final boolean isBillingAddressRequired() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static org.xms.g.wallet.CardRequirements.Builder newBuilder() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public final void writeToParcel(android.os.Parcel param0, int param1) {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public int describeContents() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static org.xms.g.wallet.CardRequirements dynamicCast(java.lang.Object param0) {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static boolean isInstance(java.lang.Object param0) {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static final class Builder extends org.xms.g.utils.XObject {
        
        public Builder(com.google.android.gms.wallet.CardRequirements.Builder param0, java.lang.Object param1) {
            super(param0, null);
        }
        
        public final org.xms.g.wallet.CardRequirements.Builder addAllowedCardNetwork(int param0) {
            throw new java.lang.RuntimeException("Not Supported");
        }
        
        public final org.xms.g.wallet.CardRequirements.Builder addAllowedCardNetworks(java.util.Collection<java.lang.Integer> param0) {
            throw new java.lang.RuntimeException("Not Supported");
        }
        
        public final org.xms.g.wallet.CardRequirements build() {
            throw new java.lang.RuntimeException("Not Supported");
        }
        
        public final org.xms.g.wallet.CardRequirements.Builder setAllowPrepaidCards(boolean param0) {
            throw new java.lang.RuntimeException("Not Supported");
        }
        
        public final org.xms.g.wallet.CardRequirements.Builder setBillingAddressFormat(int param0) {
            throw new java.lang.RuntimeException("Not Supported");
        }
        
        public final org.xms.g.wallet.CardRequirements.Builder setBillingAddressRequired(boolean param0) {
            throw new java.lang.RuntimeException("Not Supported");
        }
        
        public static org.xms.g.wallet.CardRequirements.Builder dynamicCast(java.lang.Object param0) {
            throw new java.lang.RuntimeException("Not Supported");
        }
        
        public static boolean isInstance(java.lang.Object param0) {
            throw new java.lang.RuntimeException("Not Supported");
        }
    }
}