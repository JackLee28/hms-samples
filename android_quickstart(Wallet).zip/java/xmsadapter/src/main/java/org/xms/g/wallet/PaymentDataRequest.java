package org.xms.g.wallet;

public final class PaymentDataRequest extends org.xms.g.utils.XObject implements android.os.Parcelable {
    public static final android.os.Parcelable.Creator CREATOR = new android.os.Parcelable.Creator() {
        
        public org.xms.g.wallet.PaymentDataRequest createFromParcel(android.os.Parcel param0) {
            throw new java.lang.RuntimeException("Not Supported");
        }
        
        public org.xms.g.wallet.PaymentDataRequest[] newArray(int param0) {
            throw new java.lang.RuntimeException("Not Supported");
        }
    };
    
    public PaymentDataRequest(com.google.android.gms.wallet.PaymentDataRequest param0, java.lang.Object param1) {
        super(param0, null);
    }
    
    public static org.xms.g.wallet.PaymentDataRequest fromJson(java.lang.String param0) {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public java.util.ArrayList<java.lang.Integer> getAllowedPaymentMethods() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public final org.xms.g.wallet.CardRequirements getCardRequirements() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public final org.xms.g.wallet.PaymentMethodTokenizationParameters getPaymentMethodTokenizationParameters() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public final org.xms.g.wallet.ShippingAddressRequirements getShippingAddressRequirements() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public final org.xms.g.wallet.TransactionInfo getTransactionInfo() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public final boolean isEmailRequired() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public final boolean isPhoneNumberRequired() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public final boolean isShippingAddressRequired() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public final boolean isUiRequired() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static synchronized org.xms.g.wallet.PaymentDataRequest.Builder newBuilder() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public final java.lang.String toJson() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public final void writeToParcel(android.os.Parcel param0, int param1) {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public int describeContents() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static org.xms.g.wallet.PaymentDataRequest dynamicCast(java.lang.Object param0) {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static boolean isInstance(java.lang.Object param0) {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static final class Builder extends org.xms.g.utils.XObject {
        
        public Builder(com.google.android.gms.wallet.PaymentDataRequest.Builder param0, java.lang.Object param1) {
            super(param0, null);
        }
        
        public final org.xms.g.wallet.PaymentDataRequest.Builder addAllowedPaymentMethod(int param0) {
            throw new java.lang.RuntimeException("Not Supported");
        }
        
        public final org.xms.g.wallet.PaymentDataRequest.Builder addAllowedPaymentMethods(java.util.Collection<java.lang.Integer> param0) {
            throw new java.lang.RuntimeException("Not Supported");
        }
        
        public final org.xms.g.wallet.PaymentDataRequest build() {
            throw new java.lang.RuntimeException("Not Supported");
        }
        
        public final org.xms.g.wallet.PaymentDataRequest.Builder setCardRequirements(org.xms.g.wallet.CardRequirements param0) {
            throw new java.lang.RuntimeException("Not Supported");
        }
        
        public final org.xms.g.wallet.PaymentDataRequest.Builder setEmailRequired(boolean param0) {
            throw new java.lang.RuntimeException("Not Supported");
        }
        
        public final org.xms.g.wallet.PaymentDataRequest.Builder setPaymentMethodTokenizationParameters(org.xms.g.wallet.PaymentMethodTokenizationParameters param0) {
            throw new java.lang.RuntimeException("Not Supported");
        }
        
        public final org.xms.g.wallet.PaymentDataRequest.Builder setPhoneNumberRequired(boolean param0) {
            throw new java.lang.RuntimeException("Not Supported");
        }
        
        public final org.xms.g.wallet.PaymentDataRequest.Builder setShippingAddressRequired(boolean param0) {
            throw new java.lang.RuntimeException("Not Supported");
        }
        
        public final org.xms.g.wallet.PaymentDataRequest.Builder setShippingAddressRequirements(org.xms.g.wallet.ShippingAddressRequirements param0) {
            throw new java.lang.RuntimeException("Not Supported");
        }
        
        public final org.xms.g.wallet.PaymentDataRequest.Builder setTransactionInfo(org.xms.g.wallet.TransactionInfo param0) {
            throw new java.lang.RuntimeException("Not Supported");
        }
        
        public final org.xms.g.wallet.PaymentDataRequest.Builder setUiRequired(boolean param0) {
            throw new java.lang.RuntimeException("Not Supported");
        }
        
        public static org.xms.g.wallet.PaymentDataRequest.Builder dynamicCast(java.lang.Object param0) {
            throw new java.lang.RuntimeException("Not Supported");
        }
        
        public static boolean isInstance(java.lang.Object param0) {
            throw new java.lang.RuntimeException("Not Supported");
        }
    }
}