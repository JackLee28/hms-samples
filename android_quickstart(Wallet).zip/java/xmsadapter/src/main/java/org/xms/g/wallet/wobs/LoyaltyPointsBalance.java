package org.xms.g.wallet.wobs;

public final class LoyaltyPointsBalance extends org.xms.g.utils.XObject implements android.os.Parcelable {
    public static final android.os.Parcelable.Creator CREATOR = new android.os.Parcelable.Creator() {
        
        public org.xms.g.wallet.wobs.LoyaltyPointsBalance createFromParcel(android.os.Parcel param0) {
            throw new java.lang.RuntimeException("Not Supported");
        }
        
        public org.xms.g.wallet.wobs.LoyaltyPointsBalance[] newArray(int param0) {
            throw new java.lang.RuntimeException("Not Supported");
        }
    };
    
    public LoyaltyPointsBalance(com.google.android.gms.wallet.wobs.LoyaltyPointsBalance param0, java.lang.Object param1) {
        super(param0, null);
    }
    
    public final java.lang.String getCurrencyCode() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public final long getCurrencyMicros() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public final double getDouble() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public final int getInt() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public final java.lang.String getString() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public final int getType() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static org.xms.g.wallet.wobs.LoyaltyPointsBalance.Builder newBuilder() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public final void writeToParcel(android.os.Parcel param0, int param1) {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public int describeContents() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static org.xms.g.wallet.wobs.LoyaltyPointsBalance dynamicCast(java.lang.Object param0) {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static boolean isInstance(java.lang.Object param0) {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static final class Builder extends org.xms.g.utils.XObject {
        
        public Builder(com.google.android.gms.wallet.wobs.LoyaltyPointsBalance.Builder param0, java.lang.Object param1) {
            super(param0, null);
        }
        
        public final org.xms.g.wallet.wobs.LoyaltyPointsBalance build() {
            throw new java.lang.RuntimeException("Not Supported");
        }
        
        public final org.xms.g.wallet.wobs.LoyaltyPointsBalance.Builder setDouble(double param0) {
            throw new java.lang.RuntimeException("Not Supported");
        }
        
        public final org.xms.g.wallet.wobs.LoyaltyPointsBalance.Builder setInt(int param0) {
            throw new java.lang.RuntimeException("Not Supported");
        }
        
        public final org.xms.g.wallet.wobs.LoyaltyPointsBalance.Builder setMoney(java.lang.String param0, long param1) {
            throw new java.lang.RuntimeException("Not Supported");
        }
        
        public final org.xms.g.wallet.wobs.LoyaltyPointsBalance.Builder setString(java.lang.String param0) {
            throw new java.lang.RuntimeException("Not Supported");
        }
        
        public static org.xms.g.wallet.wobs.LoyaltyPointsBalance.Builder dynamicCast(java.lang.Object param0) {
            throw new java.lang.RuntimeException("Not Supported");
        }
        
        public static boolean isInstance(java.lang.Object param0) {
            throw new java.lang.RuntimeException("Not Supported");
        }
    }
    
    public static interface Type extends org.xms.g.utils.XInterface {
        
        public static int getDOUBLE() {
            throw new java.lang.RuntimeException("Not Supported");
        }
        
        public static int getINT() {
            throw new java.lang.RuntimeException("Not Supported");
        }
        
        public static int getMONEY() {
            throw new java.lang.RuntimeException("Not Supported");
        }
        
        public static int getSTRING() {
            throw new java.lang.RuntimeException("Not Supported");
        }
        
        public static int getUNDEFINED() {
            throw new java.lang.RuntimeException("Not Supported");
        }
        
        default com.google.android.gms.wallet.wobs.LoyaltyPointsBalance.Type getGInstanceType() {
            throw new java.lang.RuntimeException("Not Supported");
        }
        
        default java.lang.Object getHInstanceType() {
            throw new java.lang.RuntimeException("Not Supported");
        }
        
        public static org.xms.g.wallet.wobs.LoyaltyPointsBalance.Type dynamicCast(java.lang.Object param0) {
            throw new java.lang.RuntimeException("Not Supported");
        }
        
        public static boolean isInstance(java.lang.Object param0) {
            throw new java.lang.RuntimeException("Not Supported");
        }
        
        public static class XImpl extends org.xms.g.utils.XObject implements org.xms.g.wallet.wobs.LoyaltyPointsBalance.Type {
            
            public XImpl(com.google.android.gms.wallet.wobs.LoyaltyPointsBalance.Type param0, java.lang.Object param1) {
                super(param0, param1);
            }
        }
    }
}