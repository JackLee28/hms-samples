package org.xms.g.location;

public final class LocationStatusCodes extends org.xms.g.utils.XObject {
    
    public LocationStatusCodes(com.google.android.gms.location.LocationStatusCodes param0, java.lang.Object param1) {
        super(param0, null);
    }
    
    public static int getERROR() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static int getGEOFENCE_NOT_AVAILABLE() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static int getGEOFENCE_TOO_MANY_GEOFENCES() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static int getGEOFENCE_TOO_MANY_PENDING_INTENTS() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static int getSUCCESS() {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static org.xms.g.location.LocationStatusCodes dynamicCast(java.lang.Object param0) {
        throw new java.lang.RuntimeException("Not Supported");
    }
    
    public static boolean isInstance(java.lang.Object param0) {
        throw new java.lang.RuntimeException("Not Supported");
    }
}